<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed');


class Io_manage_model extends CI_Model
{
	
	   
	public function __construct()
	{
		parent::__construct();
		
		
	}



	/**
	 * doctors
	 *
	 * @return object Users
	 * @author Ben Edmunds
	 **/
	public function io_list()
	{
	   $query = $this
	   				->db
					->get( 'issue_order' );
 
        if( $query->num_rows() > 0 ) {
		
            return $query->result();
        } else {
            return array();
        }
	}
	

		/**
	 * 
	 *
	 * @insert issue Order into database 
	 * @sazedul. winux soft ltd.
	 **/
	public function createIo( $issue_order, $iwo_number, $material_name, $material_code, $sub_group, $material_group, $material_qty, $unit_price_avg,  $total_price, $measurement_unit ){
	
	$this->db->insert('issue_order', $issue_order); 
	
	
	$j=count($material_name);
	
	
			 
			 $io_num=$this->db->insert_id();
			
	
	for($i=0 ; $i<$j ; $i++):
			
		if(($material_name[$i])!='')	{
		
	  $query='INSERT INTO `io_material_list` (`io_number`,`iwo_number`, `material_name`, `material_code`, `sub_group`, `material_group`, `measurement_unit`,  `material_qty`, `unit_price_avg`, `total_price`, `insert_by`, `io_date` ) VALUES ("'.$io_num.'","'.$iwo_number[$i].'","'.$material_name[$i].'", "'.$material_code[$i].'", "'.$sub_group[$i].'", "'.$material_group[$i].'", "'.$measurement_unit[$i].'", "'.$material_qty[$i].'", "'.$unit_price_avg[$i].'", "'.$total_price[$i].'", "'.$issue_order['insert_by'].'", "'.$issue_order['io_date'].'")';
			 
			mysql_query($query);
	
			//echo $query;
			
				
 			$query2='INSERT INTO `material_stock` ( `io_number`,`iwo_number`, `material_name`, `material_code`,`sub_group`, `material_group`, `measurement_unit`, `material_qty`, `unit_price`, `net_price`, `insert_by` ,  `date` ) VALUES ("'.$io_num.'","'.$iwo_number[$i].'","'.$material_name[$i].'", "'.$material_code[$i].'", "'.$sub_group[$i].'", "'.$material_group[$i].'", "'.$measurement_unit[$i].'", "'.$material_qty[$i].'", "'.$unit_price_avg[$i].'", "'.$total_price[$i].'", "'.$issue_order['insert_by'].'","'.$issue_order['io_date'].'" )';
					 
					mysql_query($query2);				
			
			
			
							$querySu = $this
									->db
									->where('material_code',$material_code[$i])
									->get( 'stock_update' );
									
										
					if( $querySu->num_rows() > 0 ) 
					
					{
							
						 $stock_update=$querySu->result();
						 
							foreach($stock_update as $su):
							 
								if($su->material_code==$material_code[$i])
								 {
									$total_qty=($su->material_qty-$material_qty[$i]);
									
									$total_net_price=($su->net_price-$total_price[$i]);
									
									$avg_unit_price=($total_net_price/$total_qty);
									
									//$avg_net_price=($avg_unit_price*$total_qty);
									
										$data= array(
											'material_qty'=>$total_qty,
											'unit_price'=>$avg_unit_price,
											'net_price'=>$total_net_price
										);
										
										$this->db
											   ->where('material_code', $su->material_code)
											   ->update('stock_update', $data); 
								 }
								 
							endforeach;	
								 
					}		 
							 
			
			} // not null Check	
			
	endfor;
	
			
	}
	
	
	
	
			public function ioInfo($dataIn)
	{
	   $query = $this
	   				->db
					->where('io_number',$dataIn)
					->get( 'issue_order' );
 
        if( $query->num_rows() > 0 ) {
		
            return $query->result();
        } else {
            return false;
        }
	}


	
		/**
		 * Edit Group
		 * @sazedul. winux soft ltd.
		 **/
		public function previewIo($dataIn)
		{
				
		//echo 'data='.$dataIn;					
/*		$query = $this
				 ->db
				 ->select('issue_order.*')
				 ->select('io_material_list.*')	 
				 ->where('issue_order.io_number', $dataIn)
				 ->from('io_material_list')
				 ->join('issue_order', 'issue_order.io_number = io_material_list.io_number')
				 ->get('issue_order');*/
				 
				 
		$query = $this
	   				->db
					->where('io_number',$dataIn)
					->get( 'io_material_list' );
			
			$row = $query->result();	
			
			//print_r($row);	
							  
			return $row;
			  
		}	
	
	
		    function materialAc($idSelect)
    {
    
	
    $sql = "SELECT material_name FROM `stock_update` WHERE `material_name` LIKE '".$idSelect."%'";

    $data=mysql_query($sql);

    $arrcnt = -1;

    $dataArray = array();

    while($temp = mysql_fetch_assoc($data)):

        foreach($temp as $key=>$val)
    {
        $temp[$key] = stripslashes($val);
        $arrcnt++;
    }
    $dataArray[$arrcnt] = $temp;

    endwhile;
    //return $dataArray ;

		foreach ($dataArray as $key => $value) {
	
			echo $value['material_name']."\n";
	
		}
	 
    }
	
	public function material_name($g)
	{
	   $query = $this
	   				->db
					->where('material_name',$g)
					->get( 'stock_update' );
 
        if( $query->num_rows() > 0 ) {
		
            return $query->result();
        } else {
            return 0;
        }
	}
	
	
		
	public function iwo_number_check($g)
	{
	   $query = $this
	   				->db
					->where('iwo_number',$g)
					->get( 'iwo' );
 
        if( $query->num_rows() > 0 ) {
		
            return 0;
        } else {
            return 1;
        }
	}

	
		
//####################################################################################################################	
//******************************************io Return****************************************************************

	public function io_number_check($g)
	{
	   $query = $this
	   				->db
					->where('io_number',$g)
					->get( 'issue_order' );
 
        if( $query->num_rows() > 0 ) {
		
            return 0;
        } else {
            return 1;
        }
	}


	public function ioReturnUpdate( $data, $iwo_number, $material_name, $material_code, $material_group, $material_qty_main, $material_qty, $unit_price_avg, $total_price, $sub_group, $measurement_unit, $io_date, $local )
	{
	
	$io_number=$data['io_number'];
	$update_by=$data['update_by'];
	
	$this->db
					   ->where('io_number', $data['io_number'])
					   ->update('issue_order', $data); 
					   
	$q=$this
                        ->db
						->where('io_number',$data['io_number'])
                        ->delete('io_material_list');	
						   
	/*$q=$this
                        ->db
						->where('io_number',$data['io_number'])
                        ->delete('material_stock');	*/	
						
		$j=count($material_code);
				
		for($i=0 ; $i<$j ; $i++):
				
				if(($material_code[$i])!='')	
				{
					
					
					$return_qty[$i]=($material_qty_main[$i]-$material_qty[$i]);
					$return_net_price[$i]=($return_qty[$i]*$unit_price_avg[$i]);
					
					if($return_qty[$i]!=0)
					{
					$comment[$i]='io Return (amount='.$return_qty[$i].')';
					
					
					 $query='INSERT INTO `io_material_list` ( `io_number`,`iwo_number`, `local`, `return`, `material_name`, `material_code`, `material_group`, `measurement_unit`, `sub_group`, `io_date`, `material_qty`, `unit_price_avg`, `total_price`, `insert_by`, `comment` ) VALUES ("'.$io_number.'","'.$iwo_number[$i].'","'.$local[$i].'",1,"'.$material_name[$i].'", "'.$material_code[$i].'", "'.$material_group[$i].'", "'.$measurement_unit[$i].'", "'.$sub_group[$i].'","'.$io_date[$i].'", "'.$material_qty[$i].'", "'.$unit_price_avg[$i].'", "'.$total_price[$i].'", "'.$update_by.'", "'.$comment[$i].'")';
						 
						mysql_query($query);
						
						
					//echo $query;	
					
					
						$query2='INSERT INTO `material_stock` ( `io_number`,`iwo_number`, `local`, `return`, `material_name`, `material_code`, `material_group`, `sub_group`, `date`, `measurement_unit`, `material_qty`, `unit_price`, `net_price`, `insert_by`, `comment` ) VALUES ("'.$io_number.'","'.$iwo_number[$i].'","'.$local[$i].'",1,"'.$material_name[$i].'", "'.$material_code[$i].'", "'.$material_group[$i].'", "'.$sub_group[$i].'","'.$io_date[$i].'", "'.$measurement_unit[$i].'", "'.$return_qty[$i].'", "'.$unit_price_avg[$i].'", "'.$return_net_price[$i].'", "'.$update_by.'", "'.$comment[$i].'")';
						 
						mysql_query($query2);	
					
					
					 
									
						
						
									
					//echo $query2;
					
			
			//in this section we update
			
						
						$querySu = $this
										->db
										->where('material_code',$material_code[$i])
										->get( 'stock_update' );
										
											
						if( $querySu->num_rows() > 0 ) 
						
						{
								
							 $stock_update=$querySu->result();
							 
								foreach($stock_update as $su):
								 
									if($su->material_code==$material_code[$i])
									 {
										$total_qty=($su->material_qty+$return_qty[$i]);
										
										$total_net_price=($su->net_price+$return_net_price[$i]);
										
										$avg_unit_price=($total_net_price/$total_qty);
										
										$avg_net_price=($avg_unit_price*$total_qty);
										
											$data= array(
												'material_qty'=>$total_qty,
												'unit_price'=>$avg_unit_price,
												'net_price'=>$avg_net_price
											);
											
											$this->db
												   ->where('material_code', $su->material_code)
												   ->update('stock_update', $data); 
									 }			 
								 
								 
								endforeach;
			 
					} 

					 
						
			
	
					}	else 
					
					{
						 $query='INSERT INTO `io_material_list` ( `io_number`,`iwo_number`, `local`, `return`, `material_name`, `material_code`, `material_group`, `measurement_unit`, `sub_group`, `io_date`, `material_qty`, `unit_price_avg`, `total_price`, `insert_by`, `comment` ) VALUES ("'.$io_number.'","'.$iwo_number[$i].'","'.$local[$i].'",1,"'.$material_name[$i].'", "'.$material_code[$i].'", "'.$material_group[$i].'", "'.$measurement_unit[$i].'", "'.$sub_group[$i].'","'.$io_date[$i].'", "'.$material_qty[$i].'", "'.$unit_price_avg[$i].'", "'.$total_price[$i].'", "'.$update_by.'", "0")';
						 
						mysql_query($query);
					}
			}
			
		endfor;
		
			   
		
				 
	
				
	} /*****End of ioReturnUpdate*****/
	
	
		
		
			
		public function io_m_list($g)
		{
		   $query = $this	   				
						->db
						->where('io_number', $g)
						->get( 'io_material_list' );
	 
			if( $query->num_rows() > 0 ) 
			{
			
				return $query->result();
			} 
			else 
			{
				return array();
			}
		}	
		
		
##################################Issue##order##LOCAL###############################################################

	public function createIoLocal( $issue_order, $material_name, $material_code, $sub_group, $material_group, $material_qty, $unit_price_avg,  $total_price, $measurement_unit ){
	
	$this->db->insert('issue_order', $issue_order); 
	
	
	$j=count($material_name);
	
	
			 
			 $io_num=$this->db->insert_id();
			 
			
	
	for($i=0 ; $i<$j ; $i++):
			
		if(($material_name[$i])!='')	{
		
			 $query='INSERT INTO `io_material_list` (`io_number`, `local`, `material_name`, `material_code`, `sub_group`, `material_group`, `measurement_unit`,  `material_qty`, `unit_price_avg`, `total_price`, `insert_by`, `io_date` ) VALUES ("'.$io_num.'","'.$issue_order['local'].'","'.$material_name[$i].'", "'.$material_code[$i].'", "'.$sub_group[$i].'", "'.$material_group[$i].'", "'.$measurement_unit[$i].'", "'.$material_qty[$i].'", "'.$unit_price_avg[$i].'", "'.$total_price[$i].'", "'.$issue_order['insert_by'].'", "'.$issue_order['io_date'].'")';
			 
			mysql_query($query);
	
			//echo $query;
			
				
 			$query2='INSERT INTO `material_stock` ( `io_number`, `local`, `material_name`, `material_code`,`sub_group`, `material_group`, `measurement_unit`, `material_qty`, `unit_price`, `net_price`, `insert_by` ,  `date` ) VALUES ("'.$io_num.'","'.$issue_order['local'].'","'.$material_name[$i].'", "'.$material_code[$i].'", "'.$sub_group[$i].'", "'.$material_group[$i].'", "'.$measurement_unit[$i].'", "'.$material_qty[$i].'", "'.$unit_price_avg[$i].'", "'.$total_price[$i].'", "'.$issue_order['insert_by'].'","'.$issue_order['io_date'].'" )';
					 
					mysql_query($query2);				
			
			//echo $query2;
			
							$querySu = $this
									->db
									->where('material_code',$material_code[$i])
									->get( 'stock_update' );
									
										
					if( $querySu->num_rows() > 0 ) 
					
					{
							
						 $stock_update=$querySu->result();
						 
							foreach($stock_update as $su):
							 
								if($su->material_code==$material_code[$i])
								 {
									$total_qty=($su->material_qty-$material_qty[$i]);
									
									$total_net_price=($su->net_price-$total_price[$i]);
									
									$avg_unit_price=($total_net_price/$total_qty);
									
									//$avg_net_price=($avg_unit_price*$total_qty);
									
										$data= array(
											'material_qty'=>$total_qty,
											'unit_price'=>$avg_unit_price,
											'net_price'=>$total_net_price
										);
										
										$this->db
											   ->where('material_code', $su->material_code)
											   ->update('stock_update', $data); 
								 }
								 
							endforeach;	
								 
					}		 
							 
			
			} // not null Check	
			
	endfor;
	
			
	}

######################################################################################################################
	
}  //End of Model Class