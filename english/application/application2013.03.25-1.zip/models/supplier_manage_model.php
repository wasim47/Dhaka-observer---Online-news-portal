<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed');


class Supplier_manage_model extends CI_Model
{
	
	   
	public function __construct()
	{
		parent::__construct();
		
		
	}



	/**
	 * doctors
	 *
	 * @return object Users
	 * @author Ben Edmunds
	 **/
	public function supplier_list()
	{
	   $query = $this
	   				->db
					->get( 'supplier' );
 
        if( $query->num_rows() > 0 ) {
		
            return $query->result();
        } else {
            return array();
        }
	}
	
		/**
	 * activate
	 *
	 * @return void
	 * @author Mathew
	 **/
	public function activate($id)
	{
		$data = array(
		    'active'          => 1
		);


$this->db->where('id', $id);
$this->db->update('supplier', $data);

		return false;
	}


	/**
	 * Deactivate
	 *
	 * @return void
	 * @author Mathew
	 **/
	public function deactivate($id)
	{
		
		
		$data = array(
		    'active'          => 0
		);


$this->db->where('id', $id);
$this->db->update('supplier', $data);
		
		return false;
	}

		/**
	 * add_staff
	 *
	 * @insert New Staff into database 
	 * @sazedul. winux soft ltd.
	 **/
	public function createSupplier($data){
	
	$this->db->insert('supplier', $data); 
			
	}
	
	public function user_del($id)
	{
		
		//echo $id;		
		$q=$this
                        ->db
						->where('id',$id)
                        ->delete('supplier');

         
	} 	
	
		/**
		 * Edit Group
		 * @sazedul. winux soft ltd.
		 **/
		public function editSupplier($id)
		{
				
			$query = $this
							->db
							->select('*')
							->where('id', $id)
							->limit(1)
							->get('supplier');
			
			
			$row = $query->row_array();		
							  
			return $row;
			  
		}	
	
	
		public function updateSupplier($s_id,$data){
		
		$this->db
					   ->where('id', $s_id)
					   ->update('supplier', $data); 
		}
		
//####################################################################################################################	
	
	
}  //End of Model Class