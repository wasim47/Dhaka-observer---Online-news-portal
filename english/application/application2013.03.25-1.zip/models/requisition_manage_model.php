<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed');


class Requisition_manage_model extends CI_Model
{
	
	   
	public function __construct()
	{
		parent::__construct();
		
		
	}



	/**
	 * doctors
	 *
	 * @return object Users
	 * @author Ben Edmunds
	 **/
	public function requisition_list()
	{
	   $query = $this
	   				->db
					->get( 'requisition' );
 
        if( $query->num_rows() > 0 ) {
		
            return $query->result();
        } else {
            return array();
        }
	}
	

	/**
	 * @insert issue Order into database 
	 * @sazedul. winux soft ltd.
	 **/
	public function createRequisition( $requisition, $iwo_number, $material_name, $material_code, $size,  $material_qty, $measurement_unit, $comment ){
	
	$this->db->insert('requisition', $requisition);
	 
	$requisition_number=$this->db->insert_id();
	
	$j=count($material_name);

	for($i=0 ; $i<$j ; $i++):
			
		if(($material_name[$i])!='')	{
		
		
	 		$data = array('requisition_number' => $requisition_number, 'iwo_number' => $iwo_number[$i] , 'material_name' => $material_name[$i], 'material_code' => $material_code[$i], 'size' => $size[$i], 'material_qty' => $material_qty[$i], 'measurement_unit' => $measurement_unit[$i], 'comment' => $comment[$i], 'requisitors_name' => $requisition['requisitors_name'], 'r_date' => $requisition['r_date'] );

$this->db->set($data);
$this->db->insert('requisition_material_list'); 
							 
			
			} // not null Check	
			
	endfor;
	
			
	}
	
	
	
	
			public function requisitionInfo($id)
	{
	   $query = $this
	   				->db
					->where('id',$id)
					->get( 'requisition' );
 
        if( $query->num_rows() > 0 ) {
		
            return $query->result();
        } else {
            return false;
        }
	}


	
		/**
		 * Edit Group
		 * @sazedul. winux soft ltd.
		 **/
		public function previewRequisition($id)
		{
				 
				 
		$query = $this
	   				->db
					->where('requisition_number',$id)
					->get( 'requisition_material_list' );
			
			$row = $query->result();	
			
			//print_r($row);	
							  
			return $row;
			  
		}	
	
	
		    function materialAc($idSelect)
    {
    
	
    $sql = "SELECT material_name FROM `stock_update` WHERE `material_name` LIKE '".$idSelect."%'";

    $data=mysql_query($sql);

    $arrcnt = -1;

    $dataArray = array();

    while($temp = mysql_fetch_assoc($data)):

        foreach($temp as $key=>$val)
    {
        $temp[$key] = stripslashes($val);
        $arrcnt++;
    }
    $dataArray[$arrcnt] = $temp;

    endwhile;
    //return $dataArray ;

		foreach ($dataArray as $key => $value) {
	
			echo $value['material_name']."\n";
	
		}
	 
    }
	
	public function material_name($g)
	{
	   $query = $this
	   				->db
					->where('material_name',$g)
					->get( 'stock_update' );
 
        if( $query->num_rows() > 0 ) {
		
            return $query->result();
        } else {
            return 0;
        }
	}
	
	
		
	public function iwo_number_check($g)
	{
	   $query = $this
	   				->db
					->where('iwo_number',$g)
					->get( 'iwo' );
 
        if( $query->num_rows() > 0 ) {
		
            return 0;
        } else {
            return 1;
        }
	}
public function requisition_del($id)
	{
		
		//echo $id;		
		$q=$this
                        ->db
						->where('requisition_number',$id)
                        ->delete('requisition_material_list');
		$q=$this
                        ->db
						->where('id',$id)
                        ->delete('requisition');
         
	} 	
	
	
		

	
}  //End of Model Class