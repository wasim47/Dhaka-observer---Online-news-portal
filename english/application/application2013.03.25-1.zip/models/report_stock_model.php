<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed');


class Report_stock_model extends CI_Model
{
	
	   
	public function __construct()
	{
		parent::__construct();
		
		
	}



	
	public function report_stock_list()
	{
	
	   $query = $this->db->get( 'material_stock' );

        if( $query->num_rows() > 0 ) 
		{
		
			$uo=$query->result();
			
			//print_r($uo);
           return $uo;
        } 
		else 
		{
            return array();
        }
	}
	
	
	
	public function report_stock_dateList()
	{
	
	  /* $query = $this->db->get( 'stock_update' );*/
					
		$q="SELECT * FROM `material_stock` WHERE `date` BETWEEN CAST('2013-01-02' AS DATE) AND CAST('2013-03-14' AS DATE)";

		$query = $this->db->query($q);
 
        if( $query->num_rows() > 0 ) 
		{
		
			$uo=$query->result();
			
			//print_r($uo);
           return $uo;
        } 
		else 
		{
            return array();
        }
	}
	
	
	public function pi_m_list($g)
	{
	   $query = $this	   				
	   				->db
					->where('pi_number', $g)
					->get( 'pi_material_list' );
 
        if( $query->num_rows() > 0 ) 
		{
		
            return $query->result();
        } 
		else 
		{
            return array();
        }
	}	
	
	
		public function material_name_trigger($g)
	{
	   $query = $this	   				
	   				->db
					->where('material_name', $g)
					->order_by("id", "asc")
					->get( 'material_stock' );
 
        if( $query->num_rows() > 0 ) 
		{
		
            return $query->result();
        } 
		else 
		{
            return array();
        }
	}
	
	
		public function issue_name_by_date($g)
	{
	   $query = $this	   				
	   				->db
					->where('io_date', $g)
					->order_by("id", "asc")
					->get( 'io_material_list' );
 
        if( $query->num_rows() > 0 ) 
		{
		
            return $query->result();
        } 
		else 
		{
            return array();
        }
	}
	
	
		public function receive_name_by_date($g)
	{
	   $query = $this	   				
	   				->db
					->where('invoice_date', $g)
					->order_by("id", "asc")
					->get( 'pi_material_list' );
 
        if( $query->num_rows() > 0 ) 
		{
		
            return $query->result();
        } 
		else 
		{
            return array();
        }
	}
	
	
	



		public function avg_price_trigger($g)
	{
	   $query = $this	   				
	   				->db
					->select('unit_price')
					->where('material_name', $g)
					->get( 'stock_update' );
 
        if( $query->num_rows() > 0 ) 
		{
		
            return $query->result();
        } 
		else 
		{
            return array();
        }
	}
	
	
		public function material_name_list_trigger($g)
	{
	   $query = $this	   				
	   				->db
					->where('material_group',$g)
					->get( 'material' );
					
					//print_r($query);
 
        if( $query->num_rows() > 0 ) 
		{
		
            return $query->result();
        } 
		else 
		{
            return array();
        }
	}

	
		    function materialAc($idSelect)
    {
    
	
    $sql = "SELECT material_name FROM `stock_update` WHERE `material_code` LIKE '".$idSelect."%'";

    $data=mysql_query($sql);

    $arrcnt = -1;

    $dataArray = array();

    while($temp = mysql_fetch_assoc($data)):

        foreach($temp as $key=>$val)
    {
        $temp[$key] = stripslashes($val);
        $arrcnt++;
    }
    $dataArray[$arrcnt] = $temp;

    endwhile;
    //return $dataArray ;

		foreach ($dataArray as $key => $value) {
	
			echo $value['material_code']."\n";
	
		}
	 
    }	
	
		
		public function material_code_trigger($g)
	{
	   $query = $this	   				
	   				->db
					->where('material_code', $g)
					->get( 'stock_update' );
 
        if( $query->num_rows() > 0 ) 
		{
		
            return $query->result();
        } 
		else 
		{
            return array();
        }
	}	
	
	
	
	public function stockUpdateHistory($g)
	{
	   $query = $this	   				
	   				->db
					->where('material_code', $g)
					->get( 'material_stock' );
 
        if( $query->num_rows() > 0 ) 
		{
		
            return $query->result();
        } 
		else 
		{
            return array();
        }
	}
	 
	public function pi_number_check($g)
	{
	   $query = $this
	   				->db
					->where('pi_number',$g)
					->get( 'material_stock' );
 
        if( $query->num_rows() > 0 ) 
		{
		
            return 0;
        } 
		else 
		{
            return 1;
        }
	}

#####################################Total##Stock####Report########################################################################

	
		public function totalStock_name_by_date($g)
	{
	   $query = $this	   				
	   				->db
					->where('date', $g)
					->order_by("id", "asc")
					->get( 'material_stock' );
 
        if( $query->num_rows() > 0 ) 
		{
		
            return $query->result();
        } 
		else 
		{
            return array();
        }
	}

		

#######################################Total##Stock####Report#####################################################################
	
#####################################Work##Order####Report########################################################################

	
		public function wo_nameTrigger($g)
	{
	   $query = $this	   				
	   				->db
					->where('iwo_number', $g)
					->order_by("id", "asc")
					->get( 'material_stock' );
 
        if( $query->num_rows() > 0 ) 
		{
		
            return $query->result();
        } 
		else 
		{
            return array();
        }
	}

		

#######################################Work##Order####Report######################################################################


#####################################Total##Stock####Report#######################################################################

	
		public function groupStock_name_by_date($g)
	{
	   $query = $this	   				
	   				->db
					->where('date', $g)
					->order_by("id", "asc")
					->get( 'material_stock' );
 
        if( $query->num_rows() > 0 ) 
		{
		
            return $query->result();
        } 
		else 
		{
            return array();
        }
	}

		

#######################################Total##Stock####Report#####################################################################		
} /*****End of CLASS stock  Update  model  *****/ 