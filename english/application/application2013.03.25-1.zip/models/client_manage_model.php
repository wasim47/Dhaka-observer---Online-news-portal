<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed');


class Client_manage_model extends CI_Model
{
	
	   
	public function __construct()
	{
		parent::__construct();
		
		
	}



	/**
	 * doctors
	 *
	 * @return object Users
	 * @author Ben Edmunds
	 **/
	public function client_list()
	{
	   $query = $this
	   				->db
					->get( 'client' );
 
        if( $query->num_rows() > 0 ) {
		
            return $query->result();
        } else {
            return array();
        }
	}
	
		/**
	 * activate
	 *
	 * @return void
	 * @author Mathew
	 **/
	public function activate($id)
	{
		$data = array(
		    'active'          => 1
		);


$this->db->where('client_code', $id);
$this->db->update('client', $data);

		return false;
	}


	/**
	 * Deactivate
	 *
	 * @return void
	 * @author Mathew
	 **/
	public function deactivate($id)
	{
		
		
		$data = array(
		    'active'          => 0
		);


$this->db->where('client_code', $id);
$this->db->update('client', $data);
		
		return false;
	}

		/**
	 * add_staff
	 *
	 * @insert New Staff into database 
	 * @sazedul. winux soft ltd.
	 **/
	public function createClient($data, $contact_person_name, $contact_person_phone, $contact_person_email)
	{
	
		$this->db->insert('client', $data); 
		
		$client_code=$this->db->insert_id();
	
		$j=count($contact_person_name);
			
		for($i=0 ; $i<$j ; $i++):
				
			if(($contact_person_name[$i])!='')	
			{
			
				 $query='INSERT INTO `client_contact_list` ( `client_name`, `client_code`, `contact_person_name`, `contact_person_email`, `contact_person_phone`, `insert_by`, `create_date`) VALUES ("'.$data['client_name'].'","'.$client_code.'","'.$contact_person_name[$i].'", "'.$contact_person_email[$i].'", "'.$contact_person_phone[$i].'", "'.$data['insert_by'].'", "'.$data['create_date'].'")';
				 
				mysql_query($query);
		
				//echo $query;
			}	
				
		endfor;
		
				
	}// End of CreateClient
	
	public function user_del($id)
	{
		
		//echo $id;		
		$q=$this
                        ->db
						->where('client_code',$id)
                        ->delete('client');
						
		$q=$this
				->db
				->where('client_code',$id)
				->delete('client_contact_list');

         
	} 	
	
		/**
		 * Edit Group
		 * @sazedul. winux soft ltd.
		 **/
		public function editClient($id)
		{
				
			$query = $this
							->db
							->select('*')
							->where('client_code', $id)
							->limit(1)
							->get('client');
			
			
			$row = $query->row_array();		
							  
			return $row;
			  
		}	
		
		public function contactList($id)
		{
				
			$query = $this
							->db
							->select('*')
							->where('client_code', $id)
							->get('client_contact_list');
			
			
			$row = $query->result();		
							  
			return $row;
			  
		}	
	
	
		public function updateClient($s_id,$data, $contact_person_name, $contact_person_phone, $contact_person_email, $cp_id )
		{
			
			$this->db
						   ->where('client_code', $s_id)
						   ->update('client', $data); 
			$q=$this
				->db
				->where('client_code',$data['client_code'])
				->delete('client_contact_list');			   
						   
					   
				$j=count($contact_person_name);
			
		for($i=0 ; $i<$j ; $i++):
				
			if(($contact_person_name[$i])!='')	
			{
			
				
			
				 $query='INSERT INTO `client_contact_list` ( `client_name`, `client_code`, `contact_person_name`, `contact_person_email`, `contact_person_phone`, `update_by`, `update_date`) VALUES ("'.$data['client_name'].'","'.$data['client_code'].'","'.$contact_person_name[$i].'", "'.$contact_person_email[$i].'", "'.$contact_person_phone[$i].'", "'.$data['update_by'].'", "'.$data['update_date'].'")';
				 
				
				 
				mysql_query($query);
		
				//echo $query;
			}	
				
		endfor;		   
		
		}
		
//####################################################################################################################	
	
	
}  //End of Model Class