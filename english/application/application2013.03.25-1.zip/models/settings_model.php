<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed');


class Settings_model extends CI_Model
{
	
	   
	public function __construct()
	{
		parent::__construct();
		
		
	}



	/**
	 * doctors
	 *
	 * @return object Users
	 * @author Ben Edmunds
	 **/
	public function locations_list()
	{
	   $query = $this
	   				->db->get( 'locations' );
 
        if( $query->num_rows() > 0 ) {
		
            $data=$query->result();
			
			
			return $data;
			
        } else {
            return array();
        }
	}
	
	
	
	/**
	 * doctors
	 *
	 * @return object Users
	 * @author sazedul winux
	 **/
	public function location_medped_list()
	{
	   $query = $this
	   				->db
					->where( 'company_name' ,1)
					->get( 'locations' );
 
        if( $query->num_rows() > 0 ) {
		
            $data=$query->result();
			
			
			return $data;
			
        } else {
            return array();
        }
	}



	
	/**
	 * doctors
	 *
	 * @return object Users
	 * @author sazedul winux
	 **/
	public function location_express_list()
	{
	   $query = $this
	   				->db
					->where( 'company_name' , 2)
					->get( 'locations' );
 
        if( $query->num_rows() > 0 ) {
		
            $data=$query->result();
			
			
			return $data;
			
        } else {
            return array();
        }
	}


	
		/**
	 * add_staff
	 *
	 * @insert New Staff into database 
	 * @sazedul. winux soft ltd.
	 **/
	public function addLocation($data){
	
	$this->db->insert('locations', $data); 
			
	}
	
	
	/**
	 * Staff Education delete
	 *
	 * @return Education from db
	 * @sazedul. winux soft ltd.
	 **/
	public function locations_del($id)
	{
		
		//echo $id;		
		$q=$this
                        ->db
						->where('id',$id)
                        ->delete('locations');

         
	} 		
	
	
	
		
		/**
	 *  insurance_update
	 *
	 * @return professional_suffixes from db
	 * @sazedul. winux soft ltd.
	 **/
	public function locations_update($id, $data){
	
	
	
	
			
			$dataA = array(
		   			 'active' => '0'
					   );
							


		 $this->db->update('locations', $dataA);
				 
					
	if(!empty($data)){
				
	foreach ($data as $location){
		
	$dataB = array(
		   			 'active' => '1'
					   );
							

//echo 'id='.$i;

		 $this->db
		 		->where('location',$location)
				->update('locations', $dataB);
	
				}
  
  
  	}		
	
} 

//*********************************Company Name Insert#######################################################################


/**
	 * doctors
	 *
	 * @return object Users
	 * @author Ben Edmunds
	 **/
	public function company_list()
	{
	   $query = $this
	   				->db->get( 'company_names' );
 
        if( $query->num_rows() > 0 ) {
		
            $data=$query->result();
			
			
			return $data;
			
        } else {
            return array();
        }
	}

	
		/**
	 * add_staff
	 *
	 * @insert New Staff into database 
	 * @sazedul. winux soft ltd.
	 **/
	public function addCompany($data){
	
	$this->db->insert('company_names', $data); 
			
	}
	
	
	/**
	 * Staff Education delete
	 *
	 * @return Education from db
	 * @sazedul. winux soft ltd.
	 **/
	public function company_del($id)
	{
		
		//echo $id;		
		$q=$this
                        ->db
						->where('id',$id)
                        ->delete('company_names');

         
	} 		
	
	
	
		
		/**
	 *  insurance_update
	 *
	 * @return professional_suffixes from db
	 * @sazedul. winux soft ltd.
	 **/
	public function company_update($id, $data){
	
	
	
	
			
			$dataA = array(
		   			 'active' => '0'
					   );
							


		 $this->db->update('company_names', $dataA);
				 
					
	if(!empty($data)){
				
	foreach ($data as $company_names){
		
	$dataB = array(
		   			 'active' => '1'
					   );
							

//echo 'id='.$i;

		 $this->db
		 		->where('company_name',$company_names)
				->update('company_names', $dataB);
	
				}
  
  
  	}		
	
} 



	
	
//#################################################################################################################################	
					//END	//#################################################################################################################################	
























	
} //insurance model Class===============================================================



/*$vist_reasons_time = array(
'Pediatric Consultation',
'Pediatric Follow Up',
'Annual Pediatric Checkup',
'Child with Fever',
'Pre-natal Fetal Consultation',
'Pre-natal Fetal Follow Up',
'Sick Child Visit',
'Abscess',
'Acne',
'Alcoholism',
'Allergic Cough',
'Allergy Consultation',
'Annual Physical',
'Arthritis',
'Asthma',
'Cholesterol / Lipids Checkup',
'CT Scan - Head',
'CT Scan - Heart (Coronary CTA)',
'CT Scan - Lungs',
'Cystic Fibrosis',
'Daytime Sleepiness',
'Dermatology Consultation',
'Ear Infection',
'ECG / EKG',
'Eczema',
'Flu Shot',
'Food Intolerance / Allergy',
'Foot Pain',
'Frequent Urination',
'Hair Removal',
'Hearing Problems / Ringing in Ears',
'Hoarseness / Voice Disorder',
'Incontinence',
'Irritable Bowel Syndrome',
'Juvenile Diabetes',
'Migraine',
'Pediatric Cerumen Removal',
'Pediatric Emergency',
'Pediatric Freezing of Warts',
'Pediatric Joint Injection',
'Pediatric Nail Removal',
'Pediatric Pre-Surgery Consultation',
'Pediatric Second Opinion',
'Pediatric Skin Biopsy / Removal of Skin Lesion',
'Pediatric Sports Physical',
'Pediatric Travel Medicine Consultation',
'Pediatric Vaccine(s)',
'Pneumonia',
'Pneumothorax',
'Pre-Travel Checkup',
'Pre-Travel Consultation',
'Pulmonary Function Testing',
'Pyelonephritis',
'Sickle Cell Disease',
'Sinus Problems',
'Sleep Problems',
'Sleep Studies',
'Sore Throat',
'Spirometry',
'STD (Sexually Transmitted Disease)',
'Swelling in Neck',
'Thalassemia',
'Thyroid Consultation',
'Ultrasound',
'Urinary Tract Infection',
'Vertigo',
'Wart(s)',
'Wound Care',
'X-ray',
);*/ 