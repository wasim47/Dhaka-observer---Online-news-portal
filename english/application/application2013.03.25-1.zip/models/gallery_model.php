<?php

class Gallery_model extends CI_Model {

    var $gallery_path;
	var $gallery_path_url;
	//var gallery_path_thumbs_url;
	
	 function __construct() {
        parent::__construct();
		
		$this->gallery_path=realpath(APPPATH.'../staff_photos');
		$this->gallery_path_url = base_url().'staff_photos/';
    }
	
	

    public function doUpload($id) {
	
	//	^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
	
	$query = $this
                        ->db
                        ->where('person_id', $id)
                        ->get('gallery');
		
		//$photo_no=0;
		$photo_qty = $query->num_rows();	
				          
		if($photo_qty==0){
		$photo_no=1;
		//$this->session->set_flashdata('error','   '. $photo_no.'st no photo uploaded');
		}elseif($photo_qty==1){
		$photo_no=2;
		//$this->session->set_flashdata('error','   '.  $photo_no.'nd no photo uploaded');
		}elseif($photo_qty==2){
		$photo_no=3;
		//$this->session->set_flashdata('error','   '.  $photo_no.'rd no photo uploaded');
		}elseif($photo_qty==3){
		$photo_no=4;
		//$this->session->set_flashdata('error', '   '. $photo_no.'th no photo uploaded');
		}
		
		if($photo_qty > 3){
		
		$this->session->set_flashdata('error', '   You can upload maximum 4 photo');

		}	else {			
		
	//	^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^	
		
		
		$config1=array(
			'allowed_types'=>'jpg|jpeg|png|gif',
			'upload_path'=>$this->gallery_path,
			'maintain_ratio' => TRUE,
			'file_name'=>'image_'.$id.$photo_no
			);
											
			$this->load->library('upload',$config1);
			$this->upload->do_upload();
			
	 		$image_data = $this->upload->data();
			
			
			$imagePath='staff_photos/'.$image_data['orig_name'];
			$thumbPath='staff_photos/thumbs/'.$image_data['orig_name'];
			
			
			
			$data = array(
				   'image_path' => $imagePath ,
				   'thumb_path' => $thumbPath ,
				   'person_id' => $id
				);

			$this->db->insert('gallery', $data); 
			
			
			$config2=array(
					'source_image' => $image_data['full_path'],
					'new_image' => $this->gallery_path . '/thumbs',
					'width' => 60,
					'height' => 70
			);
			
			$this->load->library('image_lib',$config2);
			$this->image_lib->resize();
			//return $image_data;
			
			}// if end of > 4
				} // doUpload method End
				
				function get_images(){
				 		
						$files = scandir($this->gallery_path);
						$files = array_diff($files, array('.','..', 'thumbs'));
						
						$images = array();
						
						foreach($files as $file){
								$images []= array(
									'url' => $this->gallery_path_url . $file,
									'thumb_url' => $this->gallery_path_url .'thumbs/'. $file
								);
						}
						
						return $images;
				
				}
				
				
	function imageMain($id){
				
				$query = $this
                        ->db
						->select('image_path')
						->select('default')
                        ->where('person_id', $id)
						->where('default', 1)
                        ->get('gallery');
						          
		if( $query->num_rows() > 0 ) {
								return $row = $query->row_array();	
							} else {
								return $row=array('default'=>'0');
							}
		
		}//  imageMain which return Default photo
		
		
		
				function imagesData($id){		
				
				$query = $this->db
								->where( 'person_id',$id )						
								->get( 'gallery' );
 
							if( $query->num_rows() > 0 ) {
								return $query->result();
							} else {
								return array();
							}
				}//  imagesData return gallery data as an array
				
				
 	 /**
	 * default_photo
	 *
	 * @ make a photo to default photo
	 * @sazedul. winux soft ltd.
	 **/				
				
				
	function default_photo($id, $default_photo_id){
										
		$dataA = array(
		   			 'default' => '0'
					   );
							
	     $id.'<br />';
		 $default_photo_id;	


		 $this->db->where('person_id', $id)
				 ->update('gallery', $dataA);
		
		
		 $dataB= array(
		   			 'default' => '1'
							); 					
		
		$this->db->where('id', $default_photo_id)
				 ->update('gallery', $dataB);
				 
				 	
				}// generate default photo
				
				
				
	 /**
	 * S photo_del delete
	 *
	 * @Delete photo
	 * @sazedul. winux soft ltd.
	 **/
	public function photo_del($id)
	{
		
		$phoId= $id;
						
		$query = $this
                        ->db
						->select('image_path')
						->select('thumb_path')
                        ->where('id',$phoId)
                        ->limit(1)
                        ->get('gallery');		
		
		$row = $query->row_array();		
				          
		 //print_r($row);
			if( $query->num_rows() > 0 ) {
			
				$path['image_path'] = $row['image_path'];
				$path['thumb_path'] = $row['thumb_path'];
			
				unlink($path['image_path']); 
				unlink($path['thumb_path']); 
			 
			
			
					$q=$this
							->db
							->where('id',$id)
							->delete('gallery');
					 
				}
				
	} 		
				
				
				
				
				

	
}
        
    
?>
