<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed');


class Iwo_model extends CI_Model
{
	
	   
	public function __construct()
	{
		parent::__construct();
		
		
	}



	/**
	 * doctors
	 *
	 * @return object Users
	 * @author Ben Edmunds
	 **/
	public function iwo_list()
	{
	   $query = $this
	   				->db
					->get( 'iwo' );
 
        if( $query->num_rows() > 0 ) {
		
            return $query->result();
        } else {
            return array();
        }
	}
	
		/**
	 * activate
	 *
	 * @return void
	 * @author Mathew
	 **/
	public function activate($id)
	{
		$data = array(
		    'active'          => 1
		);


$this->db->where('id', $id);
$this->db->update('iwo', $data);

		return false;
	}


	/**
	 * Deactivate
	 *
	 * @return void
	 * @author Mathew
	 **/
	public function deactivate($id)
	{
		
		
		$data = array(
		    'active'          => 0
		);


$this->db->where('id', $id);
$this->db->update('iwo', $data);
		
		return false;
	}

		/**
	 * add_staff
	 *
	 * @insert New Staff into database 
	 * @sazedul. winux soft ltd.
	 **/
	public function createIwo($iwo, $product_description, $measurement_size, $product_quantity, $total_quantity){
	
	$this->db->insert('iwo', $iwo); 
	
	$iwo_num=$this->db->insert_id();
	
	$j=count($product_description);
			
	for($i=0 ; $i<$j ; $i++):
			
		if(($product_description[$i])!='')	{
		
/*		 $query='INSERT INTO `iwo_product_list` (`iwo_number`, `client_name`, `contact_person_name`, `product_description`, `measurement_size`, `product_quantity`, `total_quantity`, `issued_by`, `issued_to`, `iwoDate`, `deliveryDate` ) VALUES ("'.$iwo_num.'","'.$iwo['client_name'].'","'.$iwo['contact_person_name'].'","'.$product_description[$i].'", "'.$measurement_size[$i].'", "'.$product_quantity[$i].'", "'.$total_quantity[$i].'","'.$iwo['issued_by'].'","'.$iwo['issued_to'].'","'.$iwo['iwoDate'].'","'.$iwo['deliveryDate'].'")';
			 
			mysql_query($query);*/
			
			$data = array('iwo_number' => $iwo_num, 'client_name' => $iwo['client_name'] , 'contact_person_name' => $iwo['contact_person_name'], 'product_description' => $product_description[$i], 'measurement_size' => $measurement_size[$i], 'product_quantity' => $product_quantity[$i], 'total_quantity' => $total_quantity[$i], 'issued_by' => $iwo['issued_by'], 'issued_to' => $iwo['issued_to'], 'iwoDate' => $iwo['iwoDate'], 'deliveryDate' => $iwo['deliveryDate'] );

$this->db->set($data);
$this->db->insert('iwo_product_list'); 
	
			//echo $query;
			}	
			
	endfor;
	
			
	}
	
	
	
	
			public function clientInfo($dataIn)
	{
	   $query = $this
	   				->db
					->where('iwo_number',$dataIn)
					->get( 'iwo' );
 
        if( $query->num_rows() > 0 ) {
		
            return $query->result();
        } else {
            return false;
        }
	}

	
	public function user_del($id)
	{
		
		//echo $id;		
		$q=$this
                        ->db
						->where('iwo_number',$id)
                        ->delete('iwo');
		$q=$this
                        ->db
						->where('iwo_number',$id)
                        ->delete('iwo_product_list');


         
	} 	
	
		/**
		 * Edit Group
		 * @sazedul. winux soft ltd.
		 **/
		public function previewIwo($dataIn)
		{
		$query = $this
	   				->db
					->where('iwo_number',$dataIn)
					->get( 'iwo_product_list' );
 
        if( $query->num_rows() > 0 ) {
		
            return $query->result();
        } else {
            return false;
        }
			  
		}	
	
	
		public function updateIwo($s_id,$data){
		
		$this->db
					   ->where('id', $s_id)
					   ->update('iwo', $data); 
		}
		
		
		
	    function client_autocomplete_name($idSelect)
    {
    
	
    $sql = "SELECT client_name FROM `client` WHERE client_name LIKE '".$idSelect."%'";

    $data=mysql_query($sql);

    $arrcnt = -1;

    $dataArray = array();

		while($temp = mysql_fetch_assoc($data)):
	
			foreach($temp as $key=>$val)
			 {
			$temp[$key] = stripslashes($val);
			$arrcnt++;
			  }
			$dataArray[$arrcnt] = $temp;
	
		endwhile;
		//return $dataArray ;

		foreach ($dataArray as $key => $value) {
	
			echo $value['client_name']."\n";
	
		}
 

    }
	
		public function client_info($g)
	{
	   $query = $this
	   				->db
					->where('client_name',$g)
					->get( 'client' );
 
        if( $query->num_rows() > 0 ) {
		
            return $query->result();
        } else {
            return 0;
        }
	}
	
			
	    function materialAc($idSelect)
    {
    
	
    $sql = "SELECT material_name FROM `material` WHERE `material_name` LIKE '".$idSelect."%'";

    $data=mysql_query($sql);

    $arrcnt = -1;

    $dataArray = array();

    while($temp = mysql_fetch_assoc($data)):

        foreach($temp as $key=>$val)
    {
        $temp[$key] = stripslashes($val);
        $arrcnt++;
    }
    $dataArray[$arrcnt] = $temp;

    endwhile;
    //return $dataArray ;

		foreach ($dataArray as $key => $value) {
	
			echo $value['material_name']."\n";
	
		}
	 
    }
	
	public function contact_name($g)
	{
	   $query = $this
	   				->db
					->where('client_name',$g)
					->get( 'client_contact_list' );
 
        if( $query->num_rows() > 0 ) {
		
            return $query->result();
        } else {
            return 0;
        }
	}
	
	
		
	public function iwo_number_check($g)
	{
	   $query = $this
	   				->db
					->where('iwo_number',$g)
					->get( 'iwo' );
 
        if( $query->num_rows() > 0 ) {
		
            return 0;
        } else {
            return 1;
        }
	}

	
		
//####################################################################################################################	
	
	
}  //End of Model Class