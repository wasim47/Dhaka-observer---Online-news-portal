<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed');


class Pi_model extends CI_Model
{
	
	   
	public function __construct()
	{
		parent::__construct();
		
		
	}



	/**
	 * doctors
	 *
	 * @return object Users
	 * @author Ben Edmunds
	 **/
	public function pi_list()
	{
	   $query = $this
	   				->db
					->get( 'purchase_invoice' );
 
        if( $query->num_rows() > 0 ) {
		
            return $query->result();
        } else {
            return array();
        }
	}
	
		/**
	 * activate
	 *
	 * @return void
	 * @author Mathew
	 **/
	public function activate($id)
	{
		$data = array(
		    'active'          => 1
		);


$this->db->where('id', $id);
$this->db->update('purchase_invoice', $data);

		return false;
	}


	/**
	 * Deactivate
	 *
	 * @return void
	 * @author Mathew
	 **/
	public function deactivate($id)
	{
		
		
		$data = array(
		    'active'          => 0
		);


$this->db->where('id', $id);
$this->db->update('purchase_invoice', $data);
		
		return false;
	}

		/**
	 * add_staff
	 *
	 * @insert New Staff into database 
	 * @sazedul. winux soft ltd.
	 **/
	public function createPi($purchase_invoice, $material_name, $material_code, $sub_group, $material_group, $measurement_unit, $material_qty, $unit_price, $net_price){
	
	$this->db->insert('purchase_invoice', $purchase_invoice); 
	
	
	$j=count($material_name);
			
	for($i=0 ; $i<$j ; $i++):
			
		if(($material_name[$i])!='')	{

		
			 $query='INSERT INTO `pi_material_list` (`pi_number`, `supplier_name`, `supplier_code`,`material_name`, `material_code`, `sub_group`, `material_group`, `measurement_unit`, `material_qty`, `unit_price`, `net_price`, `insert_by`, `invoice_date` ) VALUES ("'.$purchase_invoice['pi_number'].'","'.$purchase_invoice['supplier_name'].'","'.$purchase_invoice['supplier_code'].'","'.$material_name[$i].'", "'.$material_code[$i].'", "'.$sub_group[$i].'", "'.$material_group[$i].'", "'.$measurement_unit[$i].'", "'.$material_qty[$i].'", "'.$unit_price[$i].'", "'.$net_price[$i].'", "'.$purchase_invoice['insert_by'].'", "'.$purchase_invoice['invoice_date'].'")';
			mysql_query($query);
	
			//echo $query;
			}	
			
	endfor;
	
			
	}//end of createPi
	
	
	
	
			public function supplierInfo($dataIn)
	{
	   $query = $this
	   				->db
					->where('pi_number',$dataIn)
					->get( 'purchase_invoice' );
 
        if( $query->num_rows() > 0 ) {
		
            return $query->result();
        } else {
            return false;
        }
	}

	
	public function user_del($id)
	{
		
		//echo $id;		
		$q=$this
                        ->db
						->where('id',$id)
                        ->delete('purchase_invoice');
		$q=$this
                        ->db
						->where('id',$id)
                        ->delete('pi_material_list');


         
	} 	
	
		/**
		 * Edit Group
		 * @sazedul. winux soft ltd.
		 **/
		public function previewPi($dataIn)
		{
				
		//echo 'data='.$dataIn;					
		$query = $this
				 ->db
				 ->select('purchase_invoice.*')
				 ->select('pi_material_list.*')	 
				 ->where('purchase_invoice.pi_number', $dataIn)
				 ->from('pi_material_list')
				 ->join('purchase_invoice', 'purchase_invoice.pi_number = pi_material_list.pi_number')
				 ->get();
			
			$row = $query->result();	
			
			//print_r($row);	
							  
			return $row;
			  
		}	
	
	
		public function updatePi($s_id,$data){
		
		$this->db
					   ->where('id', $s_id)
					   ->update('purchase_invoice', $data); 
		}
		
		
		public function pi_m_list($g)
		{
		   $query = $this	   				
						->db
						->where('pi_number', $g)
						->get( 'pi_material_list' );
	 
			if( $query->num_rows() > 0 ) 
			{
			
				return $query->result();
			} 
			else 
			{
				return array();
			}
		}	
				
			
		
			function ajaxData($idSelect)
		{
		
		
		$sql = "SELECT supplier_name FROM `supplier` WHERE supplier_name LIKE '".$idSelect."%'";
	
		$data=mysql_query($sql);
	
		$arrcnt = -1;
	
		$dataArray = array();
	
			while($temp = mysql_fetch_assoc($data)):
		
				foreach($temp as $key=>$val)
				 {
				$temp[$key] = stripslashes($val);
				$arrcnt++;
				  }
				$dataArray[$arrcnt] = $temp;
		
			endwhile;
			//return $dataArray ;
	
			foreach ($dataArray as $key => $value) {
		
				echo $value['supplier_name']."\n";
		
			}
	 
	
		}
		
		public function supplier_code($g)
	{
	   $query = $this
	   				->db
					->where('supplier_name',$g)
					->get( 'supplier' );
 
        if( $query->num_rows() > 0 ) {
		
            return $query->result();
        } else {
            return 0;
        }
	}
	
			
	    function materialAc($idSelect)
    {
    
	
    $sql = "SELECT material_name FROM `material` WHERE `material_name` LIKE '".$idSelect."%'";

    $data=mysql_query($sql);

    $arrcnt = -1;

    $dataArray = array();

    while($temp = mysql_fetch_assoc($data)):

        foreach($temp as $key=>$val)
    {
        $temp[$key] = stripslashes($val);
        $arrcnt++;
    }
    $dataArray[$arrcnt] = $temp;

    endwhile;
    //return $dataArray ;

		foreach ($dataArray as $key => $value) {
	
			echo $value['material_name']."\n";
	
		}
	 
    }
	
	public function material_name($g)
	{
	   $query = $this
	   				->db
					->where('material_name',$g)
					->get( 'material' );
 
        if( $query->num_rows() > 0 ) {
		
            return $query->result();
        } else {
            return 0;
        }
	}
	
	
		


//******************************************pi Return****************************************************************

	public function pi_number_check($g)
	{
	   $query = $this
	   				->db
					->where('pi_number',$g)
					->get( 'purchase_invoice' );
 
        if( $query->num_rows() > 0 ) {
		
            return 0;
        } else {
            return 1;
        }
	}


	public function piReturnUpdate( $data, $supplier_name, $supplier_code, $material_name, $material_code, $material_qty_main, $material_qty, $unit_price, $net_price, $sub_group, $material_group, $measurement_unit, $invoice_date )
	{
	
	$pi_number=$data['pi_number'];
	$update_by=$data['update_by'];
	
	$this->db
					   ->where('pi_number', $data['pi_number'])
					   ->update('purchase_invoice', $data); 
					   
	$q=$this
                        ->db
						->where('pi_number',$data['pi_number'])
                        ->delete('pi_material_list');	
	
	/*$q=$this
                        ->db
						->where('pi_number',$data['pi_number'])
                        ->delete('material_stock');				*/			   
					   
					   
		
		$j=count($material_code);
				
		for($i=0 ; $i<$j ; $i++):
				
				if(($material_code[$i])!='')	
				{
				
						
				
				$return_qty[$i]=($material_qty_main[$i]-$material_qty[$i]);
				$return_net_price[$i]=($return_qty[$i]*$unit_price[$i]);
				
				if($return_qty[$i]!=0)
				{
				$comment[$i]='pi Return (amount='.$return_qty[$i].')';
				
				
					 $query='INSERT INTO `pi_material_list` ( `pi_number`, `return`, `supplier_name`, `supplier_code`, `material_name`, `material_code`, `material_group`, `sub_group`, `invoice_date`, `measurement_unit`, `material_qty`, `unit_price`, `net_price`, `insert_by`, `comment` ) VALUES ("'.$pi_number.'","1","'.$supplier_name.'","'.$supplier_code.'","'.$material_name[$i].'", "'.$material_code[$i].'", "'.$material_group[$i].'", "'.$sub_group[$i].'","'.$invoice_date[$i].'", "'.$measurement_unit[$i].'", "'.$material_qty[$i].'", "'.$unit_price[$i].'", "'.$net_price[$i].'", "'.$update_by.'", "'.$comment[$i].'")';
					 
					mysql_query($query);
					
					
 				 $query2='INSERT INTO `material_stock` ( `pi_number`, `return`, `supplier_name`, `supplier_code`, `material_name`, `material_code`, `material_group`, `sub_group`, `date`, `measurement_unit`, `material_qty`, `unit_price`, `net_price`, `insert_by`, `comment` ) VALUES ("'.$pi_number.'","1","'.$supplier_name.'","'.$supplier_code.'","'.$material_name[$i].'", "'.$material_code[$i].'", "'.$material_group[$i].'", "'.$sub_group[$i].'","'.$invoice_date[$i].'", "'.$measurement_unit[$i].'", "'.$return_qty[$i].'", "'.$unit_price[$i].'", "'.$return_net_price[$i].'", "'.$update_by.'", "'.$comment[$i].'")';
					 
					mysql_query($query2);	
					
					
				//echo $query;	
		
		//in this section we update
		
					
					$querySu = $this
									->db
									->where('material_code',$material_code[$i])
									->get( 'stock_update' );
									
										
					if( $querySu->num_rows() > 0 ) 
					
					{
							
						 $stock_update=$querySu->result();
						 
							foreach($stock_update as $su):
							 
								if($su->material_code==$material_code[$i])
								 {
									$total_qty=($su->material_qty-$return_qty[$i]);
									
									$total_net_price=($su->net_price-$return_net_price[$i]);
									
									$avg_unit_price=($total_net_price/$total_qty);
									
									$avg_net_price=($avg_unit_price*$total_qty);
									
										$data= array(
											'material_qty'=>$total_qty,
											'unit_price'=>$avg_unit_price,
											'net_price'=>$avg_net_price
										);
										
										$this->db
											   ->where('material_code', $su->material_code)
											   ->update('stock_update', $data); 
								 }			 
							 
							 
							endforeach;
			 
					} 

					} else
				{
				
					 $query='INSERT INTO `pi_material_list` ( `pi_number`, `return`, `supplier_name`, `supplier_code`, `material_name`, `material_code`, `material_group`, `sub_group`, `invoice_date`, `measurement_unit`, `material_qty`, `unit_price`, `net_price`, `insert_by`, `comment` ) VALUES ("'.$pi_number.'","1","'.$supplier_name.'","'.$supplier_code.'","'.$material_name[$i].'", "'.$material_code[$i].'", "'.$material_group[$i].'", "'.$sub_group[$i].'","'.$invoice_date[$i].'", "'.$measurement_unit[$i].'", "'.$material_qty[$i].'", "'.$unit_price[$i].'", "'.$net_price[$i].'", "'.$update_by.'", "0")';
					 
					mysql_query($query);
					
				} 
						
			
	
				}	
				
		endfor;
		
			   
				 
				 
	
				
	} /*****End of piReturnUpdate*****/
	
	public function su_material_qty($g)
		{
		   $query = $this	   				
						->db
						->where('material_code', $g)
						->get( 'stock_update' );
	 
			if( $query->num_rows() > 0 ) 
			{
			
				return $query->result();
			} 
			else 
			{
				return array();
			}
		}	
		
		
//####################################################################################################################			
}  //End of Model Class