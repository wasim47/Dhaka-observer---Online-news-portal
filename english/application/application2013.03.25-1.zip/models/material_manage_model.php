<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed');


class Material_manage_model extends CI_Model
{
	
	   
	public function __construct()
	{
		parent::__construct();
		
		
	}



	/**
	 * doctors
	 *
	 * @return object Users
	 * @author Ben Edmunds
	 **/
	public function material_list()
	{
	   $query = $this
	   				->db
					->get( 'material' );
 
        if( $query->num_rows() > 0 ) {
		
            return $query->result();
        } else {
            return array();
        }
	}
	
		/**
	 * activate
	 *
	 * @return void
	 * @author Mathew
	 **/
	public function activate($id)
	{
		$data = array(
		    'active'          => 1
		);


$this->db->where('id', $id);
$this->db->update('material', $data);

		return false;
	}


	/**
	 * Deactivate
	 *
	 * @return void
	 * @author Mathew
	 **/
	public function deactivate($id)
	{
		
		
		$data = array(
		    'active'          => 0
		);


$this->db->where('id', $id);
$this->db->update('material', $data);
		
		return false;
	}

		/**
	 * add_staff
	 *
	 * @insert New Staff into database 
	 * @sazedul. winux soft ltd.
	 **/
	public function createMaterial($data){
	
	$this->db->insert('material', $data); 
			
	}
	
	public function user_del($id)
	{
		
		//echo $id;		
		$q=$this
                        ->db
						->where('id',$id)
                        ->delete('material');

         
	} 	
	
		/**
		 * Edit Material
		 * @sazedul. winux soft ltd.
		 **/
		public function editMaterial($id)
		{
				
			$query = $this
							->db
							->select('*')
							->where('id', $id)
							->limit(1)
							->get('material');
			
			
			$row = $query->row_array();		
							  
			return $row;
			  
		}	
	
	
		public function updateMaterial($m_id,$data){
		
		$this->db
					   ->where('id', $m_id)
					   ->update('material', $data); 
		}
		
		/**
	 * doctors
	 *
	 * @return object Users
	 * @author Ben Edmunds
	 **/
	public function group_code($g)
	{
	   $query = $this
	   				->db
					->where('material_group',$g)
					->select('code')
					->get( 'material_group' );
 
        if( $query->num_rows() > 0 ) {
		
            return $query->result();
        } else {
            return array();
        }
	}
	
		/**
	 * doctors
	 *
	 * @return object Users
	 * @author Ben Edmunds
	 **/
	public function group_name($g)
	{
	   $query = $this
	   				->db
					->where('code',$g)
					->select('material_group')
					->get( 'material_group' );
 
        if( $query->num_rows() > 0 ) {
		
            return $query->result();
        } else {
            return array();
        }
	}
	
	
	public function sub_group($g)
	{
	   $query = $this
	   				->db
					->where('material_group',$g)
					->select('sub_group')
					->select('sub_group_code')
					->select('material_group')
					->select('group_code')
					
					->get( 'material_sub_group' );
 
        if( $query->num_rows() > 0 ) {
		
            return $query->result();
        } else {
            return array();
        }
	}
	
	
			/**

	 * @return object Users
	 * @author Ben Edmunds
	 **/
	public function sub_group_code($g)
	{
	   $query = $this
	   				->db
					->where('sub_group',$g)
					->select('sub_group_code')
					->get( 'material_sub_group' );
 
        if( $query->num_rows() > 0 ) {
		
            return $query->result();
        } else {
            return array();
        }
	}
	
		/**
	 * doctors
	 *
	 * @return object Users
	 * @author Ben Edmunds
	 **/
	public function sub_group_name($g)
	{
	   $query = $this
	   				->db
					->where('sub_group_code',$g)
					->select('sub_group')
					->select('group_code')
					->select('material_group')
					->get( 'material_sub_group' );
 
        if( $query->num_rows() > 0 ) {
		
            return $query->result();
        } else {
            return array();
        }
	}
	
//####################################################################################################################	
	
	
}