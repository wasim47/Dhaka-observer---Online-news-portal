<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed');


class Stock_update_model extends CI_Model
{
	
	   
	public function __construct()
	{
		parent::__construct();
		
		
	}



	/**
	 * doctors
	 *
	 * @return object Users
	 * @author Ben Edmunds
	 **/
	public function stock_update_list()
	{
	   $query = $this
	   				->db
					->get( 'stock_update' );
 
        if( $query->num_rows() > 0 ) 
		{
		
			$uo=$query->result();
			
			//print_r($uo);
           return $uo;
        } 
		else 
		{
            return array();
        }
	}
	
	
	public function pi_m_list($g)
	{
	   $query = $this	   				
	   				->db
					->where('pi_number', $g)
					->get( 'pi_material_list' );
 
        if( $query->num_rows() > 0 ) 
		{
		
            return $query->result();
        } 
		else 
		{
            return array();
        }
	}	
	
	
		public function material_name_trigger($g)
	{
	   $query = $this	   				
	   				->db
					->where('material_name', $g)
					->get( 'stock_update' );
 
        if( $query->num_rows() > 0 ) 
		{
		
            return $query->result();
        } 
		else 
		{
            return array();
        }
	}
	
	
		public function material_name_list_trigger($g)
	{
	   $query = $this	   				
	   				->db
					->where('material_group',$g)
					->get( 'material' );
					
					//print_r($query);
 
        if( $query->num_rows() > 0 ) 
		{
		
            return $query->result();
        } 
		else 
		{
            return array();
        }
	}

	
		    function materialAc($idSelect)
    {
    
	
    $sql = "SELECT material_name FROM `stock_update` WHERE `material_code` LIKE '".$idSelect."%'";

    $data=mysql_query($sql);

    $arrcnt = -1;

    $dataArray = array();

    while($temp = mysql_fetch_assoc($data)):

        foreach($temp as $key=>$val)
    {
        $temp[$key] = stripslashes($val);
        $arrcnt++;
    }
    $dataArray[$arrcnt] = $temp;

    endwhile;
    //return $dataArray ;

		foreach ($dataArray as $key => $value) {
	
			echo $value['material_code']."\n";
	
		}
	 
    }	
	
		
		public function material_code_trigger($g)
	{
	   $query = $this	   				
	   				->db
					->where('material_code', $g)
					->get( 'stock_update' );
 
        if( $query->num_rows() > 0 ) 
		{
		
            return $query->result();
        } 
		else 
		{
            return array();
        }
	}	
	
	
	
	public function stockUpdateHistory($g)
	{
	   $query = $this	   				
	   				->db
					->where('material_code', $g)
					->get( 'material_stock' );
 
        if( $query->num_rows() > 0 ) 
		{
		
            return $query->result();
        } 
		else 
		{
            return array();
        }
	}
	 
	public function pi_number_check($g)
	{
	   $query = $this
	   				->db
					->where('pi_number',$g)
					->get( 'material_stock' );
 
        if( $query->num_rows() > 0 ) 
		{
		
            return 0;
        } 
		else 
		{
            return 1;
        }
	}

				/**
		 * add_staff
		 *
		 * @insert New Staff into database 
		 * @sazedul. winux soft ltd.
		 **/
	public function createSu($purchase_invoice, $material_name, $material_code, $sub_group, $material_group, $measurement_unit, $material_qty, $unit_price, $net_price)
	{
		
		$j=count($material_name);
				
		for($i=0 ; $i<$j ; $i++):
				
				if(($material_name[$i])!='')	
				{
					
								
		 	$query='INSERT INTO `material_stock` (`pi_number`, `supplier_name`, `supplier_code`,`material_name`, `material_code`, `sub_group`, `material_group`, `measurement_unit`, `material_qty`, `unit_price`, `net_price`, `insert_by`, `date` ) VALUES ("'.$purchase_invoice['pi_number'].'","'.$purchase_invoice['supplier_name'].'","'.$purchase_invoice['supplier_code'].'","'.$material_name[$i].'", "'.$material_code[$i].'", "'.$sub_group[$i].'", "'.$material_group[$i].'", "'.$measurement_unit[$i].'", "'.$material_qty[$i].'", "'.$unit_price[$i].'", "'.$net_price[$i].'", "'.$purchase_invoice['insert_by'].'", "'.$purchase_invoice['date'].'")';
					 
					mysql_query($query);
					
		//echo $query;
		//in this section we update
		
					
					$querySu = $this
									->db
									->where('material_code',$material_code[$i])
									->get( 'stock_update' );
									
										
					if( $querySu->num_rows() > 0 ) 
					
					{
							
						 $stock_update=$querySu->result();
						 
							foreach($stock_update as $su):
							 
								if($su->material_code==$material_code[$i])
								 {
									$total_qty=($su->material_qty+$material_qty[$i]);
									
									$total_net_price=($su->net_price+$net_price[$i]);
									
									$avg_unit_price=($total_net_price/$total_qty);
									
									$new_net_price=($material_qty[$i]*$avg_unit_price);
									
									$avg_net_price=($avg_unit_price*$total_qty);
									
										$data= array(
											'material_qty'=>$total_qty,
											'unit_price'=>$avg_unit_price,
											'net_price'=>$avg_net_price
										);
										
										$this->db
											   ->where('material_code', $su->material_code)
											   ->update('stock_update', $data); 
										
/*										$data2= array(
											'unit_price'=>$avg_unit_price,
											'net_price'=>$new_net_price
										);
										   
								$this->db		
												->where('material_code', $su->material_code)
											   ->where('pi_number', $purchase_invoice['pi_number'])
											   ->update('material_stock', $data2); */ 
											   
											   }			 
			 
							endforeach;
			 
					} 
					else 
					{
								
						 $query2='INSERT INTO `stock_update` (`material_name`, `material_code`, `sub_group`, `material_group`, `measurement_unit`, `material_qty`, `unit_price`, `net_price`, `insert_by` ) VALUES ("'.$material_name[$i].'", "'.$material_code[$i].'", "'.$sub_group[$i].'", "'.$material_group[$i].'", "'.$measurement_unit[$i].'", "'.$material_qty[$i].'", "'.$unit_price[$i].'", "'.$net_price[$i].'", "'.$purchase_invoice['insert_by'].'")';
						 
						mysql_query($query2);
					}
					 
						
			
	
				}	
				
		endfor;
		
			   
				 
				 
	
				
	} /*****End of createSu*****/
	
#######################################Waste####Return#########################################################################

	    function wMaterialAc($idSelect)
    {
    
	
    $sql = "SELECT material_name FROM `stock_update` WHERE `material_name` LIKE '".$idSelect."%'";

    $data=mysql_query($sql);

    $arrcnt = -1;

    $dataArray = array();

    while($temp = mysql_fetch_assoc($data)):

        foreach($temp as $key=>$val)
    {
        $temp[$key] = stripslashes($val);
        $arrcnt++;
    }
    $dataArray[$arrcnt] = $temp;

    endwhile;
    //return $dataArray ;

		foreach ($dataArray as $key => $value) {
	
			echo $value['material_name']."\n";
	
		}
	 
    }
	
	
	
			public function wMaterial_name_trigger($g)
	{
	   $query = $this	   				
	   				->db
					->where('material_name', $g)
					->get( 'stock_update' );
 
        if( $query->num_rows() > 0 ) 
		{
		
            return $query->result();
        } 
		else 
		{
            return array();
        }
	}
	
	
	
	
		public function wasteReturnUpdate($data, $data2){
		
		$this->db
					   ->where('material_code', $data['material_code'])
					   ->update('stock_update', $data); 
					   
					   $this->db->insert('material_stock', $data2); 
					   
		}
		

#######################################Waste####Return#########################################################################
	
	
} /*****End of CLASS stock  Update  model  *****/ 