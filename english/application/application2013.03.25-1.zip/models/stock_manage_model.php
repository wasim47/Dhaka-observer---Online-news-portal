<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed');


class Stock_manage_model extends CI_Model
{
	
	   
	public function __construct()
	{
		parent::__construct();
		
		
	}



	/**
	 * doctors
	 *
	 * @return object Users
	 * @author Ben Edmunds
	 **/
	public function group_list()
	{
	   $query = $this
	   				->db
					->get( 'material_group' );
 
        if( $query->num_rows() > 0 ) {
		
            return $query->result();
        } else {
            return array();
        }
	}
	
	
	
	
	
		/**
	 * activate
	 *
	 * @return void
	 * @author Mathew
	 **/
	public function activate($id)
	{
		$data = array(
		    'active'          => 1
		);


$this->db->where('id', $id);
$this->db->update('material_group', $data);

		return false;
	}


	/**
	 * Deactivate
	 *
	 * @return void
	 * @author Mathew
	 **/
	public function deactivate($id)
	{
		
		
		$data = array(
		    'active'          => 0
		);


$this->db->where('id', $id);
$this->db->update('material_group', $data);
		
		return false;
	}

		/**
	 * add_staff
	 *
	 * @insert New Staff into database 
	 * @sazedul. winux soft ltd.
	 **/
	public function createGroup($data){
	
	$this->db->insert('material_group', $data); 
			
	}
	
	public function user_del($id)
	{
		
		//echo $id;		
		$q=$this
                        ->db
						->where('id',$id)
                        ->delete('material_group');

         
	} 	
	
		/**
		 * Edit Group
		 * @sazedul. winux soft ltd.
		 **/
		public function editGroup($id)
		{
				
			$query = $this
							->db
							->select('*')
							->where('id', $id)
							->limit(1)
							->get('material_group');
			
			
			$row = $query->row_array();		
							  
			return $row;
			  
		}	
	
	
		public function updateGroup($g_id,$data){
		
		$this->db
					   ->where('id', $g_id)
					   ->update('material_group', $data); 
		}
	
//****************************************sub***Group********************************************************
/**
	 * doctors
	 *
	 * @return object Users
	 * @author Ben Edmunds
	 **/
	public function sub_group_list()
	{
	   $query = $this
	   				->db
					->get( 'material_sub_group' );
 
        if( $query->num_rows() > 0 ) {
		
            return $query->result();
        } else {
            return array();
        }
	}
	
	
	
		/**
	 * activate
	 *
	 * @return void
	 * @author Mathew
	 **/
	public function activateSub_($id)
	{
		$data = array(
		    'active'          => 1
		);


$this->db->where('id', $id);
$this->db->update('material_sub_group', $data);

		return false;
	}


	/**
	 * Deactivate
	 *
	 * @return void
	 * @author Mathew
	 **/
	public function deactivateSub_($id)
	{
		
		
		$data = array(
		    'active'          => 0
		);


$this->db->where('id', $id);
$this->db->update('material_sub_group', $data);
		
		return false;
	}

		/**
	 * add_staff
	 *
	 * @insert New Staff into database 
	 * @sazedul. winux soft ltd.
	 **/
	public function createSubGroup($data){
	
	$this->db->insert('material_sub_group', $data); 
			
	}
	
	public function sub_group_del($id)
	{
		
		//echo $id;		
		$q=$this
                        ->db
						->where('id',$id)
                        ->delete('material_sub_group');

         
	} 	
	
		/**
		 * Edit Group
		 * @sazedul. winux soft ltd.
		 **/
		public function editSubGroup($id)
		{
				
			$query = $this
							->db
							->select('*')
							->where('id', $id)
							->limit(1)
							->get('material_sub_group');
			
			
			$row = $query->row_array();		
							  
			return $row;
			  
		}	
	
	
		public function updateSubGroup($sg_id,$data){
		
		$this->db
					   ->where('id', $sg_id)
					   ->update('material_sub_group', $data); 
		}
		
//*********************************************************************************************************************	
	
	
}