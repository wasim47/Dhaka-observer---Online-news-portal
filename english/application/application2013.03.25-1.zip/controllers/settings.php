<?php defined('BASEPATH') OR exit('No direct script access allowed');

// Starting************in the name of*********Allah***********###################################**********
//#########################################################################################################	
					//						|
					//				?	  |_|_|       /					
					//             /--|		|	   |  |
					//	          /   |		| 	   |  |
					//      	 |    |		|      |  |
					//	          \___|_____|_____/   |
//##########################################################################################################	


class Settings extends CI_Controller {

	function __construct()
	{
		parent::__construct();
		
			$this->load->model('settings_model');	
			  

			}

	//redirect if needed, otherwise display the user list

	function index()
	{

           

		if (!$this->session->userdata('identity'))
		{
			//redirect them to the login page
			redirect('admin/login', 'refresh');
		}
		
		else
		{
		
			$data['onload']='settings';
            $data['locations']=$this->settings_model->locations_list();// For  Location List
			
			$data['company']=$this->settings_model->company_list();// For  Location List
            $data['main_content']="settings_view";
        $this->load->view('template', $data);
		}
	}
	
		
	
	//create a new user
	function add_locations()
	{
		//$this->data['title'] = "Create User";

		if (!$this->session->userdata('identity'))
		{
			//redirect them to the login page
			redirect('admin/login', 'refresh');
		}

		//validate form input
		$this->form_validation->set_rules('locations', 'locations', 'required|xss_clean');
		
		

		if ($this->form_validation->run() == true)
		{
			
			$data = array(
				'location' => $this->input->post('locations'),
				'company_name' => $this->input->post('company_name'),
				'address' => $this->input->post('address'),				
				'active'  => 1
				
			);
			

          $this->settings_model->addLocation($data);
		  		  
			redirect('settings', 'refresh');
			
		}
		
	}
	
	
		function locations_update()
	{
		if (!$this->session->userdata('identity'))
		{
			
			redirect('admin/login', 'refresh');
		}else{		
			
						
			
			$id=$this->input->post('id');
			$data=$this->input->post('locations');
			
						
		$this->settings_model->locations_update($id, $data);			
		
		
        redirect('settings', 'refresh'); 
		
		
			
		}		
	}
	
	
function locations_del($id){
	
	$this->settings_model->locations_del($id);
	
	
	redirect('settings');
	
	}

//#############################################################company  #####  Section#######################################


	//create a new user
	function add_company()
	{
		//$this->data['title'] = "Create User";

		if (!$this->session->userdata('identity'))
		{
			//redirect them to the login page
			redirect('admin/login', 'refresh');
		}

		//validate form input
		$this->form_validation->set_rules('company', 'company', 'required|xss_clean');
		
		

		if ($this->form_validation->run() == true)
		{
			
			$data = array(
				'company_name' => $this->input->post('company'),
				'active'  => 1
			);
			

          $this->settings_model->addCompany($data);
		  		  
			redirect('settings', 'refresh');
			
		}
		
	}
	
	
		function company_update()
	{
		if (!$this->session->userdata('identity'))
		{
			
			redirect('admin/login', 'refresh');
		}else{		
			
						
			
			$id=$this->input->post('id');
			$data=$this->input->post('company');
			
						
		$this->settings_model->company_update($id, $data);			
		
		
        redirect('settings', 'refresh'); 
		
		
			
		}		
	}
	
	
function company_del($id){
	
	$this->settings_model->company_del($id);
	
	
	redirect('settings');
	
	}


	 

}//End of insurance Class+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
