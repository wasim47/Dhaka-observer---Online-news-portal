<?php defined('BASEPATH') OR exit('No direct script access allowed');

class Stock_update extends CI_Controller {

	function __construct()
	{
		parent::__construct();
		
		$this->load->model('stock_update_model');
		$this->load->model('stock_manage_model');
		$this->load->model('pi_model');
	}

	//redirect if needed, otherwise display the user list
	function index()
	{

		if (!$this->ion_auth->logged_in())
		{
			//redirect them to the login page
			redirect('admin/login', 'refresh');
		}
		
		elseif (!($this->session->userdata('sm') == 1)&&(!($this->session->userdata('sa') == 1)))
		{
			//redirect them to the home page because they must be an administrator to view this
			redirect($this->config->item('base_url'), 'refresh');
		} else

		{
			//set the flash data error message if there is one
			$this->data['message'] = (validation_errors()) ? validation_errors() : $this->session->flashdata('message');

			//list the users
			$this->data['users'] = $this->ion_auth->users()->result();
			foreach ($this->data['users'] as $k => $user)
			{
				$this->data['users'][$k]->groups = $this->ion_auth->get_users_groups($user->id)->result();
			}

			$data['onload']='stock_update';
            $data['datas']=$this->stock_update_model->stock_update_list();
            $data['message']=$this->data['message'];
            $data['data']=$this->data;
            $data['main_content']="stock_update/index";
        $this->load->view('template', $data);
			//$this->load->view('admin/index', $this->data);
		}
	}
	
	//create a new user
	function create_stock_update()
	{
		
		/*$data['groups'] = $this->stock_manage_model->group_list();	
	    $data['sub_groups'] = $this->stock_manage_model->sub_group_list();*/
	
			
		$this->load->view('stock_update/create_stock_update');	
		
	
	}

	
		function piTrigger()
	{
	
	$g=$this->input->get('dataName');
		
	$data['pi_m_list'] = $this->pi_model->pi_m_list($g);

	//echo $data;
	
	$this->load->view('stock_update/piList',$data);
	
	} 
	
	
	function materialNameTrigger()
	{
	
	$g=$this->input->get('dataName');
		
	$data['m_list'] = $this->stock_update_model->material_name_trigger($g);

	//echo $data;
	
	$this->load->view('stock_update/mList',$data);
	} 
	
	function materialNameListTrigger()
	{
	
	$g=$this->input->get('dataName');
		
	$data['m_n_list'] = $this->stock_update_model->material_name_list_trigger($g);

	//print_r($data);
	
	$this->load->view('stock_update/material_name_list',$data);
	} 
	
	
	
	function materialCodeTrigger()
	{
	
	$g=$this->input->get('dataName');
		
	$data['m_list'] = $this->stock_update_model->material_code_trigger($g);

	//echo $data;
	
	$this->load->view('stock_update/mList',$data);
	} 
	
	
		function materialAc()
		{
		
		$idSelect =$this->input->get('q');
		
			$this->pi_model->materialAc($idSelect);
			
				
        }
	
	
		function piNumberCheck()
	{
	
	$g=$this->input->get('dataName');
		
	$data = $this->stock_update_model->pi_number_check($g);

	echo $data;
	
	//$this->load->view('pi/materialNameTrigger',$data);
	} 
	//create a stock Update
	function insert_su()
	{
		

		if (!$this->session->userdata('identity'))
		{
			//redirect them to the login page
			redirect('admin/login', 'refresh');
		}

			
			$purchase_invoice = array(
			    'pi_number' 	=> $this->input->post('pi_number'),
				'supplier_name' 	=> $this->input->post('supplier_name'),
				'supplier_code' 	=> $this->input->post('supplier_code'),
				'insert_by' 		=> $this->session->userdata('email'),			
				'date'   	=> date('Y-m-d')
			);
			
	
				$material_name 		= $this->input->post('material_name');
				$material_code	 	= $this->input->post('material_code');
				$sub_group			= $this->input->post('sub_group');
				$material_group 	= $this->input->post('material_group');
				$measurement_unit	= $this->input->post('measurement_unit');
				$material_qty 		= $this->input->post('material_qty');
				$unit_price			= $this->input->post('unit_price');
				$net_price			= $this->input->post('net_price');
	
			
			
			    $this->stock_update_model->createSu($purchase_invoice, $material_name, $material_code, $sub_group, $material_group, $measurement_unit, $material_qty, $unit_price, $net_price);
	
				  
					redirect('stock_update','refresh');
			
	
	}	
	

	
	
	function stock_update_history($g)
	{
		
		
			
		$data['datas'] = $this->stock_update_model->stockUpdateHistory($g);
			
		$this->load->view('stock_update/stock_update_history',$data);
		
	} /*****End of createSu*****/
	
	
  //************************************************       *****************************************	
 //*********************************************Current Stock******************************************
//*******************************************************************************************************

	//redirect if needed, otherwise display the user list
	function stock_current()
	{

		if (!$this->ion_auth->logged_in())
		{
			//redirect them to the login page
			redirect('admin/login', 'refresh');
		}
		elseif (!($this->session->userdata('sm') == 1)&&(!($this->session->userdata('sa') == 1)))
		{
			//redirect them to the home page because they must be an administrator to view this
			redirect($this->config->item('base_url'), 'refresh');
		} else

		{
			//set the flash data error message if there is one
			$this->data['message'] = (validation_errors()) ? validation_errors() : $this->session->flashdata('message');

			//list the users
			$this->data['users'] = $this->ion_auth->users()->result();
			foreach ($this->data['users'] as $k => $user)
			{
				$this->data['users'][$k]->groups = $this->ion_auth->get_users_groups($user->id)->result();
			}

			$data['onload']='stock_update';
			$data['groups'] = $this->stock_manage_model->group_list();	
            $data['datas']=$this->stock_update_model->stock_update_list();
            $data['message']=$this->data['message'];
            $data['data']=$this->data;
            $data['main_content']="stock_update/stock_current";
        	$this->load->view('template', $data);
			
		}	
	
	}
	
######################################################Waste#####Return#############################################################
	//create a new user
	function waste_return()
	{	
		$this->load->view('stock_update/waste_return');	

	}
	
	function wMaterialAc()
	{
	//$idSelect = $_REQUEST['idSelect'];
	$idSelect =$this->input->get('q');
   // $idSelect = mysql_real_escape_string(trim($idSelect));
	
		$this->stock_update_model->wMaterialAc($idSelect);
		
			
	}
	
	function wMaterialNameTrigger()
	{
	
	$g=$this->input->get('dataName');
		
	$data['m_list'] = $this->stock_update_model->wMaterial_name_trigger($g);

	//echo $data;
	
	$this->load->view('stock_update/wMList',$data);
	} 
	
		function waste_return_update()
	{
		

		//validate form input
		
			
			$data = array(
				'material_code' => $this->input->post('material_code'),
				'material_qty' => $this->input->post('material_qty'),
				'unit_price'  => $this->input->post('unit_price'),
				'net_price'  => $this->input->post('net_price'),
				'update_by'    => $this->session->userdata('email'),
				'update_date'    => date('Y-m-d')
			);
			
			
				$material_qty_main = $this->input->post('material_qty_main');
				$return=$material_qty_main-$data['material_qty'];
			
			$data2 = array(
				'material_name' => $this->input->post('material_name'),
				'material_code' => $this->input->post('material_code'),
				'return' => '2',
				'material_qty' => $return,
				'unit_price'  => $this->input->post('unit_price'),
				'net_price'  => $this->input->post('net_price'),
				'update_by'    => $this->session->userdata('email'),
				'comment'    => 'waste return='.$return,
				'date'    => date('Y-m-d')
			);
			


			//print_r($data);

          	$this->stock_update_model->wasteReturnUpdate($data, $data2);
					
			redirect('stock_update', 'refresh');
			
		
		
	}
######################################################Waste#####Return#############################################################
}/***** End of CLASS stock  Update  controller  *****/ 
