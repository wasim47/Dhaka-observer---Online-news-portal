<?php defined('BASEPATH') OR exit('No direct script access allowed');

class Stock_manage extends CI_Controller {

	function __construct()
	{
		parent::__construct();
		
		$this->load->model('stock_manage_model');
	}

	//redirect if needed, otherwise display the user list
	function index()
	{

		if (!$this->ion_auth->logged_in())
		{
			//redirect them to the login page
			redirect('admin/login', 'refresh');
		}
		elseif (!($this->session->userdata('sm') == 1)&&(!($this->session->userdata('sa') == 1)))
		{
			//redirect them to the home page because they must be an administrator to view this
			redirect($this->config->item('base_url'), 'refresh');
		} else

		{
			//set the flash data error message if there is one
			$this->data['message'] = (validation_errors()) ? validation_errors() : $this->session->flashdata('message');

			//list the users
			$this->data['users'] = $this->ion_auth->users()->result();
			foreach ($this->data['users'] as $k => $user)
			{
				$this->data['users'][$k]->groups = $this->ion_auth->get_users_groups($user->id)->result();
			}

			$data['onload']='stock_manage';
            $data['datas']=$this->stock_manage_model->group_list();
            $data['message']=$this->data['message'];
            $data['data']=$this->data;
            $data['main_content']="stock_manage/index";
        $this->load->view('template', $data);
			//$this->load->view('admin/index', $this->data);
		}
	}
	
	//create a new user
	function create_group()
	{
		$this->data['title'] = "Create Gtoup";

		if (!$this->session->userdata('identity'))
		{
			//redirect them to the login page
			redirect('admin/login', 'refresh');
		}

		//validate form input
		//$this->form_validation->set_rules('last_name', 'Last Name', 'trim|required|max_length[12]|alpha|xss_clean');
		$this->form_validation->set_rules('group_name', 'Group Name', 'required|xss_clean');
		$this->form_validation->set_rules('group_code', 'Group Code', 'required|xss_clean');
		

		if ($this->form_validation->run() == true)
		{
			
			$data = array(
				'material_group' => $this->input->post('group_name'),
				'code'  => $this->input->post('group_code'),
				'active'  => 1,
				'create_date'    => date('Y-m-d')
			);
			    $this->stock_manage_model->createGroup($data);
	
				  
					redirect('stock_manage', 'refresh');
			
		} else {	
		
		$this->load->view('stock_manage/create_group');	
		} 	
	
	}
	
	
//activate the user
	function activate($id)
	{

			$activation = $this->stock_manage_model->activate($id);
		
                    redirect('stock_manage', 'refresh');
	}
	
	
	//deactivate the user
	function deactivate($id )
	{
		$this->stock_manage_model->deactivate($id);

			//redirect them back to the admin page
			redirect('stock_manage', 'refresh');	
	}

	
	
	function group_del($id){
	  	
	$this->stock_manage_model->user_del($id);
	
	redirect('stock_manage');
	
	}
	
	function edit_group($id)
	{
		$data['id']=$id;  
	
		$data['editGroup']=$this->stock_manage_model->editGroup($id);   
		
		$this->load->view('stock_manage/edit_group',$data);	
	
	}
	
	
		
	function update_group()
	{
		$this->data['title'] = "Edit Profile";

		if (!$this->session->userdata('identity'))
		{
			//redirect them to the login page
			redirect('admin/login', 'refresh');
		}

		//validate form input
		
			
			$data = array(
				'material_group' => $this->input->post('material_group'),
				'code'  => $this->input->post('code'),
				'update_date'  => date('Y-m-d'),
				'update_by'    => $this->session->userdata('email')
			);
			
			 $g_id=$this->input->post('id');
			//print_r($data);

          	$this->stock_manage_model->updateGroup($g_id,$data);
					
			redirect('stock_manage', 'refresh');
			
		
		
	}
	
	//*************************************SUB**Group********************************************************************
		//redirect if needed, otherwise display the user list
	function sub_group()
	{

		if (!$this->ion_auth->logged_in())
		{
			//redirect them to the login page
			redirect('admin/login', 'refresh');
		}
		elseif (!($this->session->userdata('sm') == 1)&&(!($this->session->userdata('sa') == 1)))
		{
			//redirect them to the home page because they must be an administrator to view this
			redirect($this->config->item('base_url'), 'refresh');
		} else

		{
			//set the flash data error message if there is one
			$this->data['message'] = (validation_errors()) ? validation_errors() : $this->session->flashdata('message');

			//list the users
			$this->data['users'] = $this->ion_auth->users()->result();
			foreach ($this->data['users'] as $k => $user)
			{
				$this->data['users'][$k]->groups = $this->ion_auth->get_users_groups($user->id)->result();
			}

			$data['onload']='sub_group';
            $data['datas']=$this->stock_manage_model->sub_group_list();
            $data['message']=$this->data['message'];
            $data['data']=$this->data;
            $data['main_content']="stock_manage/sub_group";
        $this->load->view('template', $data);
			//$this->load->view('admin/index', $this->data);
		}
	}
	
	
		//create a new user
	function create_sub_group()
	{
		$this->data['title'] = "Create Sub Gtoup";

		if (!$this->session->userdata('identity'))
		{
			//redirect them to the login page
			redirect('admin/login', 'refresh');
		}

		$this->form_validation->set_rules('sub_group', 'Sub Group Name', 'required|xss_clean');
		$this->form_validation->set_rules('sub_group_code', 'Sub Group Code', 'required|xss_clean');
		

		if ($this->form_validation->run() == true)
		{		
			
			$data = array(
				'material_group' => $this->input->post('material_group'),
				'group_code'  => $this->input->post('group_code'),
				'sub_group' => $this->input->post('sub_group'),
				'sub_group_code' => $this->input->post('sub_group_code'),
				'active'  => 1,
				'insert_by'    => $this->session->userdata('email'),
				'create_date'    => date('Y-m-d')
			);
			   
			  $this->stock_manage_model->createSubGroup($data);
				  
					redirect('stock_manage/sub_group', 'refresh');
			
		} else {	 
			    
		
		$data['groups'] = $this->stock_manage_model->group_list();
		
		$this->load->view('stock_manage/create_sub_group',$data);	
		
		} 	
	
	}
	
	
//activate the user
	function activate_sub($id)
	{

			$activation = $this->stock_manage_model->activateSub($id);
		
                    redirect('stock_manage', 'refresh');
	}
	
	
	//deactivate the user
	function deactivate_sub($id )
	{
		$this->stock_manage_model->deactivateSub($id);

			//redirect them back to the admin page
			redirect('stock_manage', 'refresh');	
	}

	
	
	function sub_group_del($id){
	  	
	$this->stock_manage_model->sub_group_del($id);
	
	redirect('stock_manage/sub_group');
	
	}
	
	function edit_sub_group($id)
	{
		$data['id']=$id;  
	
		$data['editGroup']=$this->stock_manage_model->editSubGroup($id);  
		
		$data['groups'] = $this->stock_manage_model->group_list(); 
		
		$this->load->view('stock_manage/edit_sub_group',$data);	
	
	}
	
	
		
	function update_sub_group()
	{
		$this->data['title'] = "Edit Profile";

		if (!$this->session->userdata('identity'))
		{
			//redirect them to the login page
			redirect('admin/login', 'refresh');
		}

		//validate form input
		
			
			$data = array(
				'sub_group' => $this->input->post('sub_group'),
				'sub_group_code' => $this->input->post('sub_group_code'),
				'material_group' => $this->input->post('material_group'),
				'group_code'  => $this->input->post('group_code'),
				'active'  => 1,
				'update_by'    => $this->session->userdata('email'),
				'update_date'    => date('Y-m-d')
			);
			
			 $sg_id=$this->input->post('id');
			//print_r($data);

          	$this->stock_manage_model->updateSubGroup($sg_id,$data);
					
			redirect('stock_manage/sub_group', 'refresh');
			
		
		
	}

	
//*************************************SUB**Group********************************************************************	 

}
