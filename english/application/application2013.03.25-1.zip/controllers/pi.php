<?php defined('BASEPATH') OR exit('No direct script access allowed');

class Pi extends CI_Controller {

	function __construct()
	{
		parent::__construct();
		
		$this->load->model('pi_model');
		$this->load->model('stock_manage_model');
	}

	//redirect if needed, otherwise display the user list
	function index()
	{

		if (!$this->ion_auth->logged_in())
		{
			//redirect them to the login page
			redirect('admin/login', 'refresh');
		}
		elseif (!($this->session->userdata('pi') == 1)&&(!($this->session->userdata('sa') == 1)))
		{
			//redirect them to the home page because they must be an administrator to view this
			redirect($this->config->item('base_url'), 'refresh');
		} else

		{
			//set the flash data error message if there is one
			$this->data['message'] = (validation_errors()) ? validation_errors() : $this->session->flashdata('message');

			//list the users
			$this->data['users'] = $this->ion_auth->users()->result();
			foreach ($this->data['users'] as $k => $user)
			{
				$this->data['users'][$k]->groups = $this->ion_auth->get_users_groups($user->id)->result();
			}

			$data['onload']='pi';
            $data['pis']=$this->pi_model->pi_list();
            $data['message']=$this->data['message'];
            $data['main_content']="pi/index";
			
        	$this->load->view('template', $data);
			//$this->load->view('admin/index', $this->data);
		}
	}
	
	//create a new user
	function create_pi()
	{
		
		$data['groups'] = $this->stock_manage_model->group_list();	
	    $data['sub_groups'] = $this->stock_manage_model->sub_group_list();
	
			
		$this->load->view('pi/create_pi',$data);	
		
	
	}
	
	//create a insert Purchase Invoice
	function insert_pi()
	{
		

		if (!$this->session->userdata('identity'))
		{
			//redirect them to the login page
			redirect('admin/login', 'refresh');
		}

			
			$purchase_invoice = array(
			    'pi_number' 	=> $this->input->post('pi_number'),
				'supplier_name' 	=> $this->input->post('supplier_name'),
				'supplier_code' 	=> $this->input->post('supplier_code'),
				'total_price' 			=> $this->input->post('total_price'),
				'insert_by' 		=> $this->session->userdata('email'),			
				'invoice_date'   	=> date('Y-m-d')
			);
			
	
				$material_name 		= $this->input->post('material_name1');
				$material_code	 	= $this->input->post('material_code1');
				$sub_group			= $this->input->post('sub_group1');
				$material_group 	= $this->input->post('material_group1');
				$measurement_unit	= $this->input->post('measurement_unit1');
				$material_qty 		= $this->input->post('material_qty1');
				$unit_price			= $this->input->post('unit_price1');
				$net_price			= $this->input->post('net_price1');
	
		
			
			    $this->pi_model->createPi($purchase_invoice, $material_name, $material_code, $sub_group, $material_group, $measurement_unit, $material_qty, $unit_price, $net_price);
	
				  
					redirect('pi','refresh');
			
	
	}
	
//activate the user
	function activate($id)
	{

			$activation = $this->pi_model->activate($id);
		
                    redirect('pi', 'refresh');
	}
	
	
	
	//deactivate the user
	function deactivate($id )
	{
		$this->pi_model->deactivate($id);

			//redirect them back to the admin page
			redirect('pi', 'refresh');	
	}

	

	function pi_del($id){
	  	
	$this->pi_model->user_del($id);
	
	redirect('pi');
	
	}
	
	function preview_pi($dataIn)
	{
		$data['id']=$dataIn;  
	
		$data['previewData']=$this->pi_model->previewPi($dataIn);
		
		$data['supplierInfo'] = $this->pi_model->supplierInfo($dataIn);
		
		//print_r($data['previewData']);
		
		$this->load->view('pi/preview_pi',$data);	
	
	}
	
	
		
	function update_pi()
	{
		

		if (!$this->session->userdata('identity'))
		{
			//redirect them to the login page
			redirect('admin/login', 'refresh');
		}

		//validate form input
			
			$data = array(
 				'supplier_name' 	=> $this->input->post('supplier_name'),
				'customer_code' 	=> $this->input->post('customer_code'),
				'address' 			=> $this->input->post('address'),
				'phone' 			=> $this->input->post('phone'),
				'email'				=> $this->input->post('email'),
				'update_date' 		=> date('Y-m-d'),
				'update_by'   		=> $this->session->userdata('email')
			);
			
			 $s_id=$this->input->post('id');
			//print_r($data);

          	$this->pi_model->updateSupplier($s_id,$data);
					
			redirect('pi', 'refresh');
			
		
		
	}
	
	function ajaxData()
        {
		//$idSelect = $_REQUEST['idSelect'];
		$idSelect =$this->input->get('q');
       // $idSelect = mysql_real_escape_string(trim($idSelect));
		
            $this->pi_model->ajaxData($idSelect);
        }
		
			
	function supplierCodeTrigger()
	{
	
	$g=$this->input->get('supplierName');
	
	echo $g;
	
					if($g!='')
					{	
					
					
					$data['supplierCode'] = $this->pi_model->supplier_code($g);
					
					if ($data['supplierCode']!=0){
				
					//echo $data['groupcode'][0]->code;
					
					$this->load->view('pi/supplierCodeTrigger',$data);
					
					}else
							{
							echo 'fail';
							}
					
					} else
							{
							echo 'fail';
							}
			} 
			
		function materialAc()
		{
		//$idSelect = $_REQUEST['idSelect'];
		$idSelect =$this->input->get('q');
	   // $idSelect = mysql_real_escape_string(trim($idSelect));
		
			$this->pi_model->materialAc($idSelect);
			
				
        }
		
	function materialNameTrigger()
	{
	
	$g=$this->input->get('dataName');
	
	
		
	$data['materialName'] = $this->pi_model->material_name($g);

	//echo $data['groupcode'][0]->code;
	
	$this->load->view('pi/materialNameTrigger',$data);
	} 
	
//**********************************************PI Return*****************************************		
	
		function piNumberCheck()
	{
	
	$g=$this->input->get('dataName');
		
	$data = $this->pi_model->pi_number_check($g);

	echo $data;
	

	} 
	
		function pi_return()
	{
		
		/*$data['groups'] = $this->stock_manage_model->group_list();	
	    $data['sub_groups'] = $this->stock_manage_model->sub_group_list();*/
	
			
		$this->load->view('pi/pi_return');	
		
	
	}
	

		function piTrigger()
	{
	
	$g=$this->input->get('dataName');
		
	$data['pi_m_list'] = $this->pi_model->pi_m_list($g);

	//echo $data;
	
	$this->load->view('pi/piList',$data);
	} 
	
		//create a insert Purchase Invoice
	function pi_return_update()
	{
		


			
			 //$pi_number	= $this->input->post('pi_number');
			 
					
				$supplier_name 			= $this->input->post('supplier_name');
				$supplier_code			= $this->input->post('supplier_code');	
				$material_name 			= $this->input->post('material_name');
				$material_code	 		= $this->input->post('material_code');
				$material_qty_main 		= $this->input->post('material_qty_main');
				$material_qty 			= $this->input->post('material_qty');
				$unit_price				= $this->input->post('unit_price');
				$net_price				= $this->input->post('net_price');
				
				$sub_group			= $this->input->post('sub_group');
				$material_group 	= $this->input->post('material_group');
				$measurement_unit	= $this->input->post('measurement_unit');
				$invoice_date	= $this->input->post('invoice_date');
				
				
				
				//$return_qty=($material_qty_main-$material_qty);
				
				
				$data = array(
							'pi_number' 	=> $this->input->post('pi_number'),
							'comment' 	=>   'pi Return',
							'update_date' 		=> date('Y-m-d'),
							'update_by'   		=> $this->session->userdata('email')
						);
	
			
			
			    $this->pi_model->piReturnUpdate( $data, $supplier_name, $supplier_code, $material_name, $material_code, $material_qty_main, $material_qty, $unit_price, $net_price, $sub_group, $material_group, $measurement_unit, $invoice_date );
	
				  
					redirect('pi','refresh');
			
	
	}	
	
	
			function suMaterialQty()
	{
	
	$g=$this->input->get('dataName');
		
	$data = $this->pi_model->su_material_qty($g);

	//print_r($data);
	echo $data[0]->material_qty;

	} 
	
	

} //End of Class
