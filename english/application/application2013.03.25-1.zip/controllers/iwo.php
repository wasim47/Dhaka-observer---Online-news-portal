<?php defined('BASEPATH') OR exit('No direct script access allowed');

class Iwo extends CI_Controller {

	function __construct()
	{
		parent::__construct();
		
		$this->load->model('iwo_model');
		$this->load->model('stock_manage_model');
	}

	//redirect if needed, otherwise display the user list
	function index()
	{

		if (!$this->ion_auth->logged_in())
		{
			//redirect them to the login page
			redirect('admin/login', 'refresh');
		}
		elseif (!($this->session->userdata('pi') == 1)&&(!($this->session->userdata('sa') == 1)))
		{
			//redirect them to the home page because they must be an administrator to view this
			redirect($this->config->item('base_url'), 'refresh');
		} else

		{
			//set the flash data error message if there is one
			$this->data['message'] = (validation_errors()) ? validation_errors() : $this->session->flashdata('message');

			//list the users
			$this->data['users'] = $this->ion_auth->users()->result();
			foreach ($this->data['users'] as $k => $user)
			{
				$this->data['users'][$k]->groups = $this->ion_auth->get_users_groups($user->id)->result();
			}

			$data['onload']='iwo';
            $data['iwos']=$this->iwo_model->iwo_list();
            $data['message']=$this->data['message'];
            $data['main_content']="iwo/index";
        $this->load->view('template', $data);
			
		}
	}
	
	//create a new user
	function create_iwo()
	{
		
		$data['groups'] = $this->stock_manage_model->group_list();	
	    $data['sub_groups'] = $this->stock_manage_model->sub_group_list();
	
			
		$this->load->view('iwo/create_iwo',$data);	
		
	
	}
	
	//create a insert Purchase Invoice
	function insert_iwo()
	{
		

		if (!$this->session->userdata('identity'))
		{
			//redirect them to the login page
			redirect('admin/login', 'refresh');
		}

			
			$iwo = array(
				'client_name' 			=> $this->input->post('client_name'),
				'po_number' 			=> $this->input->post('po_number'),
				'client_email' 			=> $this->input->post('client_email'),				
				'contact_person_name' 	=> $this->input->post('contact_person_name'),
				'contact_person_phone' 	=> $this->input->post('contact_person_phone'),
				'printing_po_number' 	=> $this->input->post('printing_po_number'),
				'factory_name' 			=> $this->input->post('factory_name'),
				'comment' 				=> $this->input->post('comment'),
				'deliveryDate' 			=> $this->input->post('deliveryDate'),
				'issued_by' 			=> $this->session->userdata('email'),	
				'issued_to' 			=> $this->input->post('issued_to'),	
				'gtotal_quantity' 		=> $this->input->post('gtotal_quantity'),				
				'iwoDate' 				=> date('Y-m-d')
			);
			
	
				$product_description 		= $this->input->post('product_description');
				$measurement_size	 	= $this->input->post('measurement_size');
				$product_quantity			= $this->input->post('product_quantity');
				$total_quantity			= $this->input->post('total_quantity');
				
			
			    $this->iwo_model->createIwo($iwo, $product_description, $measurement_size, $product_quantity, $total_quantity);
	
				  
					redirect('iwo','refresh');
			
	
	}
	
//activate the user
	function activate($id)
	{

			$activation = $this->iwo_model->activate($id);
		
                    redirect('iwo', 'refresh');
	}
	
	
	
	//deactivate the user
	function deactivate($id )
	{
		$this->iwo_model->deactivate($id);

			//redirect them back to the admin page
			redirect('iwo', 'refresh');	
	}

	

	function iwo_del($id){
	  	
	$this->iwo_model->user_del($id);
	
	redirect('iwo');
	
	}
	
	function preview_iwo($dataIn)
	{
		$data['id']=$dataIn;  
	
		$data['previewData']=$this->iwo_model->previewIwo($dataIn);
		
		$data['clientInfo'] = $this->iwo_model->clientInfo($dataIn);
		
		//print_r($data['previewData']);
		
		$this->load->view('iwo/preview_iwo',$data);	
	
	}
	
	
		
	function update_iwo()
	{
		

		if (!$this->session->userdata('identity'))
		{
			//redirect them to the login page
			redirect('admin/login', 'refresh');
		}

		//validate form input
		
			
			$data = array(
 				'supplier_name' 	=> $this->input->post('supplier_name'),
				'customer_code' 	=> $this->input->post('customer_code'),
				'address' 			=> $this->input->post('address'),
				'phone' 			=> $this->input->post('phone'),
				'email'				=> $this->input->post('email'),
				'update_date' 		=> date('Y-m-d'),
				'update_by'   		=> $this->session->userdata('email')
			);
			
			 $s_id=$this->input->post('id');
			//print_r($data);

          	$this->iwo_model->updateSupplier($s_id,$data);
					
			redirect('iwo', 'refresh');
			
		
		
	}
	
	function clientACName()
        {
		//$idSelect = $_REQUEST['idSelect'];
		$idSelect =$this->input->get('q');
       // $idSelect = mysql_real_escape_string(trim($idSelect));
		
            $this->iwo_model->client_autocomplete_name($idSelect);
        }
		
			
	function clientInfoTrigger()
	{
	
	$g=$this->input->get('dataName');
	
					if($g!='')
					{	
					
					
					$data['clientInfo'] = $this->iwo_model->client_info($g);
					
					if ($data['clientInfo']!=0){
				
					//echo $data['groupcode'][0]->code;
					
					$this->load->view('iwo/clientInfoTrigger',$data);
					
					}else
							{
							echo 'fail';
							}
					
					} else
							{
							echo 'fail';
							}
			} 
			
			
			
			
		function materialAc()
		{
		//$idSelect = $_REQUEST['idSelect'];
		$idSelect =$this->input->get('q');
	   // $idSelect = mysql_real_escape_string(trim($idSelect));
		
			$this->iwo_model->materialAc($idSelect);
			
				
        }
		
	function contactInfoTrigger()
	{
	
	$g=$this->input->get('dataName');
	
	
		
	$data['contact_person_list'] = $this->iwo_model->contact_name($g);

	//echo $data['groupcode'][0]->code;
	
	$this->load->view('iwo/contact_person_list',$data);
	} 
	
	
	
		function iwoNumberCheck()
	{
	
	$g=$this->input->get('dataName');
		
	$data = $this->iwo_model->iwo_number_check($g);

	echo $data;
	
	//$this->load->view('iwo/materialNameTrigger',$data);
	} 
	
	

} //End of Class
