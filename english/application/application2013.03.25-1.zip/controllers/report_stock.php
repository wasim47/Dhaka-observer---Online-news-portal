<?php defined('BASEPATH') OR exit('No direct script access allowed');

class Report_stock extends CI_Controller {

	function __construct()
	{
		parent::__construct();
		
		$this->load->model('report_stock_model');
		$this->load->model('stock_manage_model');
		$this->load->model('pi_model');
	}

	//redirect if needed, otherwise display the user list
	function index()
	{

		if (!$this->ion_auth->logged_in())
		{
			//redirect them to the login page
			redirect('admin/login', 'refresh');
		}
		
		elseif (!($this->session->userdata('sm') == 1)&&(!($this->session->userdata('sa') == 1)))
		{
			//redirect them to the home page because they must be an administrator to view this
			redirect($this->config->item('base_url'), 'refresh');
		} else

		{
			//set the flash data error message if there is one
			$this->data['message'] = (validation_errors()) ? validation_errors() : $this->session->flashdata('message');

			//list the users
			$this->data['users'] = $this->ion_auth->users()->result();
			foreach ($this->data['users'] as $k => $user)
			{
				$this->data['users'][$k]->groups = $this->ion_auth->get_users_groups($user->id)->result();
			}

			$data['onload']='Material_report';
            $data['datas']=$this->report_stock_model->report_stock_list();
            $data['message']=$this->data['message'];
            $data['data']=$this->data;
            $data['main_content']="report_stock/index";
        $this->load->view('template_report', $data);
			//$this->load->view('admin/index', $this->data);
		}
	}
	
	
	//redirect if needed, otherwise display the user list
	function ledger()
	{



			$data['onload']='stock_update';
            $data['datas']=$this->report_stock_model->report_stock_dateList();
            $data['message']=$this->data['message'];
            $data['main_content']="report_stock/ledger";
        $this->load->view('template_report', $data);
			//$this->load->view('admin/index', $this->data);
		
	}	
	

	
	
	
		function piTrigger()
	{
	
	$g=$this->input->get('dataName');
		
	$data['pi_m_list'] = $this->pi_model->pi_m_list($g);

	//echo $data;
	
	$this->load->view('stock_update/piList',$data);
	
	} 
	
	
	function materialNameTrigger()
	{
	
	$g=$this->input->get('dataName');
		
	$data['m_list'] = $this->report_stock_model->material_name_trigger($g);

	$data['unit_price_avg'] = $this->report_stock_model->avg_price_trigger($g);
	
	$this->load->view('report_stock/mList',$data);
	} 
	

	
		function materialAc()
		{
		
		$idSelect =$this->input->get('q');
		
			$this->pi_model->materialAc($idSelect);
			
				
        }
	
	
		function piNumberCheck()
	{
	
	$g=$this->input->get('dataName');
		
	$data = $this->stock_update_model->pi_number_check($g);

	echo $data;
	
	//$this->load->view('pi/materialNameTrigger',$data);
	} 

###################################ISSUE###REPORT###############################################################
	function issue()
	{



			$data['onload']='issue';
            //$data['datas']=$this->report_stock_model->issue_report_stock_list();
            $data['main_content']="report_stock/issue";
			
        $this->load->view('template_report', $data);
			
		
	}	

	function issueNameByDate()
	{
	
	$g=$this->input->get('dataName');
		
	$data['m_list'] = $this->report_stock_model->issue_name_by_date($g);

	$data['unit_price_avg'] = $this->report_stock_model->avg_price_trigger($g);
	
	$this->load->view('report_stock/issueMaterialList',$data);
	} 	
	
###################################ISSUE###REPORT###############################################################


###################################RECEIVE###REPORT###############################################################
	function receive()
	{



			$data['onload']='receive';
           // $data['datas']=$this->report_stock_model->report_stock_list();
            $data['main_content']="report_stock/receive";
			
        $this->load->view('template_report', $data);
			
		
	}	
	

	function reveiveNameByDate()
	{
	
	$g=$this->input->get('dataName');
		
	$data['m_list'] = $this->report_stock_model->receive_name_by_date($g);

	//$data['unit_price_avg'] = $this->report_stock_model->avg_price_trigger($g);
	
	$this->load->view('report_stock/receiveMaterialList',$data);
	} 	
	
###################################RECEIVE###REPORT###############################################################


###################################totalStock###REPORT###############################################################
	function total_stock()
	{



			$data['onload']='total_stock';
            //$data['datas']=$this->report_stock_model->issue_report_stock_list();
            $data['main_content']="report_stock/total_stock";
			
        $this->load->view('template_report', $data);
			
		
	}	

	function totalStockNameByDate()
	{
	
	$g=$this->input->get('dataName');
		
	$data['m_list'] = $this->report_stock_model->totalStock_name_by_date($g);

	//$data['unit_price_avg'] = $this->report_stock_model->avg_price_trigger($g);
	
	$this->load->view('report_stock/totalStockMaterialList',$data);
	} 	
	
###################################totalStock###REPORT###############################################################

###################################Work Order###REPORT###############################################################
	function wo()
	{



			$data['onload']='total_stock';
            //$data['datas']=$this->report_stock_model->issue_report_stock_list();
            $data['main_content']="report_stock/wo";
			
        $this->load->view('template_report', $data);
			
		
	}	

	function woNameTrigger()
	{
	
	$g=$this->input->get('dataName');
		
	$data['m_list'] = $this->report_stock_model->wo_nameTrigger($g);

	//$data['unit_price_avg'] = $this->report_stock_model->avg_price_trigger($g);
	
	$this->load->view('report_stock/woMaterialList',$data);
	} 	
	
###################################Work Order###REPORT###############################################################


###################################groupStock###REPORT###############################################################
	function group()
	{



			$data['onload']='group_stock';
            //$data['datas']=$this->report_stock_model->issue_report_stock_list();
            $data['main_content']="report_stock/group_stock";
			
        $this->load->view('template_report', $data);
			
		
	}	

	function groupStockNameByDate()
	{
	
	$g=$this->input->get('dataName');
		
	$data['m_list'] = $this->report_stock_model->groupStock_name_by_date($g);

	//$data['unit_price_avg'] = $this->report_stock_model->avg_price_trigger($g);
	
	$this->load->view('report_stock/groupStockMaterialList',$data);
	} 	
	
###################################groupStock###REPORT###############################################################
}/***** End of CLASS stock  Update  controller  *****/ 
