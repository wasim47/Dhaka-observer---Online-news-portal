<?php defined('BASEPATH') OR exit('No direct script access allowed');

class Supplier_manage extends CI_Controller {

	function __construct()
	{
		parent::__construct();
		
		$this->load->model('supplier_manage_model');
		$this->load->model('stock_manage_model');
	}

	//redirect if needed, otherwise display the user list
	function index()
	{

		if (!$this->ion_auth->logged_in())
		{
			//redirect them to the login page
			redirect('admin/login', 'refresh');
		}
		elseif (!($this->session->userdata('sm') == 1)&&(!($this->session->userdata('sa') == 1)))
		{
			//redirect them to the home page because they must be an administrator to view this
			redirect($this->config->item('base_url'), 'refresh');
		} else

		{
			//set the flash data error message if there is one
			$this->data['message'] = (validation_errors()) ? validation_errors() : $this->session->flashdata('message');

			//list the users
			$this->data['users'] = $this->ion_auth->users()->result();
			foreach ($this->data['users'] as $k => $user)
			{
				$this->data['users'][$k]->groups = $this->ion_auth->get_users_groups($user->id)->result();
			}

			$data['onload']='supplier_manage';
            $data['suppliers']=$this->supplier_manage_model->supplier_list();
            $data['message']=$this->data['message'];
            $data['main_content']="supplier_manage/index";
        $this->load->view('template', $data);
			//$this->load->view('admin/index', $this->data);
		}
	}
	
	//create a new user
	function create_supplier()
	{
		
		$data['groups'] = $this->stock_manage_model->group_list();	
	    $data['sub_groups'] = $this->stock_manage_model->sub_group_list();
	
			
		$this->load->view('supplier_manage/create_supplier',$data);	
		
	
	}
	
	//create a new user
	function insert_supplier()
	{
		

		if (!$this->session->userdata('identity'))
		{
			//redirect them to the login page
			redirect('admin/login', 'refresh');
		}

			
			$data = array(
			    'supplier_name' 	=> $this->input->post('supplier_name'),
				'supplier_code' 	=> $this->input->post('supplier_code'),
				'address' 			=> $this->input->post('address'),
				'phone' 			=> $this->input->post('phone'),
				'email'				=> $this->input->post('email'),
				'active'			=> 1 ,
				'insert_by' 		=> $this->session->userdata('email'),			
				'create_date'   	=> date('Y-m-d')
			);
			    $this->supplier_manage_model->createSupplier($data);
	
				  
					redirect('supplier_manage', 'refresh');
			
	
	}
	
//activate the user
	function activate($id)
	{

			$activation = $this->supplier_manage_model->activate($id);
		
                    redirect('supplier_manage', 'refresh');
	}
	
	
	
	//deactivate the user
	function deactivate($id )
	{
		$this->supplier_manage_model->deactivate($id);

			//redirect them back to the admin page
			redirect('supplier_manage', 'refresh');	
	}

	

	function supplier_del($id){
	  	
	$this->supplier_manage_model->user_del($id);
	
	redirect('supplier_manage');
	
	}
	
	function edit_supplier($id)
	{
		$data['id']=$id;  
	
		$data['editData']=$this->supplier_manage_model->editSupplier($id);
		
		//$data['groups'] = $this->stock_manage_model->group_list();	
	    $data['sub_groups'] = $this->stock_manage_model->sub_group_list();
		
		$this->load->view('supplier_manage/edit_supplier',$data);	
	
	}
	
	
		
	function update_supplier()
	{
		

		if (!$this->session->userdata('identity'))
		{
			//redirect them to the login page
			redirect('admin/login', 'refresh');
		}

		//validate form input
		
			
			$data = array(
 				'supplier_name' 	=> $this->input->post('supplier_name'),
				'supplier_code' 	=> $this->input->post('supplier_code'),
				'address' 			=> $this->input->post('address'),
				'phone' 			=> $this->input->post('phone'),
				'email'				=> $this->input->post('email'),
				'update_date' 		=> date('Y-m-d'),
				'update_by'   		=> $this->session->userdata('email')
			);
			
			 $s_id=$this->input->post('id');
			//print_r($data);

          	$this->supplier_manage_model->updateSupplier($s_id,$data);
					
			redirect('supplier_manage', 'refresh');
			
		
		
	}


	 

} //End of Class
