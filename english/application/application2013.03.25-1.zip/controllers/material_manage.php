<?php defined('BASEPATH') OR exit('No direct script access allowed');

class Material_manage extends CI_Controller {

	function __construct()
	{
		parent::__construct();
		
		$this->load->model('material_manage_model');
		$this->load->model('stock_manage_model');
	}

	//redirect if needed, otherwise display the user list
	function index()
	{

		if (!$this->ion_auth->logged_in())
		{
			//redirect them to the login page
			redirect('admin/login', 'refresh');
		}
		elseif (!($this->session->userdata('sm') == 1)&&(!($this->session->userdata('sa') == 1)))
		{
			//redirect them to the home page because they must be an administrator to view this
			redirect($this->config->item('base_url'), 'refresh');
		} else

		{
			//set the flash data error message if there is one
			$this->data['message'] = (validation_errors()) ? validation_errors() : $this->session->flashdata('message');

			//list the users
			$this->data['users'] = $this->ion_auth->users()->result();
			foreach ($this->data['users'] as $k => $user)
			{
				$this->data['users'][$k]->groups = $this->ion_auth->get_users_groups($user->id)->result();
			}

			$data['onload']='material_manage';
            $data['materials']=$this->material_manage_model->material_list();
            $data['message']=$this->data['message'];
            $data['data']=$this->data;
            $data['main_content']="material_manage/index";
        $this->load->view('template', $data);
			//$this->load->view('admin/index', $this->data);
		}
	}
	
	//create a new user
	function create_material()
	{
		
		$data['groups'] = $this->stock_manage_model->group_list();	
	    $data['sub_groups'] = $this->stock_manage_model->sub_group_list();
	
			
		$this->load->view('material_manage/create_material',$data);	
		
	
	}
	
	//create a new user
	function insert_material()
	{
		

		if (!$this->session->userdata('identity'))
		{
			//redirect them to the login page
			redirect('admin/login', 'refresh');
		}

			
			$data = array(
			    'material_group' 	=> $this->input->post('groupName'),
				'group_code' 		=> $this->input->post('group_code'),
				'sub_group' 		=> $this->input->post('sub_group_name'),
				'sub_group_code' 	=> $this->input->post('sub_group_code'),
				'material_name'		=> $this->input->post('material_name'),
				'material_code'		=> $this->input->post('material_code'),
				'measurement_unit'	=> $this->input->post('measurement_unit'),
				'opening_qty'  		=> $this->input->post('opening_qty'),
				'opening_balance' 	=> $this->input->post('opening_balance'),
				'publish' 			=> $this->input->post('publish'),	
				'insert_by' 		=> $this->session->userdata('email'),			
				'create_date'   	=> date('Y-m-d')
			);
			    $this->material_manage_model->createMaterial($data);
	
				  
					redirect('material_manage', 'refresh');
			
		//} else {	
		
		//$this->load->view('material_manage',$data);	
		//} 	
	
	}
	
//activate the user
	function activate($id)
	{

			$activation = $this->material_manage_model->activate($id);
		
                    redirect('material_manage', 'refresh');
	}
	
	
	
	//deactivate the user
	function deactivate($id )
	{
		$this->material_manage_model->deactivate($id);

			//redirect them back to the admin page
			redirect('material_manage', 'refresh');	
	}

	

	function material_del($id){
	  	
	$this->material_manage_model->user_del($id);
	
	redirect('material_manage');
	
	}
	
	function edit_material($id)
	{
		$data['id']=$id;  
	
		$data['editData']=$this->material_manage_model->editMaterial($id);
		
		$data['groups'] = $this->stock_manage_model->group_list();	
	    $data['sub_groups'] = $this->stock_manage_model->sub_group_list();
		
		$this->load->view('material_manage/edit_material',$data);	
	
	}
	
	
		
	function update_material()
	{
		

		if (!$this->session->userdata('identity'))
		{
			//redirect them to the login page
			redirect('admin/login', 'refresh');
		}

		//validate form input
		
			
			$data = array(
				'material_group' => $this->input->post('groupName'),
				'group_code' => $this->input->post('group_code'),
				'sub_group'  => $this->input->post('sub_group_name'),
				'sub_group_code' => $this->input->post('sub_group_code'),
				'material_name'  => $this->input->post('material_name'),
				'material_code' => $this->input->post('material_code'),
				'measurement_unit'  => $this->input->post('measurement_unit'),
				'opening_qty' => $this->input->post('opening_qty'),
				'opening_balance'  => $this->input->post('opening_balance'),
				'update_date'  => date('Y-m-d'),
				'update_by'    => $this->session->userdata('email')
			);
			
			 $m_id=$this->input->post('id');
			//print_r($data);

          	$this->material_manage_model->updateMaterial($m_id,$data);
					
			redirect('material_manage', 'refresh');
			
		
		
	}
	
	function groupCodeSearch()
	{
	
	$g=$this->input->get('groupName');
	
	$data['groups'] = $this->stock_manage_model->group_list();
	
	if($g!='none'){
		
	$data['groupcode'] = $this->material_manage_model->group_code($g);

	}

	
	$this->load->view('material_manage/groupCodeMenu',$data);
	}
	
		
	function groupNameSearch()
	{
	
	$g=$this->input->get('groupCode');
	
	$data['groups'] = $this->stock_manage_model->group_list();
		
	if($g!='none'){
		
	$data['groupcode'] = $this->material_manage_model->group_name($g);

	}

	
	$this->load->view('material_manage/groupNameMenu',$data);
	}
	
	function groupCodeTrigger()
	{
	
	$g=$this->input->get('groupName');
	
	
		
	$data['groupcode'] = $this->material_manage_model->group_code($g);

	//echo $data['groupcode'][0]->code;
	
	$this->load->view('material_manage/groupCodeTrigger',$data);
	} 
	
	
		function subGroupCodeTrigger()
	{
	
	$g=$this->input->get('subGroupName');
	
	
		
	$data['subGroupcode'] = $this->material_manage_model->sub_group_code($g);

	//echo $data['groupcode'][0]->code;
	
	$this->load->view('material_manage/subGroupCodeTrigger',$data);
	} 
	
	//***********************sub group name,code****ajax*******************
	
	/*function subGroupCodeSearch()
	{
	
	$g=$this->input->get('subGroupName');
	
	$data['sub_groups'] = $this->stock_manage_model->sub_group_list();
			
	if($g!='none'){
		
	$data['sub_group_code'] = $this->material_manage_model->sub_group_code($g);
	
	}
	
	
	$this->load->view('material_manage/subGroupCodeMenu',$data);
	}
	
	
	function subGroupNameSearch()
	{
	
	$g=$this->input->get('subGroupCode');
	
	$data['sub_groups'] = $this->stock_manage_model->sub_group_list();
	
	
	
		
	if($g!='none'){
		
	$data['sub_group_name'] = $this->material_manage_model->sub_group_name($g);
	
	}
	
	
	$this->load->view('material_manage/subGroupNameMenu',$data);
	}*/
	
	function subGroup()
	{
	
	$g=$this->input->get('groupName');

	$data['sub_group'] = $this->material_manage_model->sub_group($g);
	
	$this->load->view('material_manage/subGroup',$data);
	}
	
	
	 

}
