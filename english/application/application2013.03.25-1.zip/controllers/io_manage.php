<?php defined('BASEPATH') OR exit('No direct script access allowed');

class Io_manage extends CI_Controller {

	function __construct()
	{
		parent::__construct();
		
		$this->load->model('io_manage_model');
		$this->load->model('stock_manage_model');
	}

	//redirect if needed, otherwise display the user list
	function index()
	{

		if (!$this->ion_auth->logged_in())
		{
			//redirect them to the login page
			redirect('admin/login', 'refresh');
		}
		elseif (!($this->session->userdata('io') == 1)&&(!($this->session->userdata('sa') == 1)))
		{
			//redirect them to the home page because they must be an administrator to view this
			redirect($this->config->item('base_url'), 'refresh');
		} else

		{
			//set the flash data error message if there is one
			$this->data['message'] = (validation_errors()) ? validation_errors() : $this->session->flashdata('message');

			//list the users
			$this->data['users'] = $this->ion_auth->users()->result();
			foreach ($this->data['users'] as $k => $user)
			{
				$this->data['users'][$k]->groups = $this->ion_auth->get_users_groups($user->id)->result();
			}

			$data['onload']='io';
            $data['ios']=$this->io_manage_model->io_list();
            $data['message']=$this->data['message'];
            $data['main_content']="io_manage/index";
			
        	$this->load->view('template', $data);
			//$this->load->view('admin/index', $this->data);
		}
	}
	
	//create a Issue Order
	function create_io()
	{
		$this->load->view('io_manage/create_io');	
	
	}
	
	
	
	//create a insert Issue Order
	function insert_io()
	{
		

		if (!$this->session->userdata('identity'))
		{
			//redirect them to the login page
			redirect('admin/login', 'refresh');
		}

			
			$issue_order = array(
			    'iwo_number' 	=> $this->input->post('iwo_number'),
				'gtotal' 		=> $this->input->post('gtotal_price'),
				'insert_by' 	=> $this->session->userdata('email'),			
				'io_date'   	=> date('Y-m-d')
			);
			
	
			    $iwo_number 		= $this->input->post('iwo_number1');
				$material_name 		= $this->input->post('material_name1');
				$material_code	 	= $this->input->post('material_code1');
				$sub_group			= $this->input->post('sub_group1');
				$material_group 	= $this->input->post('material_group1');
				$measurement_unit 	= $this->input->post('measurement_unit1');
				$material_qty 		= $this->input->post('material_qty1');
				$unit_price_avg 	= $this->input->post('unit_price_avg1');
				$total_price 		= $this->input->post('total_price1');
	

			
 $this->io_manage_model->createIo($issue_order, $iwo_number, $material_name, $material_code, $sub_group, $material_group,  $material_qty, $unit_price_avg,  $total_price, $measurement_unit );
	
				  
					redirect('io_manage','refresh');	
	}
	
##############################Issue order#####Local##############################################################################

//create a Issue Order local
	function create_io_local()
	{
	
	$this->load->view('io_manage/create_io_local');	

	}	
	
	//create a insert Issue Order
	function insert_io_local()
	{
		
		if (!$this->session->userdata('identity'))
		{
			//redirect them to the login page
			redirect('admin/login', 'refresh');
		}

			$issue_order = array(
			    'local' 	=> '1',
				'gtotal' 		=> $this->input->post('gtotal_price'),
				'insert_by' 	=> $this->session->userdata('email'),			
				'io_date'   	=> date('Y-m-d')
			);
			

				$material_name 		= $this->input->post('material_name1');
				$material_code	 	= $this->input->post('material_code1');
				$sub_group			= $this->input->post('sub_group1');
				$material_group 	= $this->input->post('material_group1');
				$measurement_unit 	= $this->input->post('measurement_unit1');
				$material_qty 		= $this->input->post('material_qty1');
				$unit_price_avg 	= $this->input->post('unit_price_avg1');
				$total_price 		= $this->input->post('total_price1');
	

			
 $this->io_manage_model->createIoLocal($issue_order, $material_name, $material_code, $sub_group, $material_group,  $material_qty, $unit_price_avg,  $total_price, $measurement_unit );
	
				  
					redirect('io_manage','refresh');
	}
	

##############################End###Issue##Order###Local#########################################################################


	

	function io_del($id){
	  	
	$this->io_manage_model->user_del($id);
	
	redirect('io_manage');
	
	}
	
	function preview_io($dataIn)
	{
		$data['id']=$dataIn;  
	
		$data['previewData']=$this->io_manage_model->previewIo($dataIn);
		
		$data['ioInfo'] = $this->io_manage_model->ioInfo($dataIn);
		
		//print_r($data['previewData']);
		
		$this->load->view('io_manage/preview_io',$data);	
	
	}
	
	
		

				
		function materialAc()
		{
		//$idSelect = $_REQUEST['idSelect'];
		$idSelect =$this->input->get('q');
	   // $idSelect = mysql_real_escape_string(trim($idSelect));
		
			$this->io_manage_model->materialAc($idSelect);
			
				
        }
		
	function materialNameTrigger()
	{
	
	$g=$this->input->get('dataName');
	
	
		
	$data['materialName'] = $this->io_manage_model->material_name($g);

	//echo $data['groupcode'][0]->code;
	
	$this->load->view('io_manage/materialNameTrigger',$data);
	} 
	
	
	
		function iwoNumberCheck()
	{
	
	$g=$this->input->get('dataName');
		
	$data = $this->io_manage_model->iwo_number_check($g);

	echo $data;
	
	
	} 
	//**********************************************IO Return*****************************************	
	
		
		function ioNumberCheck()
	{
	
	$g=$this->input->get('dataName');
		
	$data = $this->io_manage_model->io_number_check($g);

	echo $data;
	

	} 
	
		function io_return()
	{
		
		/*$data['groups'] = $this->stock_manage_model->group_list();	
	    $data['sub_groups'] = $this->stock_manage_model->sub_group_list();*/
	
			
		$this->load->view('io_manage/io_return');	
		
	
	}
	
		function ioTrigger()
	{
	
	$g=$this->input->get('dataName');
		
	$data['io_m_list'] = $this->io_manage_model->io_m_list($g);

	//echo $data;
	
	$this->load->view('io_manage/ioList',$data);
	} 
	
		//create a insert Purchase Invoice
	function io_return_update()
	{
		


			
			    //$io_number				= $this->input->post('io_number');	
				
				$iwo_number				= $this->input->post('iwo_number');
				$material_name 			= $this->input->post('material_name');
				$material_code	 		= $this->input->post('material_code');
				$material_group 		= $this->input->post('material_group');
				$material_qty_main 		= $this->input->post('material_qty_main');
				$material_qty 			= $this->input->post('material_qty');
				$unit_price_avg			= $this->input->post('unit_price');
				$total_price			= $this->input->post('total_price');
				
				$sub_group			= $this->input->post('sub_group');
				$measurement_unit	= $this->input->post('measurement_unit');
				$io_date	= $this->input->post('io_date');
				$local	= $this->input->post('local');
				
				
				//$return_qty=($material_qty_main-$material_qty);
				
				
				$data = array(
							'local' 		=> $local[0],
							'io_number' 		=> $this->input->post('io_number'),
							'comment' 			=>   'io Return',
							'update_date' 		=> date('Y-m-d'),
							'update_by'   		=> $this->session->userdata('email')
						);
	
			
			
			    $this->io_manage_model->ioReturnUpdate( $data, $iwo_number, $material_name, $material_code, $material_group, $material_qty_main, $material_qty, $unit_price_avg, $total_price, $sub_group, $measurement_unit, $io_date, $local );
	
				  
					redirect('io_manage','refresh');
			
	
	}	
	
	
	
	
	
	

} //End of Class
