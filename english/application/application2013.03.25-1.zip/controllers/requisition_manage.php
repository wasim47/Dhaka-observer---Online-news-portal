<?php defined('BASEPATH') OR exit('No direct script access allowed');

class Requisition_manage extends CI_Controller {

	function __construct()
	{
		parent::__construct();
		
		$this->load->model('requisition_manage_model');
		$this->load->model('stock_manage_model');
	}

	//redirect if needed, otherwise display the user list
	function index()
	{

		if (!$this->ion_auth->logged_in())
		{
			//redirect them to the login page
			redirect('admin/login', 'refresh');
		}
		elseif (!($this->session->userdata('io') == 1)&&(!($this->session->userdata('sa') == 1)))
		{
			//redirect them to the home page because they must be an administrator to view this
			redirect($this->config->item('base_url'), 'refresh');
		} else

		{
			//set the flash data error message if there is one
			$this->data['message'] = (validation_errors()) ? validation_errors() : $this->session->flashdata('message');

			//list the users
			$this->data['users'] = $this->ion_auth->users()->result();
			foreach ($this->data['users'] as $k => $user)
			{
				$this->data['users'][$k]->groups = $this->ion_auth->get_users_groups($user->id)->result();
			}

			$data['onload']='requisition_manage';
            $data['ios']=$this->requisition_manage_model->requisition_list();
            $data['message']=$this->data['message'];
            $data['main_content']="requisition_manage/index";
			
        	$this->load->view('template', $data);
			//$this->load->view('admin/index', $this->data);
		}
	}
	
	//create a Issue Order
	function create_requisition()
	{
		$this->load->view('requisition_manage/create_requisition');	
	
	}
	
	
	
	//create a insert Issue Order
	function insert_requisition()
	{
		

		if (!$this->session->userdata('identity'))
		{
			//redirect them to the login page
			redirect('admin/login', 'refresh');
		}

			
			$requisition = array(
				'requisitors_name' 	=> $this->session->userdata('email'),	
				'delivery_location' 	=> $this->input->post('delivery_location'),		
				'delivery_date' 	=> $this->input->post('delivery_date'),			
				'r_date'   	=> date('Y-m-d')
			);
			
	
			    $iwo_number 		= $this->input->post('iwo_number1');
				$material_name 		= $this->input->post('material_name1');
				$material_code	 	= $this->input->post('material_code1');
				$size				= $this->input->post('size1');
				$material_qty 		= $this->input->post('material_qty1');
				$measurement_unit 	= $this->input->post('measurement_unit1');
				$comment		 	= $this->input->post('comment1');
	

			
 $this->requisition_manage_model->createRequisition($requisition, $iwo_number, $material_name, $material_code, $size,  $material_qty, $measurement_unit, $comment );
	
				  
					redirect('requisition_manage','refresh');	
	}
	

	

	function requisition_del($id){
	  	
	$this->requisition_manage_model->requisition_del($id);
	
	redirect('requisition_manage');
	
	}
	
	function preview_requisition($id)
	{
		$data['id']=$id;  
	
		$data['previewData']=$this->requisition_manage_model->previewRequisition($id);
		
		$data['requisitionInfo'] = $this->requisition_manage_model->requisitionInfo($id);
		
		//print_r($data['previewData']);
		
		$this->load->view('requisition_manage/preview_requisition',$data);	
	
	}
	
	
		

				
		function materialAc()
		{
		//$idSelect = $_REQUEST['idSelect'];
		$idSelect =$this->input->get('q');
	   // $idSelect = mysql_real_escape_string(trim($idSelect));
		
			$this->requisition_manage_model->materialAc($idSelect);
			
				
        }
		
	function materialNameTrigger()
	{
	
	$g=$this->input->get('dataName');
	
	
		
	$data['materialName'] = $this->requisition_manage_model->material_name($g);

	//echo $data['groupcode'][0]->code;
	
	$this->load->view('requisition_manage/materialNameTrigger',$data);
	} 
	
	
	
		function iwoNumberCheck()
	{
	
	$g=$this->input->get('dataName');
		
	$data = $this->requisition_manage_model->iwo_number_check($g);

	echo $data;
	
	
	} 
	//**********************************************requisition Return*****************************************	
	
		
		function requisitionNumberCheck()
	{
	
	$g=$this->input->get('dataName');
		
	$data = $this->requisition_manage_model->requisition_number_check($g);

	echo $data;
	

	} 
	
		function requisition_return()
	{
		
		/*$data['groups'] = $this->stock_manage_model->group_list();	
	    $data['sub_groups'] = $this->stock_manage_model->sub_group_list();*/
	
			
		$this->load->view('requisition_manage/requisition_return');	
		
	
	}
	
		function requisitionTrigger()
	{
	
	$g=$this->input->get('dataName');
		
	$data['requisition_m_list'] = $this->requisition_manage_model->requisition_m_list($g);

	//echo $data;
	
	$this->load->view('requisitrequisitionn_manage/ioList',$data);
	} 
	
		//create a insert Purchase Invoice
	function requisition_return_update()
	{
		


			
			    //$io_number				= $this->input->post('io_number');	
				
				$iwo_number				= $this->input->post('iwo_number');
				$material_name 			= $this->input->post('material_name');
				$material_code	 		= $this->input->post('material_code');
				$material_group 		= $this->input->post('material_group');
				$material_qty_main 		= $this->input->post('material_qty_main');
				$material_qty 			= $this->input->post('material_qty');
				$unit_price_avg			= $this->input->post('unit_price');
				$total_price			= $this->input->post('total_price');
				
				$sub_group			= $this->input->post('sub_group');
				$measurement_unit	= $this->input->post('measurement_unit');
				$requisition_date	= $this->input->post('requisition_date');
				$local	= $this->input->post('local');
				
				
				//$return_qty=($material_qty_main-$material_qty);
				
				
				$data = array(
							'local' 		=> $local[0],
							'requisition_number' 		=> $this->input->post('requisition_number'),
							'comment' 			=>   'requisition Return',
							'update_date' 		=> date('Y-m-d'),
							'update_by'   		=> $this->session->userdata('email')
						);
	
			
			
			    $this->requisition_manage_model->requisitionReturnUpdate( $data, $iwo_number, $material_name, $material_code, $material_group, $material_qty_main, $material_qty, $unit_price_avg, $total_price, $sub_group, $measurement_unit, $requisition_date, $local );
	
				  
					redirect('requisition_manage','refresh');
			
	
	}	
	
	
	
	
	
	

} //End of Class
