<?php defined('BASEPATH') OR exit('No direct script access allowed');

class Client_manage extends CI_Controller {

	function __construct()
	{
		parent::__construct();
		
		$this->load->model('client_manage_model');
		$this->load->model('stock_manage_model');
	}

	//redirect if needed, otherwise display the user list
	function index()
	{

		if (!$this->ion_auth->logged_in())
		{
			//redirect them to the login page
			redirect('admin/login', 'refresh');
		}
		elseif (!($this->session->userdata('sm') == 1)&&(!($this->session->userdata('sa') == 1)))
		{
			//redirect them to the home page because they must be an administrator to view this
			redirect($this->config->item('base_url'), 'refresh');
		} else

		{
			//set the flash data error message if there is one
			$this->data['message'] = (validation_errors()) ? validation_errors() : $this->session->flashdata('message');

			//list the users
			$this->data['users'] = $this->ion_auth->users()->result();
			foreach ($this->data['users'] as $k => $user)
			{
				$this->data['users'][$k]->groups = $this->ion_auth->get_users_groups($user->id)->result();
			}

			$data['onload']='client_manage';
            $data['clients']=$this->client_manage_model->client_list();
            $data['message']=$this->data['message'];
            $data['main_content']="client_manage/index";
        $this->load->view('template', $data);
			//$this->load->view('admin/index', $this->data);
		}
	}
	
	//create a new user
	function create_client()
	{
		
		$data['groups'] = $this->stock_manage_model->group_list();	
	    $data['sub_groups'] = $this->stock_manage_model->sub_group_list();
	
			
		$this->load->view('client_manage/create_client',$data);	
		
	
	}
	
	//create a new user
	function insert_client()
	{
		

		if (!$this->session->userdata('identity'))
		{
			//redirect them to the login page
			redirect('admin/login', 'refresh');
		}

			
			$data = array(
			    'client_name' 			=> $this->input->post('client_name'),
				'address' 				=> $this->input->post('address'),
				'client_phone' 			=> $this->input->post('client_phone'),
				'client_email'			=> $this->input->post('client_email'),
				'active'				=> 1 ,
				'insert_by' 		=> $this->session->userdata('email'),			
				'create_date'   	=> date('Y-m-d')
			);
			
				$contact_person_name 		= $this->input->post('contact_person_name1');
				$contact_person_phone	 	= $this->input->post('contact_person_phone1');
				$contact_person_email		= $this->input->post('contact_person_email1');
			

			
			    $this->client_manage_model->createClient($data, $contact_person_name, $contact_person_phone, $contact_person_email );
	
				  
					redirect('client_manage', 'refresh');
			
	
	}
	
//activate the user
	function activate($id)
	{

			$activation = $this->client_manage_model->activate($id);
		
                    redirect('client_manage', 'refresh');
	}
	
	
	
	//deactivate the user
	function deactivate($id )
	{
		$this->client_manage_model->deactivate($id);

			//redirect them back to the admin page
			redirect('client_manage', 'refresh');	
	}

	

	function client_del($id){
	  	
	$this->client_manage_model->user_del($id);
	
	redirect('client_manage');
	
	}
	
	function edit_client($id)
	{
		$data['client_code']=$id;  
	
		$data['editData']=$this->client_manage_model->editClient($id);
		$data['contact_list']=$this->client_manage_model->contactList($id);
		
		//$data['groups'] = $this->stock_manage_model->group_list();	
	   // $data['sub_groups'] = $this->stock_manage_model->sub_group_list();
		
		$this->load->view('client_manage/edit_client',$data);	
	
	}
	
	
		
	function update_client()
	{
		

		if (!$this->session->userdata('identity'))
		{
			//redirect them to the login page
			redirect('admin/login', 'refresh');
		}

		//validate form input
		
			
			$data = array(
 				'client_name' 	=> $this->input->post('client_name'),
				'client_code' 	=> $this->input->post('client_code'),
				'address' 			=> $this->input->post('address'),
				'client_phone' 			=> $this->input->post('client_phone'),
				'client_email'				=> $this->input->post('client_email'),
				'update_date' 		=> date('Y-m-d'),
				'update_by'   		=> $this->session->userdata('email')
			);
			
			 $s_id=$this->input->post('client_code');
			//print_r($data);
				
				$contact_person_name 		= $this->input->post('contact_person_name');
				$contact_person_phone	 	= $this->input->post('contact_person_phone');
				$contact_person_email		= $this->input->post('contact_person_email');				
				$cp_id						= $this->input->post('cp_id');
			

          	$this->client_manage_model->updateClient($s_id, $data, $contact_person_name, $contact_person_phone, $contact_person_email, $cp_id);
					
			redirect('client_manage', 'refresh');
			
		
		
	}


	 

} //End of Class
