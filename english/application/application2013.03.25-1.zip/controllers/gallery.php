<?php 
class Gallery extends CI_Controller {

    function __construct(){
               
        parent::__construct();
     
		
	$this->load->model('gallery_model');	

          
    }

    public function index() {        
    
	 $data=array();
	if($this->input->post('upload')){
	
	//$this->input->post('upload');
	$this->gallery_model->doUpload();
	
	}
	
	$data['images'] = $this->gallery_model->get_images(); 
	//$data['error']=$this->upload->display_errors();
        
        //$data['main_content']="";
        $this->load->view('gallery_view', $data);
    }

   

}

?>
