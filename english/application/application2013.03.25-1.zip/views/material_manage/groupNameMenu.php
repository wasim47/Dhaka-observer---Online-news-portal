

<?php ///////////////////////////////////////////////////////////////////////////////////////////////////////////////  ?>

							<?php if (isset($groupcode)){ 
							$selected=$groupcode[0]->material_group;
							} else { 
							$selected='none';
							}?>
					<select  onchange="groupCodeChanger()" name="group_code"  id="groupName" >
                    <option  value="none" selected="selected" >Select code</option>
                    
					<?php foreach($groups as $group): ?>
					<option value="<?php echo $group->material_group;?>" <?php if (($group->material_group)==$selected){?> selected="selected" <?php } ?>><?php echo $group->material_group;?></option>
				
				<?php endforeach;?>
					</select>
              