

<?php ///////////////////////////////////////////////////////////////////////////////////////////////////////////////  ?>

		<p>				                            
                           <?php  
						   
							
							?>
                    
       <table width="100%"><tr><td width="45%">Sub Group Code:</td><td width="55%" style="text-align:left; font-weight:bold;" id="groupCode">
	   <?php if (isset($subGroupcode[0]->sub_group_code)){ echo $subGroupcode[0]->sub_group_code; } ?></td></tr></table>
            <?php if (isset($subGroupcode[0]->sub_group_code)){ echo form_hidden('sub_group_code',$subGroupcode[0]->sub_group_code,'id="sub_group_code"'); }?> 
            
            </p>
      
					
              