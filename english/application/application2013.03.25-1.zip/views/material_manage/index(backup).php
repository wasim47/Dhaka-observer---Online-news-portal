
<?php //+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++?>
<table width="100%" border="0" cellspacing="0" cellpadding="0">
	<tr>
	<td colspan="3"><img src="<?php echo base_url();?>assets/images/main_body_01.jpg" width="986" height="35" /></td>
	</tr>
	<tr>
	<td><img src="<?php echo base_url();?>assets/images/main_body_02.jpg" width="24" height="60" /></td>
	<td background="images/main_body_03.jpg" width="936" height="50">
	<table width="930"  border="0">
	<tr>
	<td width="49"><img src="<?php echo base_url();?>assets/images/Product.png" width="48" height="48" /></td>
	<td width="595"><h1><span class="material">Material Manager </span></h1></td>
	<!--<td width="28" class="border"><div align="center" class="section"><a href="javascript:void(0);" onClick="article_delete('delete','0');" ><img src="images/delete2.png" width="32" height="32" border="0" />Delete</a></div></td>-->
	<!--<td width="33" class="border"><div align="center" class="section"><a href="#" class="newFrm">
	<img src="images/edit1.png" width="32" height="32" border="0" />Edit</a></div></td>-->
	<td width="33" class="border">
	<div align="center" class="section">
	<a class="uCreate" href="<?php echo base_url();?>material_manage/create_material"><img src="<?php echo base_url();?>assets/images/new1.png" width="30" height="30" border="0" />New</a>
	</div>
	</td>
	
	</tr>
	</table>
	</td>
	<td><img src="<?php echo base_url();?>assets/images/main_body_04.jpg" width="26" height="60" /></td>
	</tr>
	<tr>
	<td colspan="3"><img src="<?php echo base_url();?>assets/images/main_body_05.jpg" width="986" height="32" /></td>
	</tr>
</table>
    
    <table width="100%" border="0" cellspacing="0" cellpadding="0">
	<tr>
	<td colspan="3"><img src="<?php echo base_url();?>assets/images/main_body_01.jpg" width="986" height="35" /></td>
	</tr>
	<tr>
	<td style="background:url(assets/images/bar.jpg) repeat-y;" valign="top"><img src="<?php echo base_url();?>assets/images/main_body_02.jpg" width="24" height="181" /></td>
	<td width="936" height="181" align="center" style="background:url(assets/images/main_body_03.jpg) repeat-x; background-color:#dee4f0" >
	
	
	<div class="table_user_round1">
	  
		<table width="100%"  cellpadding="4" cellspacing="1">
          <tr>
            <td width="48" height="26" align="center" bgcolor="#C9DEF1" class="table_header"><span class="style2">#</span></td>
            
             <td width="147" align="center" bgcolor="#C9DEF1" class="table_header"><span class="style2">Material Name </span></td>
            <td width="117" align="center" bgcolor="#C9DEF1" class="table_header"><span class="style2">Material  Code</span></td>
            <td width="147" align="center" bgcolor="#C9DEF1" class="table_header"><span class="style2">Material Group </span></td>
            <td width="150" align="center" bgcolor="#C9DEF1" class="table_header"><span class="style2">Measurement Unit</span></td>
            <td width="132" align="center" bgcolor="#C9DEF1" class="table_header"><span class="style2">Opening Quantity</span></td>
            
                        
            <td width="129" align="center" bgcolor="#C9DEF1" class="table_header"><span class="style2">Action </span></td>
          </tr>
        </table>
		<div style="overflow:scroll; overflow-x:hidden; width:910px; max-height:313px;">
		  <table width="100%" cellpadding="4" cellspacing="1">
           
            <?php $i=1; foreach ($materials as $material):?>
             <?php if($i%2!=0)
			 { $c="#E3EDF9";
			 } else {
				$c="#FFFFFF"; } ?>
            <tr class="table_hover" bgcolor="<?php echo $c; ?>">
              <td width="47" height="27" align="center"><span class="style9"><?php echo $i;?></span></td>
              <td width="139" align="left" class="section" style="padding-left:10px;"><a href="#" title="<?php echo $material->material_group;?>" class="style2" > <?php echo $material->material_name;?></a></td>
              <td width="116" align="center" class="style2"><?php echo $material->material_code;?></td>
              <td width="144" align="center" class="style2"><?php echo $material->material_group;?></td>
              <td width="150" align="center"><span class="style2"><?php echo $material->measurement_unit;?></span></td>
              <td width="132" align="center"><span class="style2"><?php echo $material->opening_qty;?></span></td>
          
              
              <td width="116" align="center" class="section"><a href="<?php echo base_url();?>material_manage/edit_material/<?php echo $material->id; ?>" class="uCreate" title="Edit"><img src="<?php echo base_url();?>assets/images/pensil.png" border="0"> </a>&nbsp;&nbsp;&nbsp; <a href="<?php echo base_url();?>material_manage/material_del/<?php echo $material->id; ?>" title="Delete"><img src="<?php echo base_url();?>assets/images/delete.png" border="0"></a> </td>
            </tr>
            <?php $i++; endforeach;?>           
            
          </table>
		</div>
	</div></td>
	<td style="background:url(assets/images/bar1.jpg) repeat-y;" valign="top"><img src="<?php echo base_url();?>assets/images/main_body_04.jpg" width="26" height="181" /></td>
	</tr>
	<tr>
	<td colspan="3"><img src="<?php echo base_url();?>assets/images/main_body_05.jpg" width="986" height="32" /></td>
	</tr>
	</table>
<div id="errors"><?php echo $message;?></div>
<?php //+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++?>


<div id="lightBox" align="center">
	<table cellspacing="0" cellpadding="0">
	<tr>
	<td colspan="3" align="right">
	<!--<a title="Close" class="bb_close" href="javascript:void(0);" onClick="hideOverlay();"></a>--></td>
	</tr>
	<tr>
	<td class="t_l"></td>
	<td class="t_c"></td>
	<td class="t_r"></td>
	</tr>
	<tr>
	<td class="c_l"></td>
	<td class="c_c">
	<div id="lightText"></div></td>
	<td class="c_r"></td>
	</tr>
	<tr>
	<td class="b_l"></td>
	<td class="b_c"></td>
	<td class="b_r"></td>
	</tr>
	</table>
</div>

<div id="lightBox3" align="center">
	<table cellspacing="0" cellpadding="0">
	<tr>
	<td colspan="3" align="right">
	<!--<a title="Close" class="bb_close" href="javascript:void(0);" onClick="hideOverlay();"></a>--></td>
	</tr>
	<tr>
	<td class="t_l"></td>
	<td class="t_c"></td>
	<td class="t_r"></td>
	</tr>
	<tr>
	<td class="c_l"></td>
	<td class="c_c">
	<div id="lightText3"></div></td>
	<td class="c_r"></td>
	</tr>
	<tr>
	<td class="b_l"></td>
	<td class="b_c"></td>
	<td class="b_r"></td>
	</tr>
	</table>
</div>


<script type="text/javascript">
//#########################################################################################

	//to retrive the subGroup of the selected Group//
	function subGroupTrigger()
{
	
	var groupName=document.getElementById("groupName").value;
	//alert(groupName);
	
	
	var xmlRequest = GetXmlHttpObject();
	if (xmlRequest == null)
	return;
	var url="<?php echo base_url();?>material_manage/subGroup?groupName="+groupName;
	//alert(url);
	var browser=navigator.appName;
	if (browser=="Microsoft Internet Explorer")
		{
			xmlRequest.open("POST",url, true);
		}
	else
		{
			xmlRequest.open("GET",url, true);
		}
	xmlRequest.setRequestHeader("Content-Type", "application/x-www-formurlencoded");
	xmlRequest.onreadystatechange =function()
		{
			if(xmlRequest.readyState==4)
			{
				HandleAjaxResponse(xmlRequest,'dis');
			}
		};
	xmlRequest.send(null);
	
	groupCodeTrigger();
	
	return false;
}
		


		


	//#########################################################################################


	//#########################################################################################
		
	function groupCodeTrigger()
{
	
	var groupName=document.getElementById("groupName").value;
	//alert(groupName);
	
	var xmlRequest = GetXmlHttpObject();
	if (xmlRequest == null)
	return;
	var url="<?php echo base_url();?>material_manage/groupCodeTrigger?groupName="+groupName;
	//alert(url);
	var browser=navigator.appName;
	if (browser=="Microsoft Internet Explorer")
		{
			xmlRequest.open("POST",url, true);
		}
	else
		{
			xmlRequest.open("GET",url, true);
		}
	xmlRequest.setRequestHeader("Content-Type", "application/x-www-formurlencoded");
	xmlRequest.onreadystatechange =function()
		{
			if(xmlRequest.readyState==4)
			{
				HandleAjaxResponse(xmlRequest,'dis3');
			}
		};
	xmlRequest.send(null);
	return false;
}
		


	function subGroupCodeTrigger()
{
	
	var subGroupName=document.getElementById("subGroupName").value;
	//alert(groupName);
	
	var xmlRequest = GetXmlHttpObject();
	if (xmlRequest == null)
	return;
	var url="<?php echo base_url();?>material_manage/subGroupCodeTrigger?subGroupName="+subGroupName;
	//alert(url);
	var browser=navigator.appName;
	if (browser=="Microsoft Internet Explorer")
		{
			xmlRequest.open("POST",url, true);
		}
	else
		{
			xmlRequest.open("GET",url, true);
		}
	xmlRequest.setRequestHeader("Content-Type", "application/x-www-formurlencoded");
	xmlRequest.onreadystatechange =function()
		{
			if(xmlRequest.readyState==4)
			{
				HandleAjaxResponse(xmlRequest,'dis4');
			}
		};
	xmlRequest.send(null);
	return false;
}
		
	

	//#########################################################################################
	function HandleAjaxResponse(xmlRequest,focusDiv)
	{
		var xmlT=xmlRequest.responseText;
		//alert(xmlT);
		document.getElementById(focusDiv).innerHTML=xmlT;
		//loadmylightbox();
		return false;
	}	
	
	function GetXmlHttpObject()
{		
	var xmlHttp=null;
	try
	{
		xmlHttp=new XMLHttpRequest();
	}
	catch (e)
	{
		// Internet Explorer
		try
			{
				xmlHttp=new ActiveXObject("Microsoft.XMLHTTP");
			}
		catch (e)
			{
				xmlHttp=new ActiveXObject("Msxml2.XMLHTTP");
			}
	}
	return xmlHttp;
}


</script>
