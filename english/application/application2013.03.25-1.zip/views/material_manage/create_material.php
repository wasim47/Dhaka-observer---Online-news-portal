<style>

#u_table {
text-align:right;
	width:600px;
	height:250px;
	float:left;
	margin-bottom:30px;
}

.uc_header {
  float: right;
  text-align:center;
  width:600px;
  font-size:18px;
  font-weight:bold;
  
}

.left_col {
  float: right;
  padding-right: 40px;
}

.right_col {
  float: right;
  padding-right: 70px;
}

#u_table select {
width:160px;

}

#u_table input ,#u_table select  {
  background: none repeat scroll 0 0 #E6F4FF;
  border: 1px solid #7FB2CF;
  border-radius: 2px 2px 2px 2px;
  color: #205291;
  font-family: Verdana,Arial,Helvetica,sans-serif;
  font-size: 9px;
  font-weight: normal;
  height: 18px;
  width: 125px;
}

#u_table input:hover, #u_table input:focus #u_table select:hover, #u_table select:focus {
	border-color:#087DB5;
	background:#E6F4FF;
} 

 .bb_close , .submit {
  background-color: #7DA8D3;
  border: 1px solid #4B87C2;
  border-radius: 3px 3px 3px 3px;
  color: #FFFFFF;
  cursor: pointer;
  font-family: Arial,Helvetica,sans-serif;
  font-size: 12px;
  height: 21px;
  width: 120px;
  margin-left:30px;
}

.submit {

  background-color: #7DA8D3;
  border: 1px solid #4B87C2;
  border-radius: 3px 3px 3px 3px;
  color: #FFFFFF;
  cursor: pointer;
  font-family: Arial,Helvetica,sans-serif;
  font-size: 12px;
  height: 21px;
  width: 120px;
  margin-left:150px;
}

                      
              #groupCode {
  background: none repeat scroll 0 0 #E6F4FF;
  border: 1px solid #7FB2CF;
  border-radius: 2px 2px 2px 2px;
  color: #205291;
  font-family: Verdana,Arial,Helvetica,sans-serif;
  font-size: 9px;
  font-weight: normal;
  height: 16px;
  width: 125px;
}





</style>


<?php
		$options = array(
						  '0'  => 'No',
						  '1'    => 'Yes'
						);
						
		$options2 = array(
						  'none' 	  => 'Select Unit',
						  'Pcs'   => 'Pcs',
						  'Coil'  => 'Coil',
						  'Kg'    => 'Kg',						  
						  'Pair'  => 'Pair',
						  'Box'    => 'Box',
						  'sft'    => 'sft',
						  'rft'    => 'rft',
						  'gl'    => 'gl',
						  'ltr'    => 'ltr',
						  'pkt'    => 'pkt',
						  'yds'    => 'yds',
						  'yd'    => 'yd',
						  'set'    => 'set',
						  'Kg'    => 'Kg',
						  'Kg'    => 'Kg',
						);
						
 		echo form_open("material_manage/insert_material");

?>


<?php ///////////////////////////////////////////////////////////////////////////////////////////////////////////////  ?>
<div id="u_table">
<div class="uc_header"><img src="<?php echo base_url();?>assets/images/Product.png" width="48" height="48" />Material Create</div>
	<div class="left_col">
    <div id="dis3">
		   <p> 
           <table width="100%"><tr><td width="45%"> Group Code:</td><td width="55%" id="groupCode" >&nbsp;</td></tr></table>
            <?php echo form_hidden('group_code','','id="group_code"');?>
      </p></div>
      <div id="dis4"><p  >
           <table><tr><td> Sub Group Code:</td><td id="groupCode" >&nbsp;</td></tr></table>
            <?php echo form_hidden('sub_group_code','','id="sub_group_code"');?>
      </p></div>


      
   <p>
           <table width="100%"><tr><td width="45%"> Material Code: </td><td width="55%"  >
            <?php echo form_input('material_code','','id="material_code"');?></td></tr></table>
      </p>
      
		<p>
            <table width="100%"><tr><td width="45%">Opening Balance: </td><td width="55%"  >
            <?php echo form_input('opening_balance','','id="opening_balance"');?></td></tr></table>
      </p>
       <p>
      <table width="100%"><tr><td width="45%">Publish: </td><td width="55%"  >
            <?php echo form_dropdown('publish',$options,'No'); ?></td></tr></table>
      </p>   

</div>
<div class="right_col">

	  <p>
    		<!--	<div id="dis1">-->
            	  Group Name:
    			  <select  onchange="subGroupTrigger()" name="groupName" id="groupName"  >
                    <option value="none" >Select Group</option>
                    <?php foreach($groups as $group): ?>
                    <option  value="<?php echo $group->material_group;?>" ><?php echo $group->material_group;?></option>
                    <?php endforeach;?>
                  </select>
    			<!--</div>-->
  </p>
        <p> 
         <div id="dis">
         			Sub Group Name: 
					<select  onchange="subGroupCodeTrigger()" name="sub_group_name"  id="subGroupName" >
                    <option  value="none" selected="selected" >Select SubGroup Code</option>                  
					<?php foreach($sub_groups as $sub_group): ?>
					<option value="<?php echo $sub_group->sub_group_code;?>" ><?php echo $sub_group->sub_group_code;?></option>				
				<?php endforeach;?>
					</select>
              </div>
		</p>

      <p>
            Material Name: 
            <?php echo form_input('material_name','','id="material_name"');?>
      </p>
      <p>
       		Measurement Unit:
      		<?php echo form_dropdown('measurement_unit',$options2,'none'); ?>
     </p>
	 
      <p>
            Opening Quantity: 
            <?php echo form_input('opening_qty','','id="opening_qty"');?>
      </p>
       



      
  </div>    
</div>
<p><?php echo form_submit('submit', 'Create Material','class="submit" onclick="validationCheck()"');?><input class="bb_close" onclick="hideOverlay();" href="#" title="Close" type="button" value="Cancel"></p>
<?php echo form_close();?>
	
     