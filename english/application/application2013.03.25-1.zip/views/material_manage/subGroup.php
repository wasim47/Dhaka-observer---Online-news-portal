

<?php ///////////////////////////////////////////////////////////////////////////////////////////////////////////////  ?>

						                            
                           <?php if (isset($sub_group)){ 
						   
						   //print_r($sub_group);
							
							?>
                     Sub Group Name:
					<select   onchange="subGroupCodeTrigger()" name="sub_group_name"  id="subGroupName" >
                    <option  value="none" selected="selected" >Select Sub Group</option>
                    
					<?php foreach($sub_group as $sg): ?>
					<option value="<?php echo $sg->sub_group;?>" ><?php echo $sg->sub_group;?></option>
				
				<?php endforeach; }?>
					</select>
              