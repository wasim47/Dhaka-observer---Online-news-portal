

<?php ///////////////////////////////////////////////////////////////////////////////////////////////////////////////  ?>

							<?php if (isset($sub_group_code)){ 
							$selected=$sub_group_code[0]->sub_group_code;
							} else { 
							$selected='none';
							}?>
                            
                           <?php if (isset($sub_group_code)){ 
							echo 'Material Group :'.$material_group=$sub_group_code[0]->material_group;
							echo form_hidden('material_group',$material_group);
							echo form_hidden('group_code',$sub_group_code[0]->group_code);
							}?></br>
					<select onchange="subGroupNameChanger()"  name="sub_group_code"  id="subGroupCode" >
                    <option  value="none" selected="selected" >Select code</option>
                    
					<?php foreach($sub_groups as $sub_group): ?>
					<option value="<?php echo $sub_group->sub_group_code;?>" <?php if (($sub_group->sub_group_code)==$selected){?> selected="selected" <?php } ?>><?php echo $sub_group->sub_group_code;?></option>
				
				<?php endforeach;?>
					</select>
              