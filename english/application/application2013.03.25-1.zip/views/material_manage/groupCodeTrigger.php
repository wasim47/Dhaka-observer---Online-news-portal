

<?php ///////////////////////////////////////////////////////////////////////////////////////////////////////////////  ?>

		<p>				                            
                           <?php  
						   
							
							?>
                    
       <table width="100%"><tr><td width="45%"> Group Code:</td><td width="55%" style="text-align:left; font-weight:bold;" id="groupCode">
	   <?php if (isset($groupcode[0]->code)){ echo $groupcode[0]->code; } ?></td></tr></table>
            <?php if (isset($groupcode[0]->code)){ echo form_hidden('group_code',$groupcode[0]->code,'id="group_code"'); }?> 
            
            </p>
      
 