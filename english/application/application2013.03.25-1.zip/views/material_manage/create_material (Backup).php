<style>

#u_table {
text-align:right;
	width:600px;
	height:250px;
	float:left;
	margin-bottom:30px;
}

.uc_header {
  float: right;
  text-align:center;
  width:600px;
  font-size:18px;
  font-weight:bold;
  
}

.left_col {
  float: right;
  padding-right: 40px;
}

.right_col {
  float: right;
  padding-right: 70px;
}

#u_table select {
width:160px;

}

#u_table input ,#u_table select  {
  background: none repeat scroll 0 0 #E6F4FF;
  border: 1px solid #7FB2CF;
  border-radius: 2px 2px 2px 2px;
  color: #205291;
  font-family: Verdana,Arial,Helvetica,sans-serif;
  font-size: 9px;
  font-weight: normal;
  height: 18px;
  width: 125px;
}

#u_table input:hover, #u_table input:focus #u_table select:hover, #u_table select:focus {
	border-color:#087DB5;
	background:#E6F4FF;
} 

 .bb_close , .submit {
  background-color: #7DA8D3;
  border: 1px solid #4B87C2;
  border-radius: 3px 3px 3px 3px;
  color: #FFFFFF;
  cursor: pointer;
  font-family: Arial,Helvetica,sans-serif;
  font-size: 12px;
  height: 21px;
  width: 120px;
  margin-left:30px;
}

.submit {

  background-color: #7DA8D3;
  border: 1px solid #4B87C2;
  border-radius: 3px 3px 3px 3px;
  color: #FFFFFF;
  cursor: pointer;
  font-family: Arial,Helvetica,sans-serif;
  font-size: 12px;
  height: 21px;
  width: 120px;
  margin-left:150px;
}



</style>


<?php
		$options = array(
						  '0'  => 'No',
						  '1'    => 'Yes'
						);
						
		$options2 = array(
						  'none' 	  => 'Select Unit',
						  'Pcs'   => 'Pcs',
						  'Coil'  => 'Coil',
						  'Kg'    => 'Kg',						  
						  'Pair'  => 'Pair',
						  'Box'    => 'Box',
						  'sft'    => 'sft',
						  'rft'    => 'rft',
						  'gl'    => 'gl',
						  'ltr'    => 'ltr',
						  'pkt'    => 'pkt',
						  'yds'    => 'yds',
						  'yd'    => 'yd',
						  'set'    => 'set',
						  'Kg'    => 'Kg',
						  'Kg'    => 'Kg',
						);
						
 		echo form_open("material_manage/insert_material");

?>


<?php ///////////////////////////////////////////////////////////////////////////////////////////////////////////////  ?>
<div id="u_table">
<div class="uc_header"><img src="<?php echo base_url();?>assets/images/Product.png" width="48" height="48" />Material Create</div>
	<div class="left_col">
      <p>
         <div id="dis">
					<select  onchange="subGroupNameChanger()" name="sub_group_code"  id="subGroupCode" >
                    <option  value="none" selected="selected" >Select SubGroup Code</option>
                    
					<?php foreach($sub_groups as $sub_group): ?>
					<option value="<?php echo $sub_group->sub_group_code;?>" ><?php echo $sub_group->sub_group_code;?></option>
				
				<?php endforeach;?>
					</select>
              </div>
		</p>

      
      <p>
            Material Code: 
            <?php echo form_input('material_code','','id="material_code"');?>
      </p>
      
		<p>
            Opening Balance: 
            <?php echo form_input('opening_balance','','id="opening_balance"');?>
      </p>
       <p>
            Publish: 
            <?php echo form_dropdown('publish',$options,'No'); ?>
      </p>   

</div>
<div class="right_col">

	  <p>
    			<div id="dis1">
    			  <select  onchange="subGroupCodeChanger()" name="subGroupName" id="subGroupName"  >
                    <option value="none" >Select Sub Group</option>
                    <?php foreach($sub_groups as $sub_group): ?>
                    <option  value="<?php echo $sub_group->sub_group;?>" ><?php echo $sub_group->sub_group;?></option>
                    <?php endforeach;?>
                  </select>
    			</div>
  </p>

      <p>
            Material Name: 
            <?php echo form_input('material_name','','id="material_name"');?>
      </p>
      <p>
       		Measurement Unit:
      		<?php echo form_dropdown('measurement_unit',$options2,'none'); ?>
     </p>
	 
      <p>
            Opening Quantity: 
            <?php echo form_input('opening_qty','','id="opening_qty"');?>
      </p>
       



      
  </div>    
</div>
<p><?php echo form_submit('submit', 'Create Material','class="submit"');?><input class="bb_close" onclick="hideOverlay();" href="#" title="Close" type="button" value="Cancel"></p>
<?php echo form_close();?>
	
     