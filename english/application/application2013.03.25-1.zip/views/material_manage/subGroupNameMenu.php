

<?php ///////////////////////////////////////////////////////////////////////////////////////////////////////////////  ?>

							<?php if (isset($sub_group_name)){ 
							
							//print_r($sub_group_name);
							$selected=$sub_group_name[0]->sub_group;
							} else { 
							$selected='none';
							}?>
                            
					<select  onchange="subGroupCodeChanger()" name="sub_group_name"  id="subGroupName" >
                    <option  value="none" selected="selected" >Select code</option>
                    
					<?php foreach($sub_groups as $sub_group): ?>
					<option value="<?php echo $sub_group->sub_group;?>" <?php if (($sub_group->sub_group)==$selected){?> selected="selected" <?php } ?>><?php echo $sub_group->sub_group;?></option>
				
				<?php endforeach;?>
					</select>
              