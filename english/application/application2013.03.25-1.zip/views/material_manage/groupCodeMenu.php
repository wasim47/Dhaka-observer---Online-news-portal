

<?php ///////////////////////////////////////////////////////////////////////////////////////////////////////////////  ?>

							<?php if (isset($groupcode)){ 
							$selected=$groupcode[0]->code;
							} else { 
							$selected='none';
							}?>
					<select onchange="groupNameChanger()"  name="group_code"  id="groupCode" >
                    <option  value="none" selected="selected" >Select code</option>
                    
					<?php foreach($groups as $group): ?>
					<option value="<?php echo $group->code;?>" <?php if (($group->code)==$selected){?> selected="selected" <?php } ?>><?php echo $group->code;?></option>
				
				<?php endforeach;?>
					</select>
              