<?php $i=1; foreach($pi_m_list as $data):?>
          <tr id="<?php echo "prof_".$i; ?>">
            <td><?php echo form_input('material_name[]',$data->material_name,'id="material_name'.$i.'" autocomplete="off" "  class="vertical" readonly="" ');?></td>
            <td><?php echo form_input('material_code[]',$data->material_code,'id="material_code'.$i.'" readonly=""');?></td>
            <td><?php echo form_input('measurement_unit[]',$data->measurement_unit,'id="measurement_unit'.$i.'" readonly=""');?></td>
            <td><?php echo form_input('material_qty[]',$data->material_qty,'id="material_qty_'.$i.'"  class="vertical" onkeyup="netPrice(this)" ');?>
            <?php echo form_input('material_qty_main[]',$data->material_qty,'id="material_qty_main'.$i.'" style="display:none;" readonly="" ');?>
			<?php echo form_input('material_qty_check[]',$data->material_qty,'id="material_qty_check'.$i.'" style="display:none;" readonly="" ');?></td>
            <td><?php echo form_input('unit_price[]',$data->unit_price,'id="unit_price'.$i.'"  class="vertical" readonly="" ');?></td>
            <td ><?php echo form_input('net_price[]', $data->net_price,'id="net_price'.$i.'" readonly="" ');?>
				<?php echo form_input('sub_group[]', $data->sub_group,'id="sub_group'.$i.'" style="display:none;" readonly="" ');?>
                <?php echo form_input('supplier_name',$data->supplier_name,'id="supplier_name" style="display:none;" readonly=""');?>
                 <?php echo form_input('supplier_code',$data->supplier_code,'id="supplier_code" style="display:none;" readonly=""');?>
            	 <?php echo form_input('material_group[]',$data->material_group,'id="material_group" style="display:none;" readonly=""');?>
                 <?php echo form_input('sub_group[]',$data->sub_group,'id="sub_group" style="display:none;" readonly=""');?>
                 <?php echo form_input('invoice_date[]',$data->invoice_date,'id="sub_group" style="display:none;" readonly=""');?>
                </td>
     <td ><img src="<?php echo base_url();?>assets/images/delete.png" width="20" height="20" border="0" id="<?php echo "prof_".$i; ?>"  value="<?php echo "prof_".$i; ?>" onClick="del(this)" ></td>
          </tr>
         <?php $i++; endforeach; ?>
         
		
        