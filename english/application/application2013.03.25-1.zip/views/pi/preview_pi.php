<script type="text/javascript" src="<?php echo base_url();?>assets/js/common.js"></script><!-- for light Box -->
<script type="text/javascript" src="<?php echo base_url();?>assets/js/jquery.lightbox-0.5.js"></script><!-- for light Box -->
<script type="text/javascript" src="<?php echo base_url();?>assets/js/jquery.autocomplete.js"></script><!-- for Auto Complete -->
<link rel="stylesheet" type="text/css" href="<?php echo base_url();?>assets/css/lightbox.css" /><!-- for light Box -->
<link rel="stylesheet" type="text/css" href="<?php echo base_url();?>assets/css/jquery.autocomplete.css" /><!-- for Auto Complete CSS -->
<style>

#u_table {
  float: left;
  margin-bottom: 30px;
  min-height: 250px;
  text-align: right;
  width: 900px;
}

.uc_header {
  float: right;
  text-align:center;
  width:800px;
  font-size:18px;
  font-weight:bold;
  
}

.left_col {
  margin-top: 40px;
  float: right;
  padding-right: 50px;
}

.right_col {
  float: left;
  margin-top: 10px;
  padding-right: 20px;
}

.row1 {

	height:140px;
}

#u_table select {
width:160px;

}

#u_table input ,#u_table select {
  background: none repeat scroll 0 0 #E6F4FF;
  border: 1px solid #7FB2CF;
  border-radius: 2px 2px 2px 2px;
  color: #205291;
  font-family: Verdana,Arial,Helvetica,sans-serif;
  font-size: 9px;
  font-weight: normal;
  height: 18px;
 /* width: 150px;*/
}

#u_table .row2 input ,#u_table .row2 select {
  background: none repeat scroll 0 0 #E6F4FF;
  border: 1px solid #7FB2CF;
  border-radius: 2px 2px 2px 2px;
  color: #205291;
  font-family: Verdana,Arial,Helvetica,sans-serif;
  font-size: 9px;
  font-weight: normal;
  height: 18px;
  width: 95%;
}

#u_table input:hover, #u_table input:focus #u_table select:hover, #u_table select:focus {
	border-color:#087DB5;
	background:#E6F4FF;
} 

 .bb_close , .submit {
  background-color: #7DA8D3;
  border: 1px solid #4B87C2;
  border-radius: 3px 3px 3px 3px;
  color: #FFFFFF;
  cursor: pointer;
  font-family: Arial,Helvetica,sans-serif;
  font-size: 12px;
  height: 21px;
  width: 120px;
  margin-left:30px;
}

.submit {
  background-color: #7DA8D3;
  border: 1px solid #4B87C2;
  border-radius: 3px 3px 3px 3px;
  color: #FFFFFF;
  cursor: pointer;
  font-family: Arial,Helvetica,sans-serif;
  font-size: 12px;
  height: 21px;
  margin-left: 300px;
  width: 120px;
}
  
  #u_table button  {
  background-color: #7DA8D3;
  border: 1px solid #4B87C2;
  border-radius: 3px 3px 3px 3px;
  color: #FFFFFF;
  cursor: pointer;
  font-family: Arial,Helvetica,sans-serif;
  font-size: 12px;
  height: 21px;
  
  width: 120px;
}
                      
              #groupCode1 {
  background: none repeat scroll 0 0 #E6F4FF;
  border: 1px solid #7FB2CF;
  border-radius: 2px 2px 2px 2px;
  color: #205291;
  font-family: Verdana,Arial,Helvetica,sans-serif;
  font-size: 9px;
  font-weight: normal;
  height: 16px;
  width: 80px;
}

#u_table textarea {
  background: none repeat scroll 0 0 #E6F4FF;
  border: 1px solid #7FB2CF;
  border-radius: 2px 2px 2px 2px;
  color: #205291;
  font-family: Verdana,Arial,Helvetica,sans-serif;
  font-size: 9px;
  font-weight: normal;
  width: 200px;
  height: 56px;
}
.style4 {font-size: 12px}
#u_table .row1 .right_col table {
}
#u_table .row1 .right_col table {
}
</style>


<?php echo form_open("pi/insert_pi"); ?>


<?php ///////////////////////////////////////////////////////////////////////////////////////////////////////////////  ?>
<div id="u_table">
<div class="uc_header"> Create Purchase Invoice</div>
    <div class="row1">  
            <div class="left_col">
            
                  
                    <table width="110%" border="0">
              <tr>
                <td width="105"><div align="right">Invoice Date:</div></td>
                <td width="88" id="groupCode1"><div align="center"><strong><?php echo $supplierInfo[0]->invoice_date;?><?php echo form_hidden('invoiceDate',date('Y-m-d'),'id="invoiceDate"');?></strong></div></td>
              </tr>
              <tr>
                <td><div align="right">Incoice Creating By</div></td>
                <td id="groupCode1" ><div align="center"><strong><?php echo $supplierInfo[0]->insert_by; ?></strong></div></td>
              </tr>
             
            </table>
         
                  
      </div>
              
                          <div class="right_col">
                          
                          
                    <table width="100%" border="0" cellspacing="4" >
              <tr>
                <td width="170">Purchase Invoice Number :</td>
                <td width="18"><?php echo form_input('pi_number',$supplierInfo[0]->pi_number,'id="pi_number" style="width:100px;" class="vertical" tabindex="1" onblur="piCheck()"');?></td><td colspan="3" id="sms" style="display:none;color:red; font-size:09px; text-align:left;">in use or empty</td>                
              </tr><tr >
                <td>Supplier Name:</td>
                <td colspan="3"><?php echo form_input('supplier_name',$supplierInfo[0]->supplier_name,'id="idSelect" autocomplete="off"   class="vertical" style="width:100px;" onKeyUp="supplierCode()"  tabindex="2" onblur="supplierCode()"');?></td></tr>
                <tr >
                <td>Supplier Code:</td>
                <td colspan="3"><?php echo form_input('supplier_code',$supplierInfo[0]->supplier_code,'id="supplier_code" style="width:100px;"');?></td></tr>
             <!-- <tr>
                <td>&nbsp;</td>
                <td  >&nbsp;</td><td width="41">&nbsp;</td>
                <td   >&nbsp;</td>
              </tr>
              <tr>
                <td>Supplier Address: </td>
                <td colspan="3" ><?php echo form_input('address',$supplierInfo[0]->address,'id="address" style="width:315px;"');?></td>
              </tr>--></table>
            
            
                    
      </div>   
    </div>    
 <div class="row2"><table width="100%" border="0">
     <thead>
         <tr>
            <th width="12%"><div align="center"><span class="style4">Material Name</span></div></th>
           <th width="13%"><div align="center"><span class="style4">Material Code</span></div></th>
           <th width="16%"><div align="center"><span class="style4">Material Sub Group</span></div></th>
           <th width="13%"><div align="center"><span class="style4">Material Group</span></div></th>
           <th width="15%"><div align="center"><span class="style4">Measurement Unit</span></div></th>
           <th width="15%"><div align="center"><span class="style4">Material Quantity</span></div></th>
           <th width="8%"><div align="center"><span class="style4">Unit Price</span></div></th>
           <th width="8%"><div align="center"><span class="style4">Net Price</span></div></th>
         </tr>
     </thead>
         <tbody id="addContent"><?php foreach($previewData as $data):?>
          <tr>
            <td><?php echo form_input('material_name',$data->material_name,'id="material_name" autocomplete="off" "  class="vertical" onKeyUp="materialName()" tabindex="3"  ');?></td>
            <td><?php echo form_input('mc',$data->material_code,'id="mc" readonly=""');?></td>
            <td><?php echo form_input('sub_group',$data->sub_group,' id="sub_group2" readonly="" ');?></td>
            <td><?php echo form_input('material_group',$data->material_group,'id="material_group" readonly="" ');?></td>
            <td><?php echo form_input('measurement_unit',$data->measurement_unit,'id="measurement_unit" readonly=""');?></td>
            <td><?php echo form_input('material_qty',$data->material_qty,'id="material_qty" tabindex="4" class="vertical" ');?></td>
            <td><?php echo form_input('unit_price',$data->unit_price,'id="unit_price" tabindex="5" class="vertical" onkeyup="netPrice()"');?></td>
            <td ><?php echo form_input('net_price',$data->net_price,'id="net_price"');?></td>
          </tr>
         <?php endforeach; ?>
         
		<tr style="border: 1px solid #7FB2CF; ">
            <td>&nbsp;</td>
          <td>&nbsp;</td>
            <td>&nbsp;</td>
            <td>&nbsp;</td>
            <td>&nbsp;</td>
            <td>&nbsp;</td>
            <td><strong>Total Price</strong></td>
            <td ><?php echo form_input('total_price',$supplierInfo[0]->total_price,'id="total_price"');?></td>
          </tr>
        </tbody>
</table>
 
 </div>          
           
</div>    

<div class="row3">
<p><?php echo form_submit('submit', 'Submit','class="submit" ');?><input class="bb_close" onclick="hideOverlay();" href="#" title="Close" type="button" value="Cancel"></p>

    </div><!--end row3-->
</div><!--end u_table-->

<?php echo form_close();?>	

<script type="text/javascript">
 
 
 
		 $().ready(function() {
		 
		 
			$("#idSelect").autocomplete("pi/ajaxData", {
				width: 230,
				matchContains: true,
				selectFirst: false
			});
			
			$("#idSelect").result(function(event, data, formatted) {	
				supplierCode();
			});
		});
		
		 $().ready(function() {
			$("#material_name").autocomplete("pi/materialAc", {
				width: 150,
				matchContains: true,
				selectFirst: false
			});
			
			$("#material_name").result(function(event, data, formatted) {	
				materialName();
			});
		});
 
 
$(".vertical").keypress(function(event) {
        if(event.keyCode == 13) { 
        textboxes = $("input.vertical");

        currentBoxNumber = textboxes.index(this);
        if (textboxes[currentBoxNumber + 1] != null) {
            nextBox = textboxes[currentBoxNumber + 1]
           // nextBox.focus();
			if(nextBox.value !='')
			{
				nextBox = textboxes[currentBoxNumber + 2]
				
           // nextBox.focus();
			}
			
			nextBox.focus();
			
           event.preventDefault();
            return false 
            }
        }
    });
	
			$(document).keydown(function(e){
			if(e.keyCode==17)
			{
             //alert('CTRL Worlking');
				add25();
				document.getElementById('material_name').focus();
				
			}
		});
		
		//
		function netPrice()
		{
			var unitPrice=document.getElementById("unit_price").value;
			var materialQty=document.getElementById("material_qty").value;
			var netPrice=(unitPrice*materialQty);
			document.getElementById("net_price").value= netPrice;

		}
		
		
				
		function add25()
		{
			//alert("new row working");
				$(document).ready(function(){
				 //alert("Add25");
			
				var ac=addStaff();
			
				 addStaff();
		
			});
		}
		
			
				function addStaff(){
				//alert("In");
				var material_name=$('#material_name').val();
				var mc=$('#mc').val();
				var sub_group2=$('#sub_group2').val(); 
				var material_group=$('#material_group').val();
				var measurement_unit=$('#measurement_unit').val();
				var material_qty=$('#material_qty').val();
				var unit_price=$('#unit_price').val();
				var net_price=$('#net_price').val();
				var total_price=$('#total_price').val();
				var total_price_final=(Number(net_price)+Number(total_price));
				 //alert(p_c1);
				document.getElementById("total_price").value=total_price_final;
				
				strCountField = '#prof_count';      
				intFields = $(strCountField).val();
				intFields = Number(intFields);    
				newField = intFields + 1;
				
				strNewField = '<tr class="prof blueBox" id="prof_' + newField + '">\
							<input type="hidden" id="id' + newField + '" name="id' + newField + '" value="-1" />\
<td><input type="text" id="material_name' + newField + '" name="material_name1[]" maxlength="10" value="'+material_name+'" readonly="" /></td>\
            <td><input type="text" id="mc' + newField + '" name="material_code1[]" maxlength="10" value="'+mc+'" readonly="" /></td>\
            <td><input type="text" id="sub_group2' + newField + '" name="sub_group1[]" maxlength="10" value="'+sub_group2+'" readonly="" /></td>\
  <td><input type="text" id="material_group' + newField + '" name="material_group1[]" maxlength="10" value="'+material_group+'" readonly="" /></td>\
<td><input type="text" id="measurement_unit' + newField + '" name="measurement_unit1[]" maxlength="10" value="'+measurement_unit+'" readonly="" /></td>\
<td><input type="text" id="material_qty' + newField + '" name="material_qty1[]" maxlength="10" value="'+material_qty+'" readonly="" /></td>\
<td><input type="text" id="unit_price' + newField + '" name="unit_price1[]" maxlength="10" value="'+unit_price+'" readonly="" /></td>\
<td ><input type="text" id="net_price' + newField + '" name="net_price1[]" maxlength="10" value="'+net_price+'" readonly="" /></td>\
<td ><img src="<?php echo base_url();?>assets/images/delete.png" width="20" height="20" border="0" id="prof_' + newField + '"  value="prof_' + newField + '" onClick="del(this)" ></td>\
          </tr>\
		  <div class="nopass"><!-- clears floats --></div>\
		  '
		  ;

				$("#prof_" + intFields).after(strNewField);    
				$("#prof_" + newField).slideDown("medium");
				$(strCountField).val(newField);				
				$('#material_name').val('');
				$('#mc').val('');
				$('#sub_group2').val('');
				$('#material_group').val('');
				$('#measurement_unit').val('');
				$('#material_qty').val('');
				$('#unit_price').val('');
				$('#net_price').val('');
				//alert(strNewField);
				}	
		
		
		
		function del(id)
		{
		
			var agree=confirm ('Are you want to delete This?')
			{
				if(agree)
				{
				
				var y= ($(id).attr("id"));
				
				var x=y.split('_');
				
				
				
				var material_name="material_name"+x[1];
				var mc="mc"+x[1];
				var sub_group2="sub_group2"+x[1];
				var material_group="material_group"+x[1];
				var measurement_unit="measurement_unit"+x[1];
				var material_qty="material_qty"+x[1];
				var unit_price="unit_price"+x[1];
				var netPrice="net_price"+x[1];
				
				
				
				
				
				var dataName=document.getElementById(netPrice).value;
				
				var total_price=$('#total_price').val();
				
				var total_price_final=(Number(total_price)-Number(dataName));
				 alert(total_price_final);
				document.getElementById("total_price").value=total_price_final;
				
				//alert(total_price_final);
				
					document.getElementById(material_name).value='';
					document.getElementById(mc).value='';
					document.getElementById(sub_group2).value='';
					document.getElementById(material_group).value='';
					document.getElementById(measurement_unit).value='';
					document.getElementById(material_qty).value='';
					document.getElementById(unit_price).value='';
					document.getElementById(netPrice).value='';
					
					
				 document.getElementById(y).style.display='none';
				 return true
				}
				else
				{
				return false;
				}
		}
		
		//confirm
		 //alert(y);
		
		
		}//del function END
		
		
		
		function emptyCheck(id)	
		{
		var y= ($(id).attr("id"));
		var idY ='#'+y;
	
		var val=document.getElementById(y).value;
	
			if (val=='')
			{
			//alert(val);
			//alert('its not OK');
			//$(idY).val('');
			$(idY).css("border-color","red");
			document.getElementById(y).focus();
			} else 
			{
			$(idY).css("background-color","#E6F4FF");
			$(idY).css("border-style","solid");
			$(idY).css("border-color","#7FB2CF");
			//alert('its  ok');
			}
	}
	
	
			$('.submit').click(function(e){
		
		
		
		 var pi_number=$('#pi_number').val();
		 var supplier_name=$('#idSelect').val();
	     var total_price=$('#total_price').val();
		
		//alert('supp='+total_price);
		
		
		
		if(pi_number == "" ){
		
			$('#pi_number').val('');
			$("#pi_number").css("border-color","red");
			$("#sms").css("display",""); 
			document.getElementById('pi_number').focus();
			e.preventDefault();
		
		} else if(supplier_name == "" ){
		 e.preventDefault();
		 $('#idSelect').val('');
		  $('#idSelect').css("border-color","red");
			document.getElementById(idSelect).focus();
			
		} 
		
		else if((total_price == "" )||(total_price == 0 )){
		  e.preventDefault();
		  $('#material_name').css("border-color","red");
			
			
		} 

		//return false;
		
	});
 

</script>
    