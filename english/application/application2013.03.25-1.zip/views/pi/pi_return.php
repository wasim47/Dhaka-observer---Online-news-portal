

<?php echo form_open("pi/pi_return_update"); ?>


<?php ///////////////////////////////////////////////////////////////////////////////////////////////////////////////  ?>
<div id="u_table">
<div class="uc_header"> <img src="<?php echo base_url();?>assets/images/Product.png" width="48" height="48" />&nbsp;&nbsp;Purchase Return</div>
    <div class="row1">
      <div class="right_col">
                          
                          
                    <table width="100%" border="0" cellspacing="4" >
              <tr>
                <td width="170">Purchase Invoice Number :</td>
                <td width="18"><?php echo form_input('pi_number','','id="pi_number" style="width:100px;" class="vertical" tabindex="1" ');?></td><td id="sms" style="display:none;color:red; font-size:09px; text-align:left;">This is not a Valid Purchase Invoice #</td>                
              </tr>
             <!-- <tr>
                <td>&nbsp;</td>
                <td  >&nbsp;</td><td width="41">&nbsp;</td>
                <td   >&nbsp;</td>
              </tr>
              <tr>
                <td>Supplier Address: </td>
                <td colspan="3" ><?php echo form_input('address',$supplierInfo[0]->address,'id="address" style="width:315px;"');?></td>
              </tr>--></table> 
            
            
                    
      </div>   
    </div>    
 <div class="row2"><table width="100%" border="0">
     <thead>
         <tr>
            <th width="12%"><div align="center"><span class="style4">Material Name</span></div></th>
           <th width="13%"><div align="center"><span class="style4">Material Code</span></div></th>
           <th width="15%"><div align="center"><span class="style4">Measurement Unit</span></div></th>
           <th width="15%"><div align="center"><span class="style4">Material Quantity</span></div></th>
           <th width="8%"><div align="center"><span class="style4">Unit Price</span></div></th>
           <th width="8%"><div align="center"><span class="style4">Net Price</span></div></th>
           <th width="1%"><div align="center"><span class="style4">&nbsp;&nbsp;</span></div></th>
         </tr>
     </thead>
         <tbody id="addContent">
         
		<tr style="border: 1px solid #7FB2CF; ">

          </tr>
        </tbody>
</table>
 
 </div>          
           
</div>    

<div class="row3"> <input type="hidden" class="vertical" tabindex="2" />
<p><?php echo form_submit('submit', 'Return','class="submit" ');?><input class="bb_close" onclick="hideOverlay();" href="#" title="Close" type="button" value="Cancel"></p>

    </div><!--end row3-->
</div><!--end u_table-->

<?php echo form_close();?>
<style>

#u_table {
  float: left;
  margin-bottom: 15px;
  min-height: 150px;
  text-align: right;
  width: 750px;
}

.uc_header {
  float: right;
  text-align:center;
  width:800px;
  font-size:18px;
  font-weight:bold;
  
}

.left_col {
  margin-top: 40px;
  float: right;
  padding-right: 50px;
}

.right_col {
  float: left;
  margin-top: 10px;
 
}

.row1 {

	height:100px;
}

#u_table select {
width:160px;

}

#u_table input ,#u_table select {
  background: none repeat scroll 0 0 #E6F4FF;
  border: 1px solid #7FB2CF;
  border-radius: 2px 2px 2px 2px;
  color: #205291;
  font-family: Verdana,Arial,Helvetica,sans-serif;
  font-size: 9px;
  font-weight: normal;
  height: 18px;
 /* width: 150px;*/
}

#u_table .row2 input ,#u_table .row2 select {
  background: none repeat scroll 0 0 #E6F4FF;
  border: 1px solid #7FB2CF;
  border-radius: 2px 2px 2px 2px;
  color: #205291;
  font-family: Verdana,Arial,Helvetica,sans-serif;
  font-size: 9px;
  font-weight: normal;
  height: 18px;
  width: 95%;
}

#u_table input:hover, #u_table input:focus #u_table select:hover, #u_table select:focus {
	border-color:#087DB5;
	background:#E6F4FF;
} 

 .bb_close , .submit {
  background-color: #7DA8D3;
  border: 1px solid #4B87C2;
  border-radius: 3px 3px 3px 3px;
  color: #FFFFFF;
  cursor: pointer;
  font-family: Arial,Helvetica,sans-serif;
  font-size: 12px;
  height: 21px;
  width: 120px;
  margin-left:30px;
}

.submit {
  background-color: #7DA8D3;
  border: 1px solid #4B87C2;
  border-radius: 3px 3px 3px 3px;
  color: #FFFFFF;
  cursor: pointer;
  font-family: Arial,Helvetica,sans-serif;
  font-size: 12px;
  height: 21px;
  margin-left: 220px;
  width: 120px;
}
  
  #u_table button  {
  background-color: #7DA8D3;
  border: 1px solid #4B87C2;
  border-radius: 3px 3px 3px 3px;
  color: #FFFFFF;
  cursor: pointer;
  font-family: Arial,Helvetica,sans-serif;
  font-size: 12px;
  height: 21px;
  
  width: 120px;
}
                      
              #groupCode1 {
  background: none repeat scroll 0 0 #E6F4FF;
  border: 1px solid #7FB2CF;
  border-radius: 2px 2px 2px 2px;
  color: #205291;
  font-family: Verdana,Arial,Helvetica,sans-serif;
  font-size: 9px;
  font-weight: normal;
  height: 16px;
  width: 80px;
}

#u_table textarea {
  background: none repeat scroll 0 0 #E6F4FF;
  border: 1px solid #7FB2CF;
  border-radius: 2px 2px 2px 2px;
  color: #205291;
  font-family: Verdana,Arial,Helvetica,sans-serif;
  font-size: 9px;
  font-weight: normal;
  width: 200px;
  height: 56px;
}
.style4 {font-size: 12px}
#u_table .row1 .right_col table {
}
#u_table .row1 .right_col table {
}
</style>
<script type="text/javascript">
 
 
 
	 
 
$(".vertical").keypress(function(event) {
        if(event.keyCode == 13) { 
        textboxes = $("input.vertical");

        currentBoxNumber = textboxes.index(this);
        if (textboxes[currentBoxNumber + 1] != null) {
            nextBox = textboxes[currentBoxNumber + 1]
           // nextBox.focus();
			if(nextBox.value !='')
			{
				nextBox = textboxes[currentBoxNumber + 2]
				
           // nextBox.focus();
			}
			
			nextBox.focus();
			
           event.preventDefault();
            return false 
            }
        }
    });
	
			$(document).keydown(function(e){
			if(e.keyCode==13)
			{
			 piReturnCheck();
             piTrigger();
				document.getElementById('pi_number').focus();
				
			}
		});
		
			$('#pi_number').focus(function(e){	
			
			$("#pi_number").css("border-color","#087DB5");
					$("#sms").css("display","none"); 
					
				});
		
			$('.submit').click(function(e){
		
		
		 var pi_number=$('#pi_number').val();

		
		//alert('supp='+total_price);
		
		
		
		if(pi_number == "" ){
		
			$('#pi_number').val('');
			$("#pi_number").css("border-color","red");
			$("#sms").css("display",""); 
			document.getElementById('pi_number').focus();
			e.preventDefault();
		
		} 

		//return false;
		
	});
 
 		function del(id)
		{
		
			var agree=confirm ('Are you want to delete This?')
			{
				if(agree)
				{
				
				var y= ($(id).attr("id"));
				
				var x=y.split('_');
				
				
				
				var material_name="material_name"+x[1];
				var material_code="material_code"+x[1];
				var measurement_unit="measurement_unit"+x[1];
				var material_qty="material_qty_"+x[1];
				var unit_price="unit_price"+x[1];
				var net_price="net_price"+x[1];
				var sub_group="sub_group"+x[1];
				
			
				//alert(total_price_final);
				
					document.getElementById(material_name).value='';
					document.getElementById(material_code).value='';
					document.getElementById(measurement_unit).value='';
					document.getElementById(material_qty).value='';

					document.getElementById(unit_price).value='';
					document.getElementById(net_price).value='';
					document.getElementById(sub_group).value='';
					
					
				 document.getElementById(y).style.display='none';
				 return true
				}
				else
				{
				return false;
				}
		}
		
		//confirm
		 //alert(y);
		
		
		} //del function END
		
		
		
function netPrice(id)
		{
		
			var y= ($(id).attr("id"));
				
			var x=y.split('_');

			var unit_price='unit_price'+x[2];
			var material_qty='material_qty_'+x[2];
			var material_qty_main='material_qty_main'+x[2];
			var material_qty_check='material_qty_check'+x[2];
			var net_price='net_price'+x[2];
			var material_code='material_code'+x[2];
			
				
				//alert(stock);
			
				var unitPrice=document.getElementById(unit_price).value;
				var material_new_Qty=Number(document.getElementById(material_qty).value);
				var material_qty_main=Number(document.getElementById(material_qty_main).value);
				var material_qty_check=Number(document.getElementById(material_qty_check).value);
				
				var materialQty=(material_qty_main-material_new_Qty);
				
				//alert(materialQty);
				
				suMaterialQty(material_code, materialQty, material_qty,material_qty_main);
				
			if ( material_new_Qty > material_qty_check)
			{
				alert('you can not increase value more then '+material_qty_check );
				
				document.getElementById(material_qty).value= material_qty_check;
				
				var netPrice=(unitPrice*material_qty_check);
				
				document.getElementById(net_price).value= netPrice;
				
			} else
			
			{				
				
				
				var netPrice=(unitPrice*material_new_Qty);
				
				document.getElementById(net_price).value= netPrice;
				
			}
			

		}
		
	
 

</script>