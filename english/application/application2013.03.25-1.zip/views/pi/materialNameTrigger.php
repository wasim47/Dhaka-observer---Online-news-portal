<?php 

 echo $materialName[0]->material_code."_".$materialName[0]->material_code."_".$materialName[0]->sub_group."_".$materialName[0]->material_group."_".$materialName[0]->measurement_unit ?>
				