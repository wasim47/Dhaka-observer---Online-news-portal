
<?php //+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++?>
<table width="100%" border="0" cellspacing="0" cellpadding="0">
	<tr>
	<td colspan="3"><img src="<?php echo base_url();?>assets/images/main_body_01.jpg" width="986" height="35" /></td>
	</tr>
	<tr>
	<td><img src="<?php echo base_url();?>assets/images/main_body_02.jpg" width="24" height="60" /></td>
	<td background="images/main_body_03.jpg" width="936" height="50">
	<table width="930"  border="0">
	<tr>
	<td width="49"><img src="<?php echo base_url();?>assets/images/pi.png" width="48" height="48" /></td>
	<td width="595"><h1><span class="material">Purchase Invoice </span></h1></td>
	<td width="33" class="border">
	<div align="center" class="section">
	<a class="pi" href="<?php echo base_url();?>pi/pi_return"><img src="<?php echo base_url();?>assets/images/return.png" width="30" height="30" border="0" />Return</a>
	</div>
	</td>	<td width="33" class="border">
	<div align="center" class="section">
	&nbsp;&nbsp;&nbsp;&nbsp;
	</div>
	</td>
    <td width="33" class="border">
	<div align="center" class="section">
	<a class="pi" href="<?php echo base_url();?>pi/create_pi"><img src="<?php echo base_url();?>assets/images/new1.png" width="30" height="30" border="0" />New</a>
	</div>
	</td>
	
	</tr>
	</table>
	</td>
	<td><img src="<?php echo base_url();?>assets/images/main_body_04.jpg" width="26" height="60" /></td>
	</tr>
	<tr>
	<td colspan="3"><img src="<?php echo base_url();?>assets/images/main_body_05.jpg" width="986" height="32" /></td>
	</tr>
</table>
    
    <table width="100%" border="0" cellspacing="0" cellpadding="0">
	<tr>
	<td colspan="3"><img src="<?php echo base_url();?>assets/images/main_body_01.jpg" width="986" height="35" /></td>
	</tr>
	<tr>
	<td style="background:url(assets/images/bar.jpg) repeat-y;" valign="top"><img src="<?php echo base_url();?>assets/images/main_body_02.jpg" width="24" height="181" /></td>
	<td width="936" height="181" align="center" style="background:url(assets/images/main_body_03.jpg) repeat-x; background-color:#dee4f0" >
	
	
	<div class="table_user_round1">
	  
		<table width="100%"  cellpadding="4" cellspacing="1">
        <tr >
          <td height="35" colspan="5" align="left" valign="top"><form action="" method="post">
              <table width="406" border="0" cellspacing="2" cellpadding="1">
                <!--<tr>
                  <td width="2%">&nbsp;</td>
                  <td width="17%" align="center" valign="middle"><span class="filter2">Filter :</span> </td>
                  <td width="26%" align="left" valign="middle"><label>
                    <input type="text" name="target" id="target" class="filter">
                  </label></td>
                  <td width="15%" align="left" valign="middle"><label>
                    <input type="submit" name="submit" value="Go" class="button">
                  </label></td>
                  <td width="40%" align="left" valign="middle"><input type="reset" name="reset" value="Reset" class="button"></td>
                </tr>-->
              </table>
          </form></td>
          </tr>
          <tr>
            <td width="57" height="26" align="center" bgcolor="#C9DEF1" class="table_header"><span class="style2">#</span></td>
            
            <td width="182" align="center" bgcolor="#C9DEF1" class="table_header">Purchase Invoice Number</td>
        <td width="117" align="center" bgcolor="#C9DEF1" class="table_header"><span class="style2">Suplier Name</span></td>
        <td width="208" align="center" bgcolor="#C9DEF1" class="table_header"><span class="style2">Invoice Date</span></td>
        <td width="162" align="center" bgcolor="#C9DEF1" class="table_header"><span class="style2">Created By</span></td>
       
        
            
                        
            <td width="153" align="center" bgcolor="#C9DEF1" class="table_header"><span class="style2">Action </span></td>
          </tr>
        </table>
		<div style="overflow:scroll; overflow-x:hidden; width:910px; max-height:313px;">
		  <table width="100%" cellpadding="4" cellspacing="1">
           
            <?php $i=1; foreach ($pis as $pi):?>
             <?php if($i%2!=0)
			 { $c="#E3EDF9";
			 } else {
				$c="#FFFFFF"; } ?>
            <tr class="table_hover" bgcolor="<?php echo $c; ?>">
              <td width="41" height="27" align="center"><span class="style9"><?php echo $i;?></span></td>
              <td width="112" align="left" class="section" style="padding-left:10px;"><a href="#" title="<?php echo $pi->pi_number;?>" class="style2" > <?php echo $pi->pi_number;?></a></td>
              <td width="101" align="center" class="style2"><?php echo $pi->supplier_name;?></td>
              <td width="124" align="center" class="style2"><?php echo $pi->invoice_date;?></td>
              <td width="119" align="center" class="style2"><?php echo $pi->insert_by;?></td>
                        
              
              <td width="93" align="center" class="section"><a href="<?php echo base_url();?>pi/preview_pi/<?php echo $pi->pi_number; ?>" class="pi" title="Preview"><img src="<?php echo base_url();?>assets/images/view.png" border="0"> </a>&nbsp;&nbsp;&nbsp; <a href="<?php echo base_url();?>pi/pi_del/<?php echo $pi->id; ?>" title="Delete"><img src="<?php echo base_url();?>assets/images/delete.png" border="0"></a> </td>
            </tr>
            <?php $i++; endforeach;?>           
          </table>
		</div>
	</div></td>
	<td style="background:url(assets/images/bar1.jpg) repeat-y;" valign="top"><img src="<?php echo base_url();?>assets/images/main_body_04.jpg" width="26" height="181" /></td>
	</tr>
	<tr>
	<td colspan="3"><img src="<?php echo base_url();?>assets/images/main_body_05.jpg" width="986" height="32" /></td>
	</tr>
	</table>
<div id="errors"><?php echo $message;?></div>
<?php //+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++?>


<div id="lightBox" align="center">
	<table cellspacing="0" cellpadding="0">
	<tr>
	<td colspan="3" align="right">
	<!--<a title="Close" class="bb_close" href="javascript:void(0);" onClick="hideOverlay();"></a>--></td>
	</tr>
	<tr>
	<td class="t_l"></td>
	<td class="t_c"></td>
	<td class="t_r"></td>
	</tr>
	<tr>
	<td class="c_l"></td>
	<td class="c_c">
	<div id="lightText"></div></td>
	<td class="c_r"></td>
	</tr>
	<tr>
	<td class="b_l"></td>
	<td class="b_c"></td>
	<td class="b_r"></td>
	</tr>
	</table>
</div>

<div id="lightBox4" align="center">
	<table cellspacing="0" cellpadding="0">
	<tr>
	<td colspan="3" align="right">
	<!--<a title="Close" class="bb_close" href="javascript:void(0);" onClick="hideOverlay();"></a>--></td>
	</tr>
	<tr>
	<td class="t_l"></td>
	<td class="t_c"></td>
	<td class="t_r"></td>
	</tr>
	<tr>
	<td class="c_l"></td>
	<td class="c_c">
	<div id="lightText4"></div></td>
	<td class="c_r"></td>
	</tr>
	<tr>
	<td class="b_l"></td>
	<td class="b_c"></td>
	<td class="b_r"></td>
	</tr>
	</table>
</div>


<script type="text/javascript">
//#########################################################################################


	//to retrive the subGroup of the selected Group//
	function supplierCode()
{
	
	//var supplierName=document.getElementById("idSelect").value;
	
	var str=$('#idSelect').val();
	
	var supplierName=encodeURIComponent(str);
	//alert(supplierName);
	
	var xmlRequest = GetXmlHttpObject();
	if (xmlRequest == null)
	return;
	var url="<?php echo base_url();?>pi/supplierCodeTrigger?supplierName="+supplierName;
	//alert(url);
	var browser=navigator.appName;
	if (browser=="Microsoft Internet Explorer")
		{
			xmlRequest.open("POST",url, true);
		}
	else
		{
			xmlRequest.open("GET",url, true);
		}
	xmlRequest.setRequestHeader("Content-Type", "application/x-www-formurlencoded");
	xmlRequest.onreadystatechange =function()
		{
			if(xmlRequest.readyState==4)
			{
				HandleAjaxResponse1(xmlRequest);
			}
		};
	xmlRequest.send(null);
	return false;
}



	function HandleAjaxResponse1(xmlRequest)
	{
		var xmlT=xmlRequest.responseText;
		
		
	var x=xmlT.split('~');
	
			if (x=='fail')
			{
			//alert('its not OK');
			//$('#idSelect').val('');
			$("#idSelect").css("border-color","red"); 
			//$("#idSelect").css("border-style","dotted"); 
			//$("#sms").css("display",""); 
			//document.getElementById('idSelect').focus();
			
			} else 
			{
			//$("#sms").css("display","none"); 
			$("#idSelect").css("background-color","#E6F4FF");
			$("#idSelect").css("border-style","solid");
			$("#idSelect").css("border-color","#7FB2CF");
			//alert('its  ok');
			
			//alert(xmlT);
			//document.getElementById("idSelect").value=x[0];
			document.getElementById("supplier_code").value=x[1];
			document.getElementById("email").value=x[2];
			document.getElementById("phone").value=x[3];
			document.getElementById("address").value=x[4];
			
			return false;
			
			}
	}	
//##########################materialName###Dataretrive############################################################		

	//to retrive the subGroup of the selected Group//
	function materialName()
{
	
	var dataName=document.getElementById("material_name").value;
	//alert(groupName);
	
	var xmlRequest = GetXmlHttpObject();
	if (xmlRequest == null)
	return;
	var url="<?php echo base_url();?>pi/materialNameTrigger?dataName="+dataName;
	//alert(url);
	var browser=navigator.appName;
	if (browser=="Microsoft Internet Explorer")
		{
			xmlRequest.open("POST",url, true);
		}
	else
		{
			xmlRequest.open("GET",url, true);
		}
	xmlRequest.setRequestHeader("Content-Type", "application/x-www-formurlencoded");
	xmlRequest.onreadystatechange =function()
		{
			if(xmlRequest.readyState==4)
			{
				HandleAjaxResponseMaterialName(xmlRequest);
			}
		};
	xmlRequest.send(null);
	return false;
}



	function HandleAjaxResponseMaterialName(xmlRequest)
	{
		var xmlT=xmlRequest.responseText;
		
		
	var x=xmlT.split('_');
	//alert(xmlT);
	//document.getElementById("idSelect").value=x[0];
	document.getElementById("mc").value=x[1];
	document.getElementById("sub_group2").value=x[2];
	document.getElementById("material_group").value=x[3];
	document.getElementById("measurement_unit").value=x[4];
	
	return false;
	}		
//############################PI##Trigger###########################################################	


	function piTrigger()
{
	
	var dataName=document.getElementById("pi_number").value;
	//alert(groupName);
	
		var xmlRequest = GetXmlHttpObject();
		if (xmlRequest == null)
		return;
		var url="<?php echo base_url();?>pi/piTrigger?dataName="+dataName;
		//alert(url);
		var browser=navigator.appName;
		if (browser=="Microsoft Internet Explorer")
			{
				xmlRequest.open("POST",url, true);
			}
		else
			{
				xmlRequest.open("GET",url, true);
			}
		xmlRequest.setRequestHeader("Content-Type", "application/x-www-formurlencoded");
		xmlRequest.onreadystatechange =function()
			{
				if(xmlRequest.readyState==4)
				{
					HandleAjaxResponse(xmlRequest,'addContent');
				}
			};
		xmlRequest.send(null);
		return false;
	
}




		function HandleAjaxResponse(xmlRequest,focusDiv)
	{
		var xmlT=xmlRequest.responseText;
		//alert(xmlT);
		document.getElementById(focusDiv).innerHTML=xmlT;
		//loadmylightbox();
		return false;
	}	
 //#########################################################################################
	function piCheck()
{
	
	var dataName=document.getElementById("pi_number").value;
	//alert(groupName);
	
		var xmlRequest = GetXmlHttpObject();
		if (xmlRequest == null)
		return;
		var url="<?php echo base_url();?>pi/piNumberCheck?dataName="+dataName;
		//alert(url);
		var browser=navigator.appName;
		if (browser=="Microsoft Internet Explorer")
			{
				xmlRequest.open("POST",url, true);
			}
		else
			{
				xmlRequest.open("GET",url, true);
			}
		xmlRequest.setRequestHeader("Content-Type", "application/x-www-formurlencoded");
		xmlRequest.onreadystatechange =function()
			{
				if(xmlRequest.readyState==4)
				{
					HandleAjaxResponse3(xmlRequest,dataName);
				}
			};
		xmlRequest.send(null);
		return false;
	
}



	function HandleAjaxResponse3(xmlRequest,dataName)
	{
		var xmlT=xmlRequest.responseText;
	var x=xmlT;
	
	
	if ((dataName==''))
	{
	//alert('its not OK');
	$('#pi_number').val('');
	$("#pi_number").css("border-color","red"); 
	$("#pi_number").css("border-style","dotted");
	alert('please Put somthing');  
	document.getElementById('pi_number').focus();
	
	} else 
	{
	$("#sms").css("display","none"); 
	$("#pi_number").css("background-color","#E6F4FF");
	$("#pi_number").css("border-style","solid");
	$("#pi_number").css("border-color","#7FB2CF");
	//alert('its  ok');
	}
	
	
	if ((x==0)||(dataName==''))
	{
	//alert('its not OK');
	$('#pi_number').val('');
	$("#pi_number").css("border-color","red"); 
	$("#pi_number").css("border-style","dotted"); 
	$("#sms").css("display",""); 
	document.getElementById('pi_number').focus();
	
	} else 
	{
	$("#sms").css("display","none"); 
	$("#pi_number").css("background-color","#E6F4FF");
	$("#pi_number").css("border-style","solid");
	$("#pi_number").css("border-color","#7FB2CF");
	//alert('its  ok');
	}
	
	
	
	return false;
	
	}	
 
	
	
//#########################################################################################	


 //##############################piReturnCheck############################################
	function piReturnCheck()
{
	
	var dataName=document.getElementById("pi_number").value;
	//alert(groupName);
	
		var xmlRequest = GetXmlHttpObject();
		if (xmlRequest == null)
		return;
		var url="<?php echo base_url();?>pi/piNumberCheck?dataName="+dataName;
		//alert(url);
		var browser=navigator.appName;
		if (browser=="Microsoft Internet Explorer")
			{
				xmlRequest.open("POST",url, true);
			}
		else
			{
				xmlRequest.open("GET",url, true);
			}
		xmlRequest.setRequestHeader("Content-Type", "application/x-www-formurlencoded");
		xmlRequest.onreadystatechange =function()
			{
				if(xmlRequest.readyState==4)
				{
					HandleAjaxResponsepiReturnCheck(xmlRequest,dataName);
				}
			};
		xmlRequest.send(null);
		return false;
	
}



	function HandleAjaxResponsepiReturnCheck(xmlRequest,dataName)
	{
		var xmlT=xmlRequest.responseText;
	var x=xmlT;
	
	
	if ((dataName==''))
	{
	//alert('its not OK');
	$('#pi_number').val('');
	$("#pi_number").css("border-color","red"); 
	$("#pi_number").css("border-style","dotted");
	alert('please Put somthing');  
	document.getElementById('pi_number').focus();
	
	} else 
	{
	$("#sms").css("display","none"); 
	$("#pi_number").css("background-color","#E6F4FF");
	$("#pi_number").css("border-style","solid");
	$("#pi_number").css("border-color","#7FB2CF");
	//alert('its  ok');
	}
	
	
	if ((x==1)||(dataName==''))
	{
	//alert('its not OK');
	$('#pi_number').val('');
	$("#pi_number").css("border-color","red"); 
	$("#pi_number").css("border-style","dotted"); 
	$("#sms").css("display",""); 
	document.getElementById('pi_number').focus();
	
	} else 
	{
	$("#sms").css("display","none"); 
	$("#pi_number").css("background-color","#E6F4FF");
	$("#pi_number").css("border-style","solid");
	$("#pi_number").css("border-color","#7FB2CF");
	//alert('its  ok');
	}
	
	
	
	return false;
	
	}	
 
	
	
//##############################piReturnCheck################################################	



//######################Start###suMaterialQty########################################################


	function suMaterialQty(material_code, materialQty, material_qty, material_qty_main)
{
	
	var dataName=document.getElementById(material_code).value;
	//alert(groupName);
	
		var xmlRequest = GetXmlHttpObject();
		if (xmlRequest == null)
		return;
		var url="<?php echo base_url();?>pi/suMaterialQty?dataName="+dataName;
		//alert(url);
		var browser=navigator.appName;
		if (browser=="Microsoft Internet Explorer")
			{
				xmlRequest.open("POST",url, true);
			}
		else
			{
				xmlRequest.open("GET",url, true);
			}
		xmlRequest.setRequestHeader("Content-Type", "application/x-www-formurlencoded");
		xmlRequest.onreadystatechange =function()
			{
				if(xmlRequest.readyState==4)
				{
					HandleAjaxResponse4(xmlRequest, materialQty, material_qty, material_qty_main);
				}
			};
		xmlRequest.send(null);
		return false;
	
}



	function HandleAjaxResponse4(xmlRequest, materialQty, material_qty, material_qty_main)
	{
		var xmlT=xmlRequest.responseText;
		
		//var retrival=material_qty_main;
		
		//document.getElementById(retrival).value= xmlT
	
	if(materialQty > xmlT)
	{
	
	alert('you can not return more then '+xmlT);
	
	//document.getElementById(material_qty).value=xmlT;
	
	}
	//alert(material_qty);
	//alert(xmlT);
	
	return false;
	
	}	
 
	
	
//###############################suMaterialQty################################################	

	function GetXmlHttpObject()
{		
	var xmlHttp=null;
	try
	{
		xmlHttp=new XMLHttpRequest();
	}
	catch (e)
	{
		// Internet Explorer
		try
			{
				xmlHttp=new ActiveXObject("Microsoft.XMLHTTP");
			}
		catch (e)
			{
				xmlHttp=new ActiveXObject("Msxml2.XMLHTTP");
			}
	}
	return xmlHttp;
}


</script>

