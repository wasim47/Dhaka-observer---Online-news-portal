
<?php //+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++?>
<table width="100%" border="0" cellspacing="0" cellpadding="0">
	<tr>
	<td colspan="3"><img src="<?php echo base_url();?>assets/images/main_body_01.jpg" width="986" height="35" /></td>
	</tr>
	<tr>
	<td><img src="<?php echo base_url();?>assets/images/main_body_02.jpg" width="24" height="60" /></td>
	<td background="images/main_body_03.jpg" width="936" height="50">
	<table width="930"  border="0">
	<tr>
	<td width="49"><img src="<?php echo base_url();?>assets/images/supplier.png" width="48" height="48" /></td>
	<td width="595"><h1><span class="material">Supplier Manager </span></h1></td>
	<!--<td width="28" class="border"><div align="center" class="section"><a href="javascript:void(0);" onClick="article_delete('delete','0');" ><img src="images/delete2.png" width="32" height="32" border="0" />Delete</a></div></td>-->
	<!--<td width="33" class="border"><div align="center" class="section"><a href="#" class="newFrm">
	<img src="images/edit1.png" width="32" height="32" border="0" />Edit</a></div></td>-->
	<td width="33" class="border">
	<div align="center" class="section">
	<a class="uCreate" href="<?php echo base_url();?>supplier_manage/create_supplier"><img src="<?php echo base_url();?>assets/images/new1.png" width="30" height="30" border="0" />New</a>
	</div>
	</td>
	
	</tr>
	</table>
	</td>
	<td><img src="<?php echo base_url();?>assets/images/main_body_04.jpg" width="26" height="60" /></td>
	</tr>
	<tr>
	<td colspan="3"><img src="<?php echo base_url();?>assets/images/main_body_05.jpg" width="986" height="32" /></td>
	</tr>
</table>
    
    <table width="100%" border="0" cellspacing="0" cellpadding="0">
	<tr>
	<td colspan="3"><img src="<?php echo base_url();?>assets/images/main_body_01.jpg" width="986" height="35" /></td>
	</tr>
	<tr>
	<td style="background:url(assets/images/bar.jpg) repeat-y;" valign="top"><img src="<?php echo base_url();?>assets/images/main_body_02.jpg" width="24" height="181" /></td>
	<td width="936" height="181" align="center" style="background:url(assets/images/main_body_03.jpg) repeat-x; background-color:#dee4f0" >
	
	
	<div class="table_user_round1">
	  
		<table width="100%"  cellpadding="4" cellspacing="1">
        <tr >
          <td height="35" colspan="5" align="left" valign="top"><form action="" method="post">
              <table width="406" border="0" cellspacing="2" cellpadding="1">
                <tr>
                  <!--<td width="2%">&nbsp;</td>
                  <td width="17%" align="center" valign="middle"><span class="filter2">Filter :</span> </td>
                  <td width="26%" align="left" valign="middle"><label>
                    <input type="text" name="target" id="target" class="filter">
                  </label></td>
                  <td width="15%" align="left" valign="middle"><label>
                    <input type="submit" name="submit" value="Go" class="button">
                  </label></td>
                  <td width="40%" align="left" valign="middle"><input type="reset" name="reset" value="Reset" class="button"></td>-->
                </tr>
              </table>
          </form></td>
          </tr>
          <tr>
            <td width="47" height="26" align="center" bgcolor="#C9DEF1" class="table_header"><span class="style2">#</span></td>
            
            <td width="138" align="center" bgcolor="#C9DEF1" class="table_header"><span class="style2">Supplier Name </span></td>
        <td width="113" align="center" bgcolor="#C9DEF1" class="table_header"><span class="style2">Customer  Code</span></td>
        <td width="175" align="center" bgcolor="#C9DEF1" class="table_header"><span class="style2">Address </span></td>
        <td width="136" align="center" bgcolor="#C9DEF1" class="table_header"><span class="style2">Phone</span></td>
        <td width="134" align="center" bgcolor="#C9DEF1" class="table_header"><span class="style2">Status</span></td>
        
            
                        
            <td width="127" align="center" bgcolor="#C9DEF1" class="table_header"><span class="style2">Action </span></td>
          </tr>
        </table>
		<div style="overflow:scroll; overflow-x:hidden; width:910px; max-height:313px;">
		  <table width="100%" cellpadding="4" cellspacing="1">
           
            <?php $i=1; foreach ($suppliers as $supplier):?>
             <?php if($i%2!=0)
			 { $c="#E3EDF9";
			 } else {
				$c="#FFFFFF"; } ?>
            <tr class="table_hover" bgcolor="<?php echo $c; ?>">
              <td width="41" height="27" align="center"><span class="style9"><?php echo $i;?></span></td>
              <td width="112" align="left" class="section" style="padding-left:10px;"><a href="#" title="<?php echo $supplier->supplier_name;?>" class="style2" > <?php echo $supplier->supplier_name;?></a></td>
              <td width="101" align="center" class="style2"><?php echo $supplier->supplier_code;?></td>
              <td width="124" align="center" class="style2"><?php echo $supplier->address;?></td>
              <td width="119" align="center" class="style2"><?php echo $supplier->phone;?></td>
              <td width="112" align="center"><span class="style2"><?php if(($supplier->active)==0){?>
               <a href="<?php echo base_url();?>supplier_manage/activate/<?php echo $supplier->id; ?>" title="Deactive"><img src="<?php echo base_url();?>assets/images/stop.png" border=0></a>
			  <?php } else { ?>
              <a href="<?php echo base_url();?>supplier_manage/deactivate/<?php echo $supplier->id; ?>" title="Deactive"><img src="<?php echo base_url();?>assets/images/active.png" border=0></a><?php } ?></span></td>
          
              
              <td width="93" align="center" class="section"><a href="<?php echo base_url();?>supplier_manage/edit_supplier/<?php echo $supplier->id; ?>" class="uCreate" title="Edit"><img src="<?php echo base_url();?>assets/images/pensil.png" border="0"> </a>&nbsp;&nbsp;&nbsp; <a href="<?php echo base_url();?>supplier_manage/supplier_del/<?php echo $supplier->id; ?>" title="Delete"><img src="<?php echo base_url();?>assets/images/delete.png" border="0"></a> </td>
            </tr>
            <?php $i++; endforeach;?>           
          </table>
		</div>
	</div></td>
	<td style="background:url(assets/images/bar1.jpg) repeat-y;" valign="top"><img src="<?php echo base_url();?>assets/images/main_body_04.jpg" width="26" height="181" /></td>
	</tr>
	<tr>
	<td colspan="3"><img src="<?php echo base_url();?>assets/images/main_body_05.jpg" width="986" height="32" /></td>
	</tr>
	</table>
<div id="errors"><?php echo $message;?></div>
<?php //+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++?>


<div id="lightBox" align="center">
	<table cellspacing="0" cellpadding="0">
	<tr>
	<td colspan="3" align="right">
	<!--<a title="Close" class="bb_close" href="javascript:void(0);" onClick="hideOverlay();"></a>--></td>
	</tr>
	<tr>
	<td class="t_l"></td>
	<td class="t_c"></td>
	<td class="t_r"></td>
	</tr>
	<tr>
	<td class="c_l"></td>
	<td class="c_c">
	<div id="lightText"></div></td>
	<td class="c_r"></td>
	</tr>
	<tr>
	<td class="b_l"></td>
	<td class="b_c"></td>
	<td class="b_r"></td>
	</tr>
	</table>
</div>

<div id="lightBox3" align="center">
	<table cellspacing="0" cellpadding="0">
	<tr>
	<td colspan="3" align="right">
	<!--<a title="Close" class="bb_close" href="javascript:void(0);" onClick="hideOverlay();"></a>--></td>
	</tr>
	<tr>
	<td class="t_l"></td>
	<td class="t_c"></td>
	<td class="t_r"></td>
	</tr>
	<tr>
	<td class="c_l"></td>
	<td class="c_c">
	<div id="lightText3"></div></td>
	<td class="c_r"></td>
	</tr>
	<tr>
	<td class="b_l"></td>
	<td class="b_c"></td>
	<td class="b_r"></td>
	</tr>
	</table>
</div>


<script type="text/javascript">
//#########################################################################################

	//to retrive the subGroup of the selected Group//
	function subGroupTrigger()
{
	
	var groupName=document.getElementById("groupName").value;
	//alert(groupName);
	var xmlRequest = GetXmlHttpObject();
	if (xmlRequest == null)
	return;
	var url="<?php echo base_url();?>material_manage/subGroup?groupName="+groupName;
	//alert(url);
	var browser=navigator.appName;
	if (browser=="Microsoft Internet Explorer")
		{
			xmlRequest.open("POST",url, true);
		}
	else
		{
			xmlRequest.open("GET",url, true);
		}
	xmlRequest.setRequestHeader("Content-Type", "application/x-www-formurlencoded");
	xmlRequest.onreadystatechange =function()
		{
			if(xmlRequest.readyState==4)
			{
				HandleAjaxResponse(xmlRequest,'dis');
			}
		};
	xmlRequest.send(null);
	
	groupCodeTrigger();
	
	return false;
}
		


		


	//#########################################################################################


	//#########################################################################################
		
	function groupCodeTrigger()
{
	
	var groupName=document.getElementById("groupName").value;
	//alert(groupName);
	
	var xmlRequest = GetXmlHttpObject();
	if (xmlRequest == null)
	return;
	var url="<?php echo base_url();?>material_manage/groupCodeTrigger?groupName="+groupName;
	//alert(url);
	var browser=navigator.appName;
	if (browser=="Microsoft Internet Explorer")
		{
			xmlRequest.open("POST",url, true);
		}
	else
		{
			xmlRequest.open("GET",url, true);
		}
	xmlRequest.setRequestHeader("Content-Type", "application/x-www-formurlencoded");
	xmlRequest.onreadystatechange =function()
		{
			if(xmlRequest.readyState==4)
			{
				HandleAjaxResponse(xmlRequest,'dis3');
			}
		};
	xmlRequest.send(null);
	return false;
}
		


	function subGroupCodeTrigger()
{
	
	var subGroupName=document.getElementById("subGroupName").value;
	//alert(groupName);
	
	var xmlRequest = GetXmlHttpObject();
	if (xmlRequest == null)
	return;
	var url="<?php echo base_url();?>material_manage/subGroupCodeTrigger?subGroupName="+subGroupName;
	//alert(url);
	var browser=navigator.appName;
	if (browser=="Microsoft Internet Explorer")
		{
			xmlRequest.open("POST",url, true);
		}
	else
		{
			xmlRequest.open("GET",url, true);
		}
	xmlRequest.setRequestHeader("Content-Type", "application/x-www-formurlencoded");
	xmlRequest.onreadystatechange =function()
		{
			if(xmlRequest.readyState==4)
			{
				HandleAjaxResponse(xmlRequest,'dis4');
			}
		};
	xmlRequest.send(null);
	return false;
}
		
	

	//#########################################################################################
	function HandleAjaxResponse(xmlRequest,focusDiv)
	{
		var xmlT=xmlRequest.responseText;
		//alert(xmlT);
		document.getElementById(focusDiv).innerHTML=xmlT;
		//loadmylightbox();
		return false;
	}	
	
	function GetXmlHttpObject()
{		
	var xmlHttp=null;
	try
	{
		xmlHttp=new XMLHttpRequest();
	}
	catch (e)
	{
		// Internet Explorer
		try
			{
				xmlHttp=new ActiveXObject("Microsoft.XMLHTTP");
			}
		catch (e)
			{
				xmlHttp=new ActiveXObject("Msxml2.XMLHTTP");
			}
	}
	return xmlHttp;
}


</script>
