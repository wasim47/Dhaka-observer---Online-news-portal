<style>

#u_table {
text-align:right;
	width:500px;
	
	float:left;
	margin-bottom:10px;
}

.uc_header {
  text-align:center;
  width:600px;
  font-size:18px;
  font-weight:bold;
  
}

.left_col {
  float: right;
  padding-right: 40px;
}

.right_col {
  float: right;
  padding-right: 40px;
}

#u_table select {
width:160px;

}

#u_table input ,#u_table select  {
  background: none repeat scroll 0 0 #E6F4FF;
  border: 1px solid #7FB2CF;
  border-radius: 2px 2px 2px 2px;
  color: #205291;
  font-family: Verdana,Arial,Helvetica,sans-serif;
  font-size: 9px;
  font-weight: normal;
  height: 18px;
  width: 125px;
}

#u_table input:hover, #u_table input:focus #u_table select:hover, #u_table select:focus {
	border-color:#087DB5;
	background:#E6F4FF;
} 

 .bb_close , .submit {
  background-color: #7DA8D3;
  border: 1px solid #4B87C2;
  border-radius: 3px 3px 3px 3px;
  color: #FFFFFF;
  cursor: pointer;
  font-family: Arial,Helvetica,sans-serif;
  font-size: 12px;
  height: 21px;
  width: 120px;
  margin-left:30px;
}

.submit {

  background-color: #7DA8D3;
  border: 1px solid #4B87C2;
  border-radius: 3px 3px 3px 3px;
  color: #FFFFFF;
  cursor: pointer;
  font-family: Arial,Helvetica,sans-serif;
  font-size: 12px;
  height: 21px;
  width: 120px;
  margin-left:150px;
}



</style>


<!--<div id="errors"><?php echo $message;?></div>-->

<?php
		$options = array(
						  '0'  => 'No',
						  '1'    => 'Yes'
						);
						
 		echo form_open("stock_manage/update_group");

?>


<?php ///////////////////////////////////////////////////////////////////////////////////////////////////////////////  ?>
<div class="uc_header">Material Group Update</div>
<div id="u_table">

	<?php //echo $editGroup['material_group']; ?>
    

      <p>
            Group Name: 
            <?php echo form_input('material_group',$editGroup['material_group'],'id="material_group"');?>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
      
            Group Code: 
            <?php echo form_input('code',$editGroup['code'],'id="code"');?>
      </p>
    


</div>
<p><?php echo form_hidden('id',$editGroup['id'],'id="id"');?><?php echo form_submit('submit', 'Update','class="submit"');?><input class="bb_close" onclick="hideOverlay();" href="#" title="Close" type="button" value="Cancel"></p>
<?php echo form_close();?>