
<?php //+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++?>
<table width="100%" border="0" cellspacing="0" cellpadding="0">
	<tr>
	<td colspan="3"><img src="<?php echo base_url();?>assets/images/main_body_01.jpg" width="986" height="35" /></td>
	</tr>
	<tr>
	<td><img src="<?php echo base_url();?>assets/images/main_body_02.jpg" width="24" height="60" /></td>
	<td background="images/main_body_03.jpg" width="936" height="50">
	<table width="930"  border="0">
	<tr>
	<td width="49"><img src="<?php echo base_url();?>assets/images/icon-48-article.png" width="48" height="48" /></td>
	<td width="595"><h1><span class="user">Material Sub Group Manager </span></h1></td>
	<!--<td width="28" class="border"><div align="center" class="section"><a href="javascript:void(0);" onClick="article_delete('delete','0');" ><img src="images/delete2.png" width="32" height="32" border="0" />Delete</a></div></td>-->
	<!--<td width="33" class="border"><div align="center" class="section"><a href="#" class="newFrm">
	<img src="images/edit1.png" width="32" height="32" border="0" />Edit</a></div></td>-->
	<td width="33" class="border">
	<div align="center" class="section">
	<a class="uCreate" href="<?php echo base_url();?>stock_manage/create_sub_group"><img src="<?php echo base_url();?>assets/images/new1.png" width="30" height="30" border="0" />New</a>
	</div>
	</td>
	
	</tr>
	</table>
	</td>
	<td><img src="<?php echo base_url();?>assets/images/main_body_04.jpg" width="26" height="60" /></td>
	</tr>
	<tr>
	<td colspan="3"><img src="<?php echo base_url();?>assets/images/main_body_05.jpg" width="986" height="32" /></td>
	</tr>
</table>
    
    <table width="100%" border="0" cellspacing="0" cellpadding="0">
	<tr>
	<td colspan="3"><img src="<?php echo base_url();?>assets/images/main_body_01.jpg" width="986" height="35" /></td>
	</tr>
	<tr>
	<td style="background:url(assets/images/bar.jpg) repeat-y;" valign="top"><img src="<?php echo base_url();?>assets/images/main_body_02.jpg" width="24" height="181" /></td>
	<td width="936" height="181" align="center" style="background:url(assets/images/main_body_03.jpg) repeat-x; background-color:#dee4f0" >
	
	
	<div class="table_subGroup">
	  
		<table width="100%"  cellpadding="4" cellspacing="1">
          <tr>
            <td width="26" height="26" align="center" bgcolor="#C9DEF1" class="table_header"><span class="style2">#</span></td>
            <td width="144" align="center" bgcolor="#C9DEF1" class="table_header"><span class="style2">Sub Material Group </span></td>
            <td width="125" align="center" bgcolor="#C9DEF1" class="table_header"><span class="style2">Sub Group Code</span></td>
            <td width="111" align="center" bgcolor="#C9DEF1" class="table_header"><span class="style2">Material Group </span></td>
            <td width="84" align="center" bgcolor="#C9DEF1" class="table_header"><span class="style2">Group Code</span></td>
            <td width="48" align="center" bgcolor="#C9DEF1" class="table_header"><span class="style2">Status </span></td>
            
            <td width="90" align="center" bgcolor="#C9DEF1" class="table_header">Create Date</td>
            <td width="98" align="center" bgcolor="#C9DEF1" class="table_header">Updaet Date</td>
            
            <td width="126" align="center" bgcolor="#C9DEF1" class="table_header"><span class="style2">Action </span></td>
          </tr>
        </table>
		<div style="overflow:scroll; overflow-x:hidden;  max-height:313px;">
		  <table width="100%" cellpadding="4" cellspacing="1">
           
            <?php $i=1; foreach ($datas as $data):?>
             <?php if($i%2!=0)
			 { $c="#E3EDF9";
			 } else {
				$c="#FFFFFF"; } ?>
            <tr class="table_hover" bgcolor="<?php echo $c; ?>">
              <td width="26" height="27" align="center"><span class="style9"><?php echo $i;?></span></td>
              <td width="142" align="left" class="section" style="padding-left:10px;"><a href="#" title="<?php echo $data->material_group;?>" class="style2" > <?php echo $data->sub_group;?></a></td>
              <td width="124" align="center" class="style2"><?php echo $data->sub_group_code;?></td>
              <td width="109" align="left" class="section" style="padding-left:10px;"><a href="#" title="<?php echo $data->material_group;?>" class="style2" > <?php echo $data->material_group;?></a></td>
              <td width="87" align="center" class="style2"><?php echo $data->group_code;?></td>
              <td width="58" align="center" class="style2"><?php if(($data->active)==0){?>
               <a href="<?php echo base_url();?>stock_manage/activate/<?php echo $data->id; ?>" title="Deactive"><img src="<?php echo base_url();?>assets/images/stop.png" border=0></a>
			  <?php } else { ?>
              <a href="<?php echo base_url();?>stock_manage/deactivate/<?php echo $data->id; ?>" title="Deactive"><img src="<?php echo base_url();?>assets/images/active.png" border=0></a><?php } ?></span></td>
              <td width="87" align="center"><span class="style2"><?php echo $data->create_date;?></td>
              <td width="112" align="center"><span class="style2"><?php echo $data->update_date;?></td>
          
              
              <td width="107" align="center" class="section"><a href="<?php echo base_url();?>stock_manage/edit_sub_group/<?php echo $data->id; ?>" class="uCreate" title="Edit"><img src="<?php echo base_url();?>assets/images/pensil.png" border="0"> </a>&nbsp;&nbsp;&nbsp; <a href="<?php echo base_url();?>stock_manage/sub_group_del/<?php echo $data->id; ?>" title="Delete"><img src="<?php echo base_url();?>assets/images/delete.png" border="0"></a> </td>
            </tr>
            <?php $i++; endforeach;?>           
            
          </table>
		</div>
	</div></td>
	<td style="background:url(assets/images/bar1.jpg) repeat-y;" valign="top"><img src="<?php echo base_url();?>assets/images/main_body_04.jpg" width="26" height="181" /></td>
	</tr>
	<tr>
	<td colspan="3"><img src="<?php echo base_url();?>assets/images/main_body_05.jpg" width="986" height="32" /></td>
	</tr>
	</table>
<div id="errors"><?php echo $message;?></div>
<?php //+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++?>


<div id="lightBox" align="center">
	<table cellspacing="0" cellpadding="0">
	<tr>
	<td colspan="3" align="right">
	<!--<a title="Close" class="bb_close" href="javascript:void(0);" onClick="hideOverlay();"></a>--></td>
	</tr>
	<tr>
	<td class="t_l"></td>
	<td class="t_c"></td>
	<td class="t_r"></td>
	</tr>
	<tr>
	<td class="c_l"></td>
	<td class="c_c">
	<div id="lightText"></div></td>
	<td class="c_r"></td>
	</tr>
	<tr>
	<td class="b_l"></td>
	<td class="b_c"></td>
	<td class="b_r"></td>
	</tr>
	</table>
</div>

<div id="lightBox3" align="center">
	<table cellspacing="0" cellpadding="0">
	<tr>
	<td colspan="3" align="right">
	<!--<a title="Close" class="bb_close" href="javascript:void(0);" onClick="hideOverlay();"></a>--></td>
	</tr>
	<tr>
	<td class="t_l"></td>
	<td class="t_c"></td>
	<td class="t_r"></td>
	</tr>
	<tr>
	<td class="c_l"></td>
	<td class="c_c">
	<div id="lightText3"></div></td>
	<td class="c_r"></td>
	</tr>
	<tr>
	<td class="b_l"></td>
	<td class="b_c"></td>
	<td class="b_r"></td>
	</tr>
	</table>
</div>

<script type="text/javascript">

	//#########################################################################################
		
	function groupCodeChanger()
{
	
	var groupName=document.getElementById("groupName").value;
	//alert(groupName);
	
	var xmlRequest = GetXmlHttpObject();
	if (xmlRequest == null)
	return;
	var url="<?php echo base_url();?>material_manage/groupCodeSearch?groupName="+groupName;
	//alert(url);
	var browser=navigator.appName;
	if (browser=="Microsoft Internet Explorer")
		{
			xmlRequest.open("POST",url, true);
		}
	else
		{
			xmlRequest.open("GET",url, true);
		}
	xmlRequest.setRequestHeader("Content-Type", "application/x-www-formurlencoded");
	xmlRequest.onreadystatechange =function()
		{
			if(xmlRequest.readyState==4)
			{
				HandleAjaxResponse_groupCodeChanger(xmlRequest);
			}
		};
	xmlRequest.send(null);
	return false;
}
		
function HandleAjaxResponse_groupCodeChanger(xmlRequest)
{
	var xmlT=xmlRequest.responseText;
	//alert(xmlT);
	document.getElementById("dis").innerHTML=xmlT;
	//loadmylightbox();
	return false;
}

		


	//#########################################################################################
	
		//#########################################################################################
		
	function groupNameChanger()
{
	
	var groupCode=document.getElementById("groupCode").value;
	//alert(groupName);
	
	var xmlRequest = GetXmlHttpObject();
	if (xmlRequest == null)
	return;
	var url="<?php echo base_url();?>material_manage/groupNameSearch?groupCode="+groupCode;
	//alert(url);
	var browser=navigator.appName;
	if (browser=="Microsoft Internet Explorer")
		{
			xmlRequest.open("POST",url, true);
		}
	else
		{
			xmlRequest.open("GET",url, true);
		}
	xmlRequest.setRequestHeader("Content-Type", "application/x-www-formurlencoded");
	xmlRequest.onreadystatechange =function()
		{
			if(xmlRequest.readyState==4)
			{
				HandleAjaxResponse_groupNameChanger(xmlRequest);
			}
		};
	xmlRequest.send(null);
	return false;
}
		
function HandleAjaxResponse_groupNameChanger(xmlRequest)
{
	var xmlT=xmlRequest.responseText;
	//alert(xmlT);
	document.getElementById("dis1").innerHTML=xmlT;
	//loadmylightbox();
	return false;
}

		

function GetXmlHttpObject()
{		
	var xmlHttp=null;
	try
	{
		xmlHttp=new XMLHttpRequest();
	}
	catch (e)
	{
		// Internet Explorer
		try
			{
				xmlHttp=new ActiveXObject("Microsoft.XMLHTTP");
			}
		catch (e)
			{
				xmlHttp=new ActiveXObject("Msxml2.XMLHTTP");
			}
	}
	return xmlHttp;
}
	//#########################################################################################


</script>