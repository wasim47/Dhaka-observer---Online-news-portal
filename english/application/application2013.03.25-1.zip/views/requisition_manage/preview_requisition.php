<script type="text/javascript" src="<?php echo base_url();?>assets/js/common.js"></script><!-- for light Box -->
<script type="text/javascript" src="<?php echo base_url();?>assets/js/jquery.lightbox-0.5.js"></script><!-- for light Box -->
<script type="text/javascript" src="<?php echo base_url();?>assets/js/jquery.autocomplete.js"></script><!-- for Auto Complete -->
<link rel="stylesheet" type="text/css" href="<?php echo base_url();?>assets/css/lightbox.css" /><!-- for light Box -->
<link rel="stylesheet" type="text/css" href="<?php echo base_url();?>assets/css/jquery.autocomplete.css" /><!-- for Auto Complete CSS -->
<style>

#u_table {
text-align:right;
	width:700px;
	/*min-height:400px;*/
	float:left;
	margin-bottom:30px;
}

.uc_header {
  float: right;
  text-align:center;
  width:700px;
  font-size:18px;
  font-weight:bold;
  
}

.left_col {
  margin-top: 10px;
  float: right;
  padding-right: 70px;
}

.right_col {
  float: left;
  margin-top: 10px;
  /*padding-right: 20px;*/
}

.row1 {

	height:120px;
}

#u_table select {
width:160px;

}

#u_table input ,#u_table select {
  background: none repeat scroll 0 0 #E6F4FF;
  border: 1px solid #7FB2CF;
  border-radius: 2px 2px 2px 2px;
  color: #205291;
  font-family: Verdana,Arial,Helvetica,sans-serif;
  font-size: 9px;
  font-weight: normal;
  height: 18px;
 /* width: 150px;*/
}

#u_table .row2 input ,#u_table .row2 select {
  background: none repeat scroll 0 0 #E6F4FF;
  border: 1px solid #7FB2CF;
  border-radius: 2px 2px 2px 2px;
  color: #205291;
  font-family: Verdana,Arial,Helvetica,sans-serif;
  font-size: 9px;
  font-weight: normal;
  height: 18px;
  width: 95%;
}

#u_table input:hover, #u_table input:focus #u_table select:hover, #u_table select:focus {
	border-color:#087DB5;
	background:#E6F4FF;
} 

 .bb_close , .submit {
  background-color: #7DA8D3;
  border: 1px solid #4B87C2;
  border-radius: 3px 3px 3px 3px;
  color: #FFFFFF;
  cursor: pointer;
  font-family: Arial,Helvetica,sans-serif;
  font-size: 12px;
  height: 21px;
  width: 120px;
  margin-left:300px;
}

.submit {
  background-color: #7DA8D3;
  border: 1px solid #4B87C2;
  border-radius: 3px 3px 3px 3px;
  color: #FFFFFF;
  cursor: pointer;
  font-family: Arial,Helvetica,sans-serif;
  font-size: 12px;
  height: 21px;
  margin-left: 300px;
  width: 120px;
}
  
  #u_table button  {
  background-color: #7DA8D3;
  border: 1px solid #4B87C2;
  border-radius: 3px 3px 3px 3px;
  color: #FFFFFF;
  cursor: pointer;
  font-family: Arial,Helvetica,sans-serif;
  font-size: 12px;
  height: 21px;
  
  width: 120px;
}
                      
              #groupCode1 {
  background: none repeat scroll 0 0 #E6F4FF;
  border: 1px solid #7FB2CF;
  border-radius: 2px 2px 2px 2px;
  color: #205291;
  font-family: Verdana,Arial,Helvetica,sans-serif;
  font-size: 9px;
  font-weight: normal;
  height: 16px;
  width: 80px;
}

#u_table textarea {
  background: none repeat scroll 0 0 #E6F4FF;
  border: 1px solid #7FB2CF;
  border-radius: 2px 2px 2px 2px;
  color: #205291;
  font-family: Verdana,Arial,Helvetica,sans-serif;
  font-size: 9px;
  font-weight: normal;
  width: 200px;
  height: 56px;
}
.style4 {font-size: 12px}

#u_table .row1 .right_col table {
}
#u_table .row1 .right_col table {
}
.uc_header1 {	float: none;
	text-align:center;
	width:850px;
	font-size:18px;
	font-weight:bold;  
}
</style>


<?php echo form_open("io_manage/insert_io"); ?>


<?php ///////////////////////////////////////////////////////////////////////////////////////////////////////////////  ?>






<div id="u_table">
<div class="uc_header"> Preview <span class="uc_header1">Material Requisition</span></div>
<div class="row1">  
            <div class="left_col">
            
                  
                    <table width="121%" border="0">
             
              
              <tr>
                <td width="122"><div align="right">Delivery  Date:</div></td>
                <td width="106" id="groupCode1"><div align="center"><strong><?php echo $requisitionInfo[0]->delivery_date; ?></strong></div></td>
              </tr>
              <tr>
                <td width="122"><div align="right">Delivery Location:</div></td>
                <td width="106" id="groupCode1"><div align="center"><strong><?php echo $requisitionInfo[0]->delivery_location; ?></strong></div></td>
              </tr>  
            </table>
         
                  
      </div>
              
                          <div class="right_col">
                    <table width="100%" border="0" cellspacing="4" >               
       <tr>
                <td width="122"><div align="right">Issue Order Date:</div></td>
                <td width="106" id="groupCode1"><div align="center"><strong><?php echo $requisitionInfo[0]->r_date; ?></strong></div></td>
     </tr> 
                  
      <tr>
          <td width="122"><div align="right">Requisit's By:</div></td>
          <td width="106" id="groupCode1"><div align="center"><strong><?php echo $requisitionInfo[0]->requisitors_name; ?></strong></div></td>
     </tr>         
              </table>
                
      </div>   
    </div>    
 <div class="row2"><table width="100%" border="0">
     <thead>
         <tr>
           <th width="12%"><div align="center"><span class="style4">Work Order</span></div></th>
           <th width="12%"><div align="center"><span class="style4">Material Name</span></div></th>
           <th width="13%"><div align="center"><span class="style4">Material Code</span></div></th>
           <th width="6%"><div align="center"><span class="style4">Size</span></div></th>
           <th width="8%"><div align="center"><span class="style4">Quantity</span></div></th>
           <th width="6%"><div align="center"><span class="style4">UOM</span></div></th>
           <th width="15%"><div align="center"><span class="style4">Comment</span></div></th>
           <th width="1%">&nbsp;</th>
         </tr>
     </thead>
         <tbody id="addContent"><?php foreach($previewData as $data):?>
          <tr>
            <td id="groupCode1"><div align="center"><?php echo $data->iwo_number;?></div></td>
            <td id="groupCode1"><div align="center"><?php echo $data->material_name;?></div></td>
            <td id="groupCode1"><div align="center"><?php echo $data->material_code;?></div></td>
            <td id="groupCode1"><div align="center"><?php echo $data->size;?></div></td>
            <td id="groupCode1"><div align="center"><?php echo $data->material_qty;?></div></td>
            <td id="groupCode1"><div align="center"><?php echo $data->measurement_unit;?></div></td>
            <td id="groupCode1"><div align="center"><?php echo $data->comment;?></div></td>
            <td width="1%">&nbsp;</td>
          </tr><?php endforeach; ?>   
        </tbody>
</table>
 
 </div>          
           
</div>    

<div class="row3">
<p><input class="bb_close" onclick="hideOverlay();" href="#" title="Close" type="button" value="Cancel"></p>

    </div><!--end row3-->
</div><!--end u_table-->




    