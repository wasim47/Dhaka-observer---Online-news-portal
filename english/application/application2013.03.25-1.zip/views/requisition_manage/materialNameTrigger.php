<?php 

 echo $materialName[0]->material_code."_".$materialName[0]->measurement_unit ?>
				