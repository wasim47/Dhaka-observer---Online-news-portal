<script type="text/javascript" src="<?php echo base_url();?>assets/js/jquery.autocomplete.js"></script><!-- for Auto Complete -->
<link rel="stylesheet" type="text/css" href="<?php echo base_url();?>assets/css/jquery.autocomplete.css" /><!-- for Auto Complete CSS -->
<style>

#u_table {
text-align:right;
	width:850px;
	/*min-height:400px;*/
	float:left;
	margin-bottom:30px;
}

.uc_header {
	float: none;
	text-align:center;
	width:850px;
	font-size:18px;
	font-weight:bold;  
}

.left_col {
  margin-top: 10px;
  float: right;
  padding-right: 70px;
}

.right_col {
  float: left;
  margin-top: 10px;
  /*padding-right: 20px;*/
}

.row1 {

	height:70px;
}

#u_table select {
width:160px;

}

#u_table input ,#u_table select {
  background: none repeat scroll 0 0 #E6F4FF;
  border: 1px solid #7FB2CF;
  border-radius: 2px 2px 2px 2px;
  color: #205291;
  font-family: Verdana,Arial,Helvetica,sans-serif;
  font-size: 9px;
  font-weight: normal;
  height: 18px;
 /* width: 150px;*/
}

#u_table .row2 input ,#u_table .row2 select {
  background: none repeat scroll 0 0 #E6F4FF;
  border: 1px solid #7FB2CF;
  border-radius: 2px 2px 2px 2px;
  color: #205291;
  font-family: Verdana,Arial,Helvetica,sans-serif;
  font-size: 9px;
  font-weight: normal;
  height: 18px;
  width: 95%;
}

#u_table input:hover, #u_table input:focus #u_table select:hover, #u_table select:focus {
	border-color:#087DB5;
	background:#E6F4FF;
} 

 .bb_close , .submit {
  background-color: #7DA8D3;
  border: 1px solid #4B87C2;
  border-radius: 3px 3px 3px 3px;
  color: #FFFFFF;
  cursor: pointer;
  font-family: Arial,Helvetica,sans-serif;
  font-size: 12px;
  height: 21px;
  width: 120px;
  margin-left:30px;
}

.submit {
  background-color: #7DA8D3;
  border: 1px solid #4B87C2;
  border-radius: 3px 3px 3px 3px;
  color: #FFFFFF;
  cursor: pointer;
  font-family: Arial,Helvetica,sans-serif;
  font-size: 12px;
  height: 21px;
  margin-left: 300px;
  width: 120px;
}
  
  #u_table button  {
  background-color: #7DA8D3;
  border: 1px solid #4B87C2;
  border-radius: 3px 3px 3px 3px;
  color: #FFFFFF;
  cursor: pointer;
  font-family: Arial,Helvetica,sans-serif;
  font-size: 12px;
  height: 21px;
  
  width: 120px;
}
                      
              #groupCode1 {
  background: none repeat scroll 0 0 #E6F4FF;
  border: 1px solid #7FB2CF;
  border-radius: 2px 2px 2px 2px;
  color: #205291;
  font-family: Verdana,Arial,Helvetica,sans-serif;
  font-size: 9px;
  font-weight: normal;
  height: 16px;
  width: 80px;
}

#u_table textarea {
  background: none repeat scroll 0 0 #E6F4FF;
  border: 1px solid #7FB2CF;
  border-radius: 2px 2px 2px 2px;
  color: #205291;
  font-family: Verdana,Arial,Helvetica,sans-serif;
  font-size: 9px;
  font-weight: normal;
  width: 200px;
  height: 56px;
}
.style4 {font-size: 12px}

#u_table .row1 .right_col table {
}
#u_table .row1 .right_col table {
}
</style>


<?php echo form_open("requisition_manage/insert_requisition"); ?>


<?php ///////////////////////////////////////////////////////////////////////////////////////////////////////////////  ?>
<div id="u_table">
<div class="uc_header">Requisition Order</div>
<div class="row1">  
            <div class="left_col">
            
                  
                    <table width="121%" border="0">
              <tr><td>Delivery Date<?php echo form_input('delivery_date','','id="deliveryDate" style="width:70px;" class="vertical" tabindex="4"');?></td></tr>
              <tr><td>Delivery Location<?php echo form_input('delivery_location','','id="delivery_location" style="width:70px;" class="vertical" tabindex="4"');?></td></tr>
                          
            </table>
         
                  
      </div>
              
                          <div class="right_col">
                    <table width="100%" border="0" cellspacing="4" >
              <tr>
                <td width="125">Requisition Date:</td>
                <td width="106" id="groupCode1"><div align="center"><strong><?php echo date('Y-m-d');?><?php echo form_hidden('io_Date',date('Y-m-d'),'id="io_Date"');?></strong></div></td>               
              </tr>
              <tr>
                <td id="sms" style="display:none;color:red; font-size:09px; text-align:left;">&nbsp;</td>
              
                <td colspan="3" ></td>
              </tr>
              </table>
            
            
                    
      </div>   
    </div>    
 <div class="row2"><table width="100%" border="0">
     <thead>
         <tr>
           <th width="8%"><div align="center"><span class="style4">Work Order #</span></div></th>
           <th width="12%"><div align="center"><span class="style4">Material Name</span></div></th>
           <th width="11%"><div align="center"><span class="style4">Material Code</span></div></th>
           <th width="10%"><div align="center"><span class="style4">Size</span></div></th>
           <th width="8%"><div align="center"><span class="style4">Quantity</span></div></th>
           <th width="16%"><div align="center"><span class="style4">UOM</span></div></th>
           <th width="9%"><div align="center"><span class="style4">Remaks</span></div></th>
           <th width="2%">&nbsp;</th>
        </tr>
     </thead>
         <tbody id="addContent">
          <tr>
            <td><?php echo form_input('iwo_number','','id="iwo_number" style="width:100px;" class="vertical" tabindex="1" onblur="iwoCheck()"');?></td>
            <td><?php echo form_input('material_name','','id="material_name" autocomplete="off" "  class="vertical"  tabindex="2"  ');?></td>
            <td><?php echo form_input('material_code','','id="material_code2" readonly=""');?></td>
            <td><?php echo form_input('size','',' id="size" tabindex="3" class="vertical" ');?></td>
            <td><?php echo form_input('material_qty','','id="material_qty" tabindex="4" class="vertical" ');?></td>
            <td><?php echo form_input('measurement_unit','','id="measurement_unit" readonly="" ');?></td>
            <td><?php echo form_input('comment','','id="comment" tabindex="5" ');?></td>
            <td width="2%">&nbsp;</td>
          </tr>
          <tr><input id="prof_count" type="hidden" value="1" name="prof_count"></tr>
           
			<tr id="prof_1"></tr>
            <tr >&nbsp;</tr>
		
        </tbody>
</table>
 
 </div>          
           
</div>    

<div class="row3">
<p><?php echo form_submit('submit', 'Submit','class="submit" ');?><input class="bb_close" onclick="hideOverlay();" href="#" title="Close" type="button" value="Cancel"></p>

    </div><!--end row3-->
</div><!--end u_table-->

<?php echo form_close();?>	

<script type="text/javascript">

		
		 $().ready(function() {
			$("#material_name").autocomplete("io_manage/materialAc", {
				width: 150,
				matchContains: true,
				selectFirst: false
			});
			
			$("#material_name").result(function(event, data, formatted) {	
				materialName();
			});
		});
 
 
$(".vertical").keypress(function(event) {
        if(event.keyCode == 13) { 
        textboxes = $("input.vertical");

        currentBoxNumber = textboxes.index(this);
        if (textboxes[currentBoxNumber + 1] != null) {
            nextBox = textboxes[currentBoxNumber + 1]
           // nextBox.focus();
			if(nextBox.value !='')
			{
				nextBox = textboxes[currentBoxNumber + 2]
				
           // nextBox.focus();
			}
			
			nextBox.focus();
			
           event.preventDefault();
            return false 
            }
        }
    });
	
	
	function totalPrice()
		{
			var unitPrice=document.getElementById("unit_price_avg").value;
			var materialQty=document.getElementById("material_qty").value;
			
			if(isNaN(materialQty)){
			alert('please Put Number');
			document.getElementById("material_qty").value='';
			document.getElementById('material_qty').focus();	
			}else{
			
			var totalPrice=(unitPrice*materialQty);
			document.getElementById("total_price").value= totalPrice;
			}

		}
	
			$(document).keydown(function(e){
			if(e.keyCode==17)
			{
             	var material_name=$('#material_name').val();
				var material_code2=$('#material_code2').val();
				var material_qty=$('#material_qty').val(); 
				
				if ((material_name==''))
				{	
					$("#material_name").css("border-color","red");					
					$("#material_name").css("background-color","#FF9595");
					document.getElementById('material_name').focus();				
				} else if (material_code2=='')
				{
					$("#material_code2").css("border-color","red");					
					$("#material_code2").css("background-color","#FF9595");
					document.getElementById('material_code2').focus();
				
				}else if (material_qty=='')
				{
					$("#material_qty").css("border-color","red");					
					$("#material_qty").css("background-color","#FF9595");
					document.getElementById('material_qty').focus();
				} 
				else 				
				{
					$("#material_name").css("background-color","#E6F4FF");
					$("#material_name").css("border-style","solid");
					$("#material_name").css("border-color","#7FB2CF");
					
					$("#material_code2").css("background-color","#E6F4FF");
					$("#material_code2").css("border-style","solid");
					$("#material_code2").css("border-color","#7FB2CF");
					
					$("#material_qty").css("background-color","#E6F4FF");
					$("#material_qty").css("border-style","solid");
					$("#material_qty").css("border-color","#7FB2CF");	
					
					
					
				add25();
				document.getElementById('iwo_number').focus();
				}
			}
		});
		
		//
				
		
				
		function add25()
		{
			//alert("new row working");
				$(document).ready(function(){
				 //alert("Add25");
			
				var ac=addStaff();
			
				function addStaff(){
				//alert("In");
				var iwo_number=$('#iwo_number').val();
				var material_name=$('#material_name').val();
				var material_code2=$('#material_code2').val();
				var size=$('#size').val();
				var material_qty=$('#material_qty').val();
				var measurement_unit=$('#measurement_unit').val();
				var comment=$('#comment').val();
				
				
				
				strCountField = '#prof_count';      
				intFields = $(strCountField).val();
				intFields = Number(intFields);    
				newField = intFields + 1;
				
				strNewField = '<tr class="prof blueBox" id="prof_' + newField + '">\
							<input type="hidden" id="id' + newField + '" name="id' + newField + '" value="-1" />\
<td><input type="text" id="iwo_number' + newField + '" name="iwo_number1[]" maxlength="10" value='+iwo_number+' readonly="" /></td>\
<td><input type="text" id="material_name' + newField + '" name="material_name1[]" maxlength="10" value="'+material_name+'" readonly="" /></td>\
            <td><input type="text" id="material_code2' + newField + '" name="material_code1[]" maxlength="10" value='+material_code2+' readonly="" /></td>\
    <td><input type="text" id="size' + newField + '" name="size1[]" maxlength="10" value='+size+' readonly="" /></td>\
<td><input type="text" id="material_qty' + newField + '" name="material_qty1[]" maxlength="10" value='+material_qty+' readonly="" /></td>\
  <td><input type="text" id="measurement_unit' + newField + '" name="measurement_unit1[]" maxlength="10" value='+measurement_unit+' readonly="" /></td>\
<td><input type="text" id="comment' + newField + '" name="comment1[]" maxlength="10" value='+comment+' readonly="" /></td>\
<td><div align="left"><span class="style5"><img src="<?php echo base_url();?>assets/images/delete.png" width="20" height="20" border="0" id="prof_' + newField + '"  value="prof_' + newField + '" onClick="del(this)" ></span></div></td>\
          </tr>\
		  <div class="nopass"><!-- clears floats --></div>\
		  '
		  ;

				$("#prof_" + intFields).after(strNewField);    
				$("#prof_" + newField).slideDown("medium");
				$(strCountField).val(newField);				
				$('#iwo_number').val('');				
				$('#material_name').val('');
				$('#material_code2').val('');
				$('#size').val('');
				$('#material_qty').val('');
				$('#measurement_unit').val('');
				$('#comment').val('');
				//alert(strNewField);
				}
				
			
		});
		}
		
		
		function del(id)
		{
		
			var agree=confirm ('Are you want to delete This?')
			{
				if(agree)
				{
				
				var y= ($(id).attr("id"));
				
				var z=y.split('_');
				
				
				var iwo_number="iwo_number"+z[1];
				var material_name="material_name"+z[1];
				var material_code2="material_code2"+z[1];
				var size="size"+z[1];
				var measurement_unit="measurement_unit"+z[1];
				var material_qty="material_qty"+z[1];
				var comment="comment"+z[1];
				
				
				
			
					document.getElementById(iwo_number).value='';
					document.getElementById(material_name).value='';
					document.getElementById(material_code2).value='';
					document.getElementById(size).value='';
					document.getElementById(measurement_unit).value='';
					document.getElementById(material_qty).value='';
					document.getElementById(comment).value='';
					
					
				 document.getElementById(y).style.display='none';
				 return true
				}
				else
				{
				return false;
				}
		}
		
		//confirm
		 //alert(y);
		
		
		}//del function END
		
		
	
	

	
	
	
			$('.submit').click(function(e){
		
		
		
		 var gtotal_price=$('#gtotal_price').val();
		
		//alert(material_name);
		
		
		if(gtotal_price == "" ){
		
			$('#gtotal_price').val('');
			$("#gtotal_price").css("border-color","red");
			document.getElementById('iwo_number').focus();
			e.preventDefault();
		
		}
		
		
		//return false;
		
	});
 
$(function() {
		$( "#deliveryDate" ).datepicker({ dateFormat: 'yy-mm-dd' });
	});
</script>
    