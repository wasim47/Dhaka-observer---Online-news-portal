
<?php //+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++?>
<table width="100%" border="0" cellspacing="0" cellpadding="0">
	<tr>
	<td colspan="3"><img src="<?php echo base_url();?>assets/images/main_body_01.jpg" width="986" height="35" /></td>
	</tr>
	<tr>
	<td><img src="<?php echo base_url();?>assets/images/main_body_02.jpg" width="24" height="60" /></td>
	<td background="images/main_body_03.jpg" width="936" height="50">
	<table width="930"  border="0">
	<tr>
	<td width="49"><img src="<?php echo base_url();?>assets/images/pi.png" width="48" height="48" /></td>
	<td width="595"><h1><span class="material">Materials Requisition</span></h1></td>
    		<td width="10" class="border">
	<div align="center" class="section">
	&nbsp;
	</div>
	</td>
    
	<td width="33" class="border">
	<div align="center" class="section">
	<a class="pi" href="<?php echo base_url();?>requisition_manage/create_requisition"><img src="<?php echo base_url();?>assets/images/new1.png" width="30" height="30" border="0" />New</a>
	</div>
	</td>
	
	</tr>
	</table>
	</td>
	<td><img src="<?php echo base_url();?>assets/images/main_body_04.jpg" width="26" height="60" /></td>
	</tr>
	<tr>
	<td colspan="3"><img src="<?php echo base_url();?>assets/images/main_body_05.jpg" width="986" height="32" /></td>
	</tr>
</table>
    
    <table width="100%" border="0" cellspacing="0" cellpadding="0">
	<tr>
	<td colspan="3"><img src="<?php echo base_url();?>assets/images/main_body_01.jpg" width="986" height="35" /></td>
	</tr>
	<tr>
	<td style="background:url(assets/images/bar.jpg) repeat-y;" valign="top"><img src="<?php echo base_url();?>assets/images/main_body_02.jpg" width="24" height="181" /></td>
	<td width="936" height="181" align="center" style="background:url(assets/images/main_body_03.jpg) repeat-x; background-color:#dee4f0" >
	
	
	<div class="table_user_round1">
	  
		<table width="100%"  cellpadding="2" cellspacing="1">
        
          <thead><tr>
            <td width="50" height="26" align="center" bgcolor="#C9DEF1" class="table_header"><span class="style2">#</span></td>
            
            <td width="166" align="center" bgcolor="#C9DEF1" class="table_header">Requisition Number</td>
        <td width="141" align="center" bgcolor="#C9DEF1" class="table_header">Requisitiors Name</td>
        <td width="136" align="center" bgcolor="#C9DEF1" class="table_header">Requisition Date</td>
        <td width="127" align="center" bgcolor="#C9DEF1" class="table_header">Delivery Date</td>
        <td width="132" align="center" bgcolor="#C9DEF1" class="table_header">Delivery Location</td>
        <td width="146" align="center" bgcolor="#C9DEF1" class="table_header"><span class="style2">Action</span></td>

          </tr><thead>
        
		
		 
           
            <?php $i=1; foreach ($ios as $io):?>
             <?php if($i%2!=0)
			 { $c="#E3EDF9";
			 } else {
				$c="#FFFFFF"; } ?>
            <tr class="table_hover" bgcolor="<?php echo $c; ?>">
              <td width="50" height="27" align="center"><span class="style9"><?php echo $i;?></span></td>
              <td width="166" align="left" class="section" style="padding-left:10px;"><a href="#" title="<?php echo $io->id;?>" class="style2" > <?php echo $io->id;?></a></td>
              <td width="141" align="center" class="style2"><?php echo $io->requisitors_name;?></td>
              <td width="136" align="center" class="style2"><?php echo $io->r_date;?></td>
              <td width="127" align="center" class="style2"><?php echo $io->delivery_date;?></td>
              <td width="132" align="center" class="style2"><?php echo $io->delivery_location;?></td>
                        
              
              <td width="146" align="center" class="section"><a href="<?php echo base_url();?>requisition_manage/preview_requisition/<?php echo $io->id; ?>" class="pi" title="Preview"><img src="<?php echo base_url();?>assets/images/view.png" border="0"> </a>&nbsp;&nbsp;&nbsp; <a href="<?php echo base_url();?>requisition_manage/requisition_del/<?php echo $io->id; ?>" title="Delete"><img src="<?php echo base_url();?>assets/images/delete.png" border="0"></a> </td>
            </tr>
            <?php $i++; endforeach;?>           
          </table>
		</div>
	</div></td>
	<td style="background:url(assets/images/bar1.jpg) repeat-y;" valign="top"><img src="<?php echo base_url();?>assets/images/main_body_04.jpg" width="26" height="181" /></td>
	</tr>
	<tr>
	<td colspan="3"><img src="<?php echo base_url();?>assets/images/main_body_05.jpg" width="986" height="32" /></td>
	</tr>
	</table>
<div id="errors"><?php echo $message;?></div>
<?php //+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++?>


<div id="lightBox" align="center">
	<table cellspacing="0" cellpadding="0">
	<tr>
	<td colspan="3" align="right">
	<!--<a title="Close" class="bb_close" href="javascript:void(0);" onClick="hideOverlay();"></a>--></td>
	</tr>
	<tr>
	<td class="t_l"></td>
	<td class="t_c"></td>
	<td class="t_r"></td>
	</tr>
	<tr>
	<td class="c_l"></td>
	<td class="c_c">
	<div id="lightText"></div></td>
	<td class="c_r"></td>
	</tr>
	<tr>
	<td class="b_l"></td>
	<td class="b_c"></td>
	<td class="b_r"></td>
	</tr>
	</table>
</div>

<div id="lightBox4" align="center">
	<table cellspacing="0" cellpadding="0">
	<tr>
	<td colspan="3" align="right">
	<!--<a title="Close" class="bb_close" href="javascript:void(0);" onClick="hideOverlay();"></a>--></td>
	</tr>
	<tr>
	<td class="t_l"></td>
	<td class="t_c"></td>
	<td class="t_r"></td>
	</tr>
	<tr>
	<td class="c_l"></td>
	<td class="c_c">
	<div id="lightText4"></div></td>
	<td class="c_r"></td>
	</tr>
	<tr>
	<td class="b_l"></td>
	<td class="b_c"></td>
	<td class="b_r"></td>
	</tr>
	</table>
</div>


<script type="text/javascript">
//#############################material##Details####################################################




	//to retrive the subGroup of the selected Group//
	function materialName()
{
	
	var dataName=document.getElementById("material_name").value;
	//alert(groupName);
	
	var xmlRequest = GetXmlHttpObject();
	if (xmlRequest == null)
	return;
	var url="<?php echo base_url();?>requisition_manage/materialNameTrigger?dataName="+dataName;
	//alert(url);
	var browser=navigator.appName;
	if (browser=="Microsoft Internet Explorer")
		{
			xmlRequest.open("POST",url, true);
		}
	else
		{
			xmlRequest.open("GET",url, true);
		}
	xmlRequest.setRequestHeader("Content-Type", "application/x-www-formurlencoded");
	xmlRequest.onreadystatechange =function()
		{
			if(xmlRequest.readyState==4)
			{
				HandleAjaxResponseMaterialName(xmlRequest);
			}
		};
	xmlRequest.send(null);
	return false;
}



	function HandleAjaxResponseMaterialName(xmlRequest)
	{
		var xmlT=xmlRequest.responseText;
		
		if(xmlT!='')
		{
			var x=xmlT.split('_');
			//alert(xmlT);
			//document.getElementById("idSelect").value=x[0];
			document.getElementById("material_code2").value=x[0];
			document.getElementById("measurement_unit").value=x[1];
	
	} 
	
	
	return false;
	}		
//#########################################################################################	
	function iwoCheck()
{
	
	var dataName=document.getElementById("iwo_number").value;
	//alert(groupName);
	
	if(dataName!='')
	{
	
		var xmlRequest = GetXmlHttpObject();
		if (xmlRequest == null)
		return;
		var url="<?php echo base_url();?>io_manage/iwoNumberCheck?dataName="+dataName;
		//alert(url);
		var browser=navigator.appName;
		if (browser=="Microsoft Internet Explorer")
			{
				xmlRequest.open("POST",url, true);
			}
		else
			{
				xmlRequest.open("GET",url, true);
			}
		xmlRequest.setRequestHeader("Content-Type", "application/x-www-formurlencoded");
		xmlRequest.onreadystatechange =function()
			{
				if(xmlRequest.readyState==4)
				{
					HandleAjaxResponseiwoCheck(xmlRequest,dataName);
				}
			};
		xmlRequest.send(null);
		return false;
		
		} else 
		{
			$('#iwo_number').val('');
			$("#iwo_number").css("border-color","red"); 
			$("#iwo_number").css("border-style","dotted"); 
			$("#sms").css("display",""); 
			$('#sms').html('Empty?');
			document.getElementById('iwo_number').focus();
			
		}
	
}



	function HandleAjaxResponseiwoCheck(xmlRequest,dataName)
	{
		var xmlT=xmlRequest.responseText;
	
	
	if ((xmlT==1))
	{
	//alert('its not OK');
	$('#iwo_number').val('');
	$("#iwo_number").css("border-color","red"); 
	$("#iwo_number").css("border-style","dotted"); 
	$("#sms").css("display",""); 
	$('#sms').html('Type Correct work order #');
	document.getElementById('iwo_number').focus();
	
	} else 
	{
	$("#sms").css("display","none"); 
	$("#iwo_number").css("background-color","#E6F4FF");
	$("#iwo_number").css("border-style","solid");
	$("#iwo_number").css("border-color","#7FB2CF");
	//alert('its  ok');
	}
	
	
	
	return false;
	
	}	
 
 //##############################ioCheck##################################################
	function ioCheck()
{
	
	var dataName=document.getElementById("io_number").value;
	//alert(groupName);
	
		var xmlRequest = GetXmlHttpObject();
		if (xmlRequest == null)
		return;
		var url="<?php echo base_url();?>io_manage/ioNumberCheck?dataName="+dataName;
		//alert(url);
		var browser=navigator.appName;
		if (browser=="Microsoft Internet Explorer")
			{
				xmlRequest.open("POST",url, true);
			}
		else
			{
				xmlRequest.open("GET",url, true);
			}
		xmlRequest.setRequestHeader("Content-Type", "application/x-www-formurlencoded");
		xmlRequest.onreadystatechange =function()
			{
				if(xmlRequest.readyState==4)
				{
					HandleAjaxResponseioCheck(xmlRequest,dataName);
				}
			};
		xmlRequest.send(null);
		return false;
	
}



	function HandleAjaxResponseioCheck(xmlRequest,dataName)
	{
		var xmlT=xmlRequest.responseText;
	var x=xmlT;
	
	
	if ((dataName==''))
	{
	//alert('its not OK');
	$('#io_number').val('');
	$("#io_number").css("border-color","red"); 
	$("#io_number").css("border-style","dotted");
	alert('please Put somthing');  
	document.getElementById('io_number').focus();
	
	} else 
	{
	$("#sms").css("display","none"); 
	$("#io_number").css("background-color","#E6F4FF");
	$("#io_number").css("border-style","solid");
	$("#io_number").css("border-color","#7FB2CF");
	//alert('its  ok');
	}
	
	
	if ((x==1)||(dataName==''))
	{
	//alert('its not OK');
	$('#io_number').val('');
	$("#io_number").css("border-color","red"); 
	$("#io_number").css("border-style","dotted"); 
	$("#sms").css("display",""); 
	document.getElementById('io_number').focus();
	
	} else 
	{
	$("#sms").css("display","none"); 
	$("#io_number").css("background-color","#E6F4FF");
	$("#io_number").css("border-style","solid");
	$("#io_number").css("border-color","#7FB2CF");
	//alert('its  ok');
	}
	
	
	
	return false;
	
	}	
 
	
	
//#########################################################################################	


//############################ioTrigger###########################################################	


	function ioTrigger()
{
	
	var dataName=document.getElementById("io_number").value;
	//alert(groupName);
	
		var xmlRequest = GetXmlHttpObject();
		if (xmlRequest == null)
		return;
		var url="<?php echo base_url();?>io_manage/ioTrigger?dataName="+dataName;
		//alert(url);
		var browser=navigator.appName;
		if (browser=="Microsoft Internet Explorer")
			{
				xmlRequest.open("POST",url, true);
			}
		else
			{
				xmlRequest.open("GET",url, true);
			}
		xmlRequest.setRequestHeader("Content-Type", "application/x-www-formurlencoded");
		xmlRequest.onreadystatechange =function()
			{
				if(xmlRequest.readyState==4)
				{
					HandleAjaxResponseioTrigger(xmlRequest,'addContent');
				}
			};
		xmlRequest.send(null);
		return false;
	
}




		function HandleAjaxResponseioTrigger(xmlRequest,focusDiv)
	{
		var xmlT=xmlRequest.responseText;
		//alert(xmlT);
		document.getElementById(focusDiv).innerHTML=xmlT;
		//loadmylightbox();
		return false;
	}	
 //#############################ioTrigger##################################################	
	
//#########################################################################################	
	function GetXmlHttpObject()
{		
	var xmlHttp=null;
	try
	{
		xmlHttp=new XMLHttpRequest();
	}
	catch (e)
	{
		// Internet Explorer
		try
			{
				xmlHttp=new ActiveXObject("Microsoft.XMLHTTP");
			}
		catch (e)
			{
				xmlHttp=new ActiveXObject("Msxml2.XMLHTTP");
			}
	}
	return xmlHttp;
}


</script>

