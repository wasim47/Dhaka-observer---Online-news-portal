
<?php $this->load->view('includes/header_report');?>

<?php $this->load->view($main_content);?>

<?php $this->load->view('includes/footer_report');?>
