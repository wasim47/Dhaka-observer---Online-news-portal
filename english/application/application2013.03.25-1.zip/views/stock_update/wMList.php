
<?php $i=1; foreach($m_list as $data):?>
          <tr>
           
            <td><?php echo form_input('material_name',$data->material_name,'id="material_name" style="width:115px;" readonly=""');?></td>
            <td><?php echo form_input('material_code',$data->material_code,'id="material_code" style="width:115px;" readonly=""');?></td>
            <td><?php echo form_input('measurement_unit',$data->measurement_unit,'id="measurement_unit" style="width:115px;"');?></td>
            <td><?php echo form_input('material_qty',$data->material_qty,'id="material_qty" onkeyup="netPrice(this)"style="width:115px;"');?><?php echo form_input('material_qty_main',$data->material_qty,'id="material_qty_main" style="display:none;" readonly="" ');?></td>
            <td><?php echo form_input('unit_price',$data->unit_price,'id="unit_price" style="width:115px;" readonly=""');?></td>
            <td><?php echo form_input('net_price',$data->net_price,'id="net_price" style="width:115px;" readonly=""');?></td>

          </tr>
         <?php $i++; endforeach; ?>