
<?php $i=1; foreach($m_list as $data):?>
          <tr>
           <td><?php echo $i ;?></td>
            <td><?php echo $data->material_name; ?></td>
            <td><?php echo $data->material_code; ?></td>
            <td><?php echo $data->material_group; ?></td>
            <td> <?php echo $data->sub_group; ?></td>
            <td><?php echo $data->measurement_unit; ?></td>
            <td><?php echo $data->material_qty; ?></td>
            <td><?php echo $data->unit_price; ?></td>
            <td><?php echo $data->net_price; ?></td>
			<td  align="center"><a class="materialN" href="<?php echo base_url();?>stock_update/stock_update_history/<?php echo $data->material_code; ?>" title="History"><img src="<?php echo base_url();?>assets/images/history.png" border="0"></a></td>
 
          </tr>
         <?php $i++; endforeach; ?>