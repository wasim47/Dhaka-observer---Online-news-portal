
<?php //+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++?>
<table width="100%" border="0" cellspacing="0" cellpadding="0">
	<tr>
	<td colspan="3"><img src="<?php echo base_url();?>assets/images/main_body_01.jpg" width="986" height="35" /></td>
	</tr>
	<tr>
	<td><img src="<?php echo base_url();?>assets/images/main_body_02.jpg" width="24" height="60" /></td>
	<td background="images/main_body_03.jpg" width="936" height="50">
	<table width="930"  border="0">
	<tr>
	<td width="49"><img src="<?php echo base_url();?>assets/images/Product.png" width="48" height="48" /></td>
	<td width="595"><h1><span class="material">Update Stock</span></h1></td>
	<!--<td width="28" class="border"><div align="center" class="section"><a href="javascript:void(0);" onClick="article_delete('delete','0');" ><img src="images/delete2.png" width="32" height="32" border="0" />Delete</a></div></td>-->
	<!--<td width="33" class="border"><div align="center" class="section"><a href="#" class="newFrm">
	<img src="images/edit1.png" width="32" height="32" border="0" />Edit</a></div></td>-->
	<td width="33" class="border">
	<div align="center" class="section">
	<a class="uCreate" href="<?php echo base_url();?>stock_update/waste_return"><img src="<?php echo base_url();?>assets/images/return.png" width="30" height="30" border="0" />Return</a>
	</div>
	</td>
    
	<td width="33" class="border">
	<div align="center" class="section">
	<a class="uCreate" href="<?php echo base_url();?>stock_update/create_stock_update"><img src="<?php echo base_url();?>assets/images/new1.png" width="30" height="30" border="0" />New</a>
	</div>
	</td>
	</tr>
	</table>
	</td>
	<td><img src="<?php echo base_url();?>assets/images/main_body_04.jpg" width="26" height="60" /></td>
	</tr>
	<tr>
	<td colspan="3"><img src="<?php echo base_url();?>assets/images/main_body_05.jpg" width="986" height="32" /></td>
	</tr>
</table>
    
    <table width="100%" border="0" cellspacing="0" cellpadding="0">
	<tr>
	<td colspan="3"><img src="<?php echo base_url();?>assets/images/main_body_01.jpg" width="986" height="35" /></td>
	</tr>
	<tr>
	<td style="background:url(assets/images/bar.jpg) repeat-y;" valign="top"><img src="<?php echo base_url();?>assets/images/main_body_02.jpg" width="24" height="181" /></td>
	<td width="936" height="181" align="center" style=" background:url(assets/images/main_body_03.jpg) repeat-x; background-color:#dee4f0" >
	
	
	<div class="table_user_round1">
	  <p style="float:right; margin-right:20px; color:#999999">To get a single information of stock update please type &nbsp;&nbsp;&nbsp;
      
      <input style=" color:#999999 ; text-align:center; " id="suMaterialName" type="text" name='material_name' value='Material Name'  autocomplete="off"   class="vertical"   tabindex="3" onblur="if(this.value=='') this.value='Material Name'" onFocus="if(this.value =='Material Name' ) this.value=''" /><a style="" class="back" href="<?php echo base_url();?>stock_update" title="History"><!--<img width="26" height="26" src="<?php echo base_url();?>assets/images/back_image.png" border="0">-->Back</a></p>
		<table width="100%"  cellpadding="4" cellspacing="1">
        
        <thead>
          <tr>
            <td width="48" height="26" align="center" bgcolor="#C9DEF1" class="table_header"><span class="style2">#</span></td>
            
             <td width="147" align="center" bgcolor="#C9DEF1" class="table_header"><span class="style2">Material Name </span></td>
        <td width="117" align="center" bgcolor="#C9DEF1" class="table_header"><span class="style2">Material  Code</span></td>
        <td width="147" align="center" bgcolor="#C9DEF1" class="table_header"><span class="style2">Material Group </span></td>
        <td width="147" align="center" bgcolor="#C9DEF1" class="table_header"><span class="style2">Sub Group </span></td>
        <td width="150" align="center" bgcolor="#C9DEF1" class="table_header"><span class="style2">Measurement Unit</span></td>
        <td width="132" align="center" bgcolor="#C9DEF1" class="table_header"><span class="style2">Current Stock</span></td>
        <td width="132" align="center" bgcolor="#C9DEF1" class="table_header"><span class="style2">Unit Price</span></td>
         <td width="132" align="center" bgcolor="#C9DEF1" class="table_header"><span class="style2">Total Price</span></td>
            
                        
            <td width="129" align="center" bgcolor="#C9DEF1" class="table_header"><span class="style2">Action </span></td>
          </tr></thead>
        
		
		  <tbody id="singleshow">
           
            <?php $i=1; foreach ($datas as $data):?>
            
             <?php if($i%2!=0){ $c="#E3EDF9"; } else { $c="#FFFFFF"; } ?>
             
            <tr  class="table_hover" bgcolor="<?php echo $c; ?>">
              <td width="33" height="27" align="center"><span class="style9"><?php echo $i;?></span></td>
              <td width="89" align="left" class="section" style="padding-left:10px;"><a href="#" title="<?php echo $data->material_group;?>" class="style2" > <?php echo $data->material_name;?></a></td>
              <td width="75" align="center" class="style2"><?php echo $data->material_code;?></td>
              <td width="91" align="center" class="style2"><?php echo $data->material_group;?></td>
              <td width="88" align="center" class="style2"><?php echo $data->sub_group;?></td>
              <td width="97" align="center"><span class="style2"><?php echo $data->measurement_unit;?></span></td>
              <td width="83" align="center"><span class="style2"><?php echo $data->material_qty;?></span></td>
              <td width="97" align="center"><span class="style2"><?php echo $data->unit_price;?></span></td>
              <td width="70" align="center"><span class="style2"><?php echo $data->net_price;?></span></td>
          
              
              <td width="94" align="center" class="section"><a class="uCreate" href="<?php echo base_url();?>stock_update/stock_update_history/<?php echo $data->material_code; ?>" title="History"><img src="<?php echo base_url();?>assets/images/history.png" border="0"></a> </td>
            </tr>
            <?php $i++; endforeach;?> 
            </tbody>          
          </table>
		
	</div></td>
	<td style="background:url(assets/images/bar1.jpg) repeat-y;" valign="top"><img src="<?php echo base_url();?>assets/images/main_body_04.jpg" width="26" height="181" /></td>
	</tr>
	<tr>
	<td colspan="3"><img src="<?php echo base_url();?>assets/images/main_body_05.jpg" width="986" height="32" /></td>
	</tr>
	</table>
<div id="errors"><?php echo $message;?></div>
<?php //+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++?>


<div id="lightBox" align="center">
	<table cellspacing="0" cellpadding="0">
	<tr>
	<td colspan="3" align="right">
	<!--<a title="Close" class="bb_close" href="javascript:void(0);" onClick="hideOverlay();"></a>--></td>
	</tr>
	<tr>
	<td class="t_l"></td>
	<td class="t_c"></td>
	<td class="t_r"></td>
	</tr>
	<tr>
	<td class="c_l"></td>
	<td class="c_c">
	<div id="lightText"></div></td>
	<td class="c_r"></td>
	</tr>
	<tr>
	<td class="b_l"></td>
	<td class="b_c"></td>
	<td class="b_r"></td>
	</tr>
	</table>
</div>

<div id="lightBox3" align="center">
	<table cellspacing="0" cellpadding="0">
	<tr>
	<td colspan="3" align="right">
	<!--<a title="Close" class="bb_close" href="javascript:void(0);" onClick="hideOverlay();"></a>--></td>
	</tr>
	<tr>
	<td class="t_l"></td>
	<td class="t_c"></td>
	<td class="t_r"></td>
	</tr>
	<tr>
	<td class="c_l"></td>
	<td class="c_c">
	<div id="lightText3"></div></td>
	<td class="c_r"></td>
	</tr>
	<tr>
	<td class="b_l"></td>
	<td class="b_c"></td>
	<td class="b_r"></td>
	</tr>
	</table>
</div>


<script type="text/javascript">
//#########################################################################################	

	 $().ready(function() {
			$("#suMaterialName").autocomplete("stock_update/wMaterialAc", {
				width: 150,
				matchContains: true,
				selectFirst: false
			});
			
			$("#suMaterialName").result(function(event, data, formatted) {	
				suMaterialName();
			});
		});
		
		
	//to retrive the subGroup of the selected Group//
	function suMaterialName()
{	
	var dataName=document.getElementById("suMaterialName").value;
	//alert(groupName);
	
	var xmlRequest = GetXmlHttpObject();
	if (xmlRequest == null)
	return;
	var url="<?php echo base_url();?>stock_update/materialNameTrigger?dataName="+dataName;
	//alert(url);
	var browser=navigator.appName;
	if (browser=="Microsoft Internet Explorer")
		{
			xmlRequest.open("POST",url, true);
		}
	else
		{
			xmlRequest.open("GET",url, true);
		}
	xmlRequest.setRequestHeader("Content-Type", "application/x-www-formurlencoded");
	xmlRequest.onreadystatechange =function()
		{
			if(xmlRequest.readyState==4)
			{
			     $(".back").css("display","block"); 
				HandleAjaxResponseName(xmlRequest);
			}
		};
	xmlRequest.send(null);
	return false;
}

 $().ready(function() {
			$("#suMaterialCode").autocomplete("stock_update/materialAc", {
				width: 150,
				matchContains: true,
				selectFirst: false
			});
			
			$("#suMaterialName").result(function(event, data, formatted) {	
				suMaterialCode();
			});
		});
		
	function suMaterialCode()
{	
	var dataName=document.getElementById("suMaterialCode").value;
	//alert(groupName);
	
	var xmlRequest = GetXmlHttpObject();
	if (xmlRequest == null)
	return;
	var url="<?php echo base_url();?>stock_update/materialCodeTrigger?dataName="+dataName;
	//alert(url);
	var browser=navigator.appName;
	if (browser=="Microsoft Internet Explorer")
		{
			xmlRequest.open("POST",url, true);
		}
	else
		{
			xmlRequest.open("GET",url, true);
		}
	xmlRequest.setRequestHeader("Content-Type", "application/x-www-formurlencoded");
	xmlRequest.onreadystatechange =function()
		{
			if(xmlRequest.readyState==4)
			{
				HandleAjaxResponseCode(xmlRequest);
			}
		};
	xmlRequest.send(null);
	return false;
}



		function HandleAjaxResponseName(xmlRequest)
	{
		var xmlT=xmlRequest.responseText;
		//alert(xmlT);
		document.getElementById('singleshow').innerHTML=xmlT;
		//loadmylightbox();
		test333();
		return false;
	}


	function piTrigger()
{
	
	var dataName=document.getElementById("pi_number").value;
	//alert(groupName);
	
		var xmlRequest = GetXmlHttpObject();
		if (xmlRequest == null)
		return;
		var url="<?php echo base_url();?>stock_update/piTrigger?dataName="+dataName;
		//alert(url);
		var browser=navigator.appName;
		if (browser=="Microsoft Internet Explorer")
			{
				xmlRequest.open("POST",url, true);
			}
		else
			{
				xmlRequest.open("GET",url, true);
			}
		xmlRequest.setRequestHeader("Content-Type", "application/x-www-formurlencoded");
		xmlRequest.onreadystatechange =function()
			{
				if(xmlRequest.readyState==4)
				{
					HandleAjaxResponse(xmlRequest,'addContent');
				}
			};
		xmlRequest.send(null);
		return false;
	
}




		function HandleAjaxResponse(xmlRequest,focusDiv)
	{
		var xmlT=xmlRequest.responseText;
		//alert(xmlT);
		document.getElementById(focusDiv).innerHTML=xmlT;
		//loadmylightbox();
		return false;
	}	
 //#########################################################################################	
	function piCheck()
{
	
	var dataName=document.getElementById("pi_number").value;
	//alert(groupName);
	
		var xmlRequest = GetXmlHttpObject();
		if (xmlRequest == null)
		return;
		var url="<?php echo base_url();?>stock_update/piNumberCheck?dataName="+dataName;
		//alert(url);
		var browser=navigator.appName;
		if (browser=="Microsoft Internet Explorer")
			{
				xmlRequest.open("POST",url, true);
			}
		else
			{
				xmlRequest.open("GET",url, true);
			}
		xmlRequest.setRequestHeader("Content-Type", "application/x-www-formurlencoded");
		xmlRequest.onreadystatechange =function()
			{
				if(xmlRequest.readyState==4)
				{
					HandleAjaxResponse3(xmlRequest,dataName);
				}
			};
		xmlRequest.send(null);
		return false;
	
}



	function HandleAjaxResponse3(xmlRequest,dataName)
	{
		var xmlT=xmlRequest.responseText;
	var x=xmlT;
	
	if ((x==0)||(dataName==''))
	{
	//alert('its not OK');
	$('#pi_number').val('');
	$("#pi_number").css("border-color","red"); 
	$("#pi_number").css("border-style","dotted"); 
	$("#sms").css("display","");
	document.getElementById('pi_number').focus();
	
	} else 
	{
	$("#sms").css("display","none"); 
	$("#pi_number").css("background-color","#E6F4FF");
	$("#pi_number").css("border-style","solid");
	$("#pi_number").css("border-color","#7FB2CF");
	//alert('its  ok');
	}
	
	
	
	return false;
	}	

	
	
//#########################################################################################	
	function GetXmlHttpObject()
{		
	var xmlHttp=null;
	try
	{
		xmlHttp=new XMLHttpRequest();
	}
	catch (e)
	{
		// Internet Explorer
		try
			{
				xmlHttp=new ActiveXObject("Microsoft.XMLHTTP");
			}
		catch (e)
			{
				xmlHttp=new ActiveXObject("Msxml2.XMLHTTP");
			}
	}
	return xmlHttp;
}


</script>

