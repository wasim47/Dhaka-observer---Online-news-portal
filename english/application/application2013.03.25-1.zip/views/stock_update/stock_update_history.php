<?php echo form_open("stock_update/insert_su"); ?>


<?php ///////////////////////////////////////////////////////////////////////////////////////////////////////////////  ?>
<div id="u_table">
<div class="uc_header"> <img src="<?php echo base_url();?>assets/images/Product.png" width="48" height="48" />Stock Update History</div>
    <div class="row1">
      <div class="right_col">
 
      </div>   
    </div>    
 <div class="row2"><table width="100%" border="0">
     <thead style="color:#FFFFFF">
                  <tr>
            <td width="28" height="26" align="center"  class="table_header1"><span class="style2">#</span></td>
            
            <td width="105" align="center"  class="table_header1"><span class="style2">Material Name </span></td>
        <td width="115" align="center"  class="table_header1"><span class="style2">Material quantity </span></td>
        <td width="78" align="center"  class="table_header1"><span class="style2">Unit Price</span></td>
        <td width="81" align="center"  class="table_header1"><span class="style2">Total Price</span></td>
        <td width="117" align="center"  class="table_header1"><span class="style2">Purchase Invoice</span></td>
        <td width="110" align="center"  class="table_header1"><span class="style2">Issue Order</span></td>
        <td width="79" align="center"  class="table_header1"><span class="style2">Comment</span></td>
        <td width="89" align="center"  class="table_header1">Date</td>
         <td width="30" align="center"  class="table_header1"><span class="style2">Local</span></td>
            
        </tr>

     </thead>
         <tbody id="addContent">
         
		<?php $i=1; foreach($datas as $data):?>
          <tr>
           <td width="28" height="27" align="center"><span class="style9"><?php echo $i;?></span></td>
            <td width="105" align="left" class="section" style="padding-left:10px;"><a href="#" title="<?php echo $data->material_group;?>" class="style2" > <?php echo $data->material_name;?></a></td>
            <td width="115" align="center" class="style2"><?php echo $data->material_qty;?></td>
            <td width="78" align="center" class="style2"><?php echo $data->unit_price;?></td>
            <td width="81" align="center" class="style2"><?php echo $data->net_price;?></td>
            <td width="117" align="center"><span class="style2"><?php echo $data->pi_number;?></span></td>
            <td width="110" align="center"><span class="style2"><?php echo $data->io_number;?></span></td>
            <td width="79" align="center"><span class="style2"><?php echo $data->comment;?></span></td>
            <td width="89" align="center"><span class="style2"><?php echo $data->date;?></span></td>
            <td width="30" align="center"><span class="style2"><?php echo $data->local;?></span></td>
          </tr>
      
      
      
      
      

      
          
          
          
         <?php $i++; endforeach; ?>
         
        </tbody>
</table>
 
 </div>          
           
</div>    

<div class="row3"> <input type="hidden"  tabindex="2" />
<p><input class="bb_close" onclick="hideOverlay();" href="#" title="Close" type="button" value="OK"></p>

    </div><!--end row3-->
</div><!--end u_table-->

<?php echo form_close();?>	



<style>

#u_table {
  float: left;
  margin-bottom: 15px;
  min-height: 150px;
  text-align: right;
  width: 750px;
}

.uc_header {
  float: right;
  text-align:center;
  width:800px;
  font-size:18px;
  font-weight:bold;
  
}

.left_col {
  margin-top: 40px;
  float: right;
  padding-right: 50px;
}

.right_col {
  float: left;
  margin-top: 10px;
 
}

.row1 {

	height:60px;
}

#u_table select {
width:160px;

}

#u_table input ,#u_table select {
  background: none repeat scroll 0 0 #E6F4FF;
  border: 1px solid #7FB2CF;
  border-radius: 2px 2px 2px 2px;
  color: #205291;
  font-family: Verdana,Arial,Helvetica,sans-serif;
  font-size: 9px;
  font-weight: normal;
  height: 18px;
 /* width: 150px;*/
}

#u_table .row2 input ,#u_table .row2 select {
  background: none repeat scroll 0 0 #E6F4FF;
  border: 1px solid #7FB2CF;
  border-radius: 2px 2px 2px 2px;
  color: #205291;
  font-family: Verdana,Arial,Helvetica,sans-serif;
  font-size: 9px;
  font-weight: normal;
  height: 18px;
  width: 95%;
}

#u_table input:hover, #u_table input:focus #u_table select:hover, #u_table select:focus {
	border-color:#087DB5;
	background:#E6F4FF;
} 

 .bb_close {
  background-color: #7DA8D3;
  border: 1px solid #4B87C2;
  border-radius: 3px 3px 3px 3px;
  color: #FFFFFF;
  cursor: pointer;
  font-family: Arial,Helvetica,sans-serif;
  font-size: 12px;
  font-weight:bold;
  height: 21px;
  width: 120px;
  margin-left: 300px;
}

.submit {
  background-color: #7DA8D3;
  border: 1px solid #4B87C2;
  border-radius: 3px 3px 3px 3px;
  color: #FFFFFF;
  cursor: pointer;
  font-family: Arial,Helvetica,sans-serif;
  font-size: 12px;
  height: 21px;
  margin-left: 220px;
  width: 120px;
}
  
  #u_table button  {
  background-color: #7DA8D3;
  border: 1px solid #4B87C2;
  border-radius: 3px 3px 3px 3px;
  color: #FFFFFF;
  cursor: pointer;
  font-family: Arial,Helvetica,sans-serif;
  font-size: 12px;
  height: 21px;
  
  width: 120px;
}
                      
              #groupCode1 {
  background: none repeat scroll 0 0 #E6F4FF;
  border: 1px solid #7FB2CF;
  border-radius: 2px 2px 2px 2px;
  color: #205291;
  font-family: Verdana,Arial,Helvetica,sans-serif;
  font-size: 9px;
  font-weight: normal;
  height: 16px;
  width: 80px;
}

#u_table textarea {
  background: none repeat scroll 0 0 #E6F4FF;
  border: 1px solid #7FB2CF;
  border-radius: 2px 2px 2px 2px;
  color: #205291;
  font-family: Verdana,Arial,Helvetica,sans-serif;
  font-size: 9px;
  font-weight: normal;
  width: 200px;
  height: 56px;
}
.style4 {font-size: 12px}
#u_table .row1 .right_col table {
}
#u_table .row1 .right_col table {
}
</style>