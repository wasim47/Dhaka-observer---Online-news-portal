<style>
.submit {

  background-color: #7DA8D3;
  border: 1px solid #4B87C2;
  border-radius: 3px 3px 3px 3px;
  color: #FFFFFF;
  cursor: pointer;
  font-family: Arial,Helvetica,sans-serif;
  font-size: 12px;
  height: 20px;
  width: 50px;
  margin-left:20px;
}


</style>
<?php //+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++?>
<table width="100%" border="0" cellspacing="0" cellpadding="0">
	<tr>
	<td colspan="3"><img src="<?php echo base_url();?>assets/images/main_body_01.jpg" width="986" height="35" /></td>
	</tr>
	<tr>
	<td><img src="<?php echo base_url();?>assets/images/main_body_02.jpg" width="24" height="60" /></td>
	<td background="images/main_body_03.jpg" width="936" height="50">
	<table width="930"  border="0">
	<tr>
	<td width="49"><img src="<?php echo base_url();?>assets/images/Product.png" width="48" height="48" /></td>
	<td width="595"><h1><span class="material">Current Stock</span></h1></td>

	<td width="33" class="border">
	<div align="center" class="section">
	
	</div>
	</td>
	
	</tr>
	</table>
	</td>
	<td><img src="<?php echo base_url();?>assets/images/main_body_04.jpg" width="26" height="60" /></td>
	</tr>
	<tr>
	<td colspan="3"><img src="<?php echo base_url();?>assets/images/main_body_05.jpg" width="986" height="32" /></td>
	</tr>
</table>
    
    <table width="100%" border="0" cellspacing="0" cellpadding="0">
	<tr>
	<td colspan="3"><img src="<?php echo base_url();?>assets/images/main_body_01.jpg" width="986" height="35" /></td>
	</tr>
	<tr>
	<td style="background:url(../assets/images/bar.jpg) repeat-y;" valign="top"><img src="<?php echo base_url();?>assets/images/main_body_02.jpg" width="24" height="181" /></td>
	<td width="936" height="181" align="center" style=" background:url(../assets/images/main_body_03.jpg) repeat-x; background-color:#dee4f0" >
	
	
	<div class="table_user_round1">
    
    
    <table width="100%" border="0">
    <tr><td colspan="3"><?php  echo form_open("stock_update/insert_material"); ?><p style="float:left; margin-left:120px; font-weight:bold; ">To Date&nbsp;&nbsp;
      
          <input style=" color:#666666 ; text-align:center; width:80px; " id="datepicker" type="text" name='toDate' value='To Date'  autocomplete="off"   class="vertical"   tabindex="3" onblur="if(this.value=='') this.value='To Date'" onFocus="if(this.value =='To Date' ) this.value=''" />
          
          From Date&nbsp;&nbsp;
      
          <input style=" color:#666666 ; text-align:center; width:80px;" id="datepicker2" type="text" name='fromDate' value='From Date'  autocomplete="off"   class="vertical"   tabindex="3" onblur="if(this.value=='') this.value='From Date'" onFocus="if(this.value =='From Date' ) this.value=''" /> 
    			  <select  onchange="materialNameTrigger()" name="groupName" id="groupName"  >
                    <option value="none" >Select Group</option>
                    <?php foreach($groups as $group): ?>
                    <option  value="<?php echo $group->material_group;?>" ><?php echo $group->material_group;?></option>
                    <?php endforeach;?>
                  </select> </p><div id="dis" style="width:265px; float:right; margin-right:80px; margin-top:10px">
<select   name="material_name"  id="materialName" >
  <option  value="none" selected="selected" >Select Material</option>
</select>
<?php echo form_submit('submit', 'GO',' class="submit" id="go" ');?>

     	<?php echo form_close();?>        </div></td>
  <tr>
    <td width="10%"><img src="<?php echo base_url();?>assets/images/logo.png" width="80" height="62" /></td>
    <td width="84%">    </td>
    <td width="6%"><img src="<?php echo base_url();?>assets/images/print_icon.png" width="60" height="60" /></td>
  </tr>
</table>

	  
		<table width="100%"  cellpadding="4" cellspacing="1">
        
        <thead>
          <tr>
            <td width="48" height="26" align="center" bgcolor="#C9DEF1" class="table_header"><span class="style2">#</span></td>
            
             <td width="147" align="center" bgcolor="#C9DEF1" class="table_header"><span class="style2">Material Name </span></td>
        <td width="117" align="center" bgcolor="#C9DEF1" class="table_header"><span class="style2">Material  Code</span></td>
        <td width="147" align="center" bgcolor="#C9DEF1" class="table_header"><span class="style2">Material Group </span></td>
        <td width="147" align="center" bgcolor="#C9DEF1" class="table_header"><span class="style2">Sub Group </span></td>
        <td width="150" align="center" bgcolor="#C9DEF1" class="table_header"><span class="style2">Measurement Unit</span></td>
        <td width="132" align="center" bgcolor="#C9DEF1" class="table_header"><span class="style2">Current Stock</span></td>
        <td width="132" align="center" bgcolor="#C9DEF1" class="table_header"><span class="style2">Unit Price</span></td>
         <td width="132" align="center" bgcolor="#C9DEF1" class="table_header"><span class="style2">Total Price</span></td>
            
                        
            <td width="129" align="center" bgcolor="#C9DEF1" class="table_header"><span class="style2">Action </span></td>
          </tr></thead>
        
		
		  <tbody id="singleshow">
           
            <?php $i=1; foreach ($datas as $data):?>
            
             <?php if($i%2!=0){ $c="#E3EDF9"; } else { $c="#FFFFFF"; } ?>
             
            <tr  class="table_hover" bgcolor="<?php echo $c; ?>">
              <td width="33" height="27" align="center"><span class="style9"><?php echo $i;?></span></td>
              <td width="89" align="left" class="section" style="padding-left:10px;"><a href="#" title="<?php echo $data->material_group;?>" class="style2" > <?php echo $data->material_name;?></a></td>
              <td width="75" align="center" class="style2"><?php echo $data->material_code;?></td>
              <td width="91" align="center" class="style2"><?php echo $data->material_group;?></td>
              <td width="88" align="center" class="style2"><?php echo $data->sub_group;?></td>
              <td width="97" align="center"><span class="style2"><?php echo $data->measurement_unit;?></span></td>
              <td width="83" align="center"><span class="style2"><?php echo $data->material_qty;?></span></td>
              <td width="97" align="center"><span class="style2"><?php echo $data->unit_price;?></span></td>
              <td width="70" align="center"><span class="style2"><?php echo $data->net_price;?></span></td>
          
              
              <td width="94" align="center" class="section"><a class="uCreate" href="<?php echo base_url();?>stock_update/stock_update_history/<?php echo $data->material_code; ?>" title="History"><img src="<?php echo base_url();?>assets/images/history.png" border="0"></a> </td>
            </tr>
            <?php $i++; endforeach;?> 
            </tbody>          
          </table>
		
	</div></td>
	<td style="background:url(../assets/images/bar1.jpg) repeat-y;" valign="top"><img src="<?php echo base_url();?>assets/images/main_body_04.jpg" width="26" height="181" /></td>
	</tr>
	<tr>
	<td colspan="3"><img src="<?php echo base_url();?>assets/images/main_body_05.jpg" width="986" height="32" /></td>
	</tr>
	</table>
<div id="errors"><?php echo $message;?></div>
<?php //+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++?>


<div id="lightBox" align="center">
	<table cellspacing="0" cellpadding="0">
	<tr>
	<td colspan="3" align="right">
	<!--<a title="Close" class="bb_close" href="javascript:void(0);" onClick="hideOverlay();"></a>--></td>
	</tr>
	<tr>
	<td class="t_l"></td>
	<td class="t_c"></td>
	<td class="t_r"></td>
	</tr>
	<tr>
	<td class="c_l"></td>
	<td class="c_c">
	<div id="lightText"></div></td>
	<td class="c_r"></td>
	</tr>
	<tr>
	<td class="b_l"></td>
	<td class="b_c"></td>
	<td class="b_r"></td>
	</tr>
	</table>
</div>

<div id="lightBox3" align="center">
	<table cellspacing="0" cellpadding="0">
	<tr>
	<td colspan="3" align="right">
	<!--<a title="Close" class="bb_close" href="javascript:void(0);" onClick="hideOverlay();"></a>--></td>
	</tr>
	<tr>
	<td class="t_l"></td>
	<td class="t_c"></td>
	<td class="t_r"></td>
	</tr>
	<tr>
	<td class="c_l"></td>
	<td class="c_c">
	<div id="lightText3"></div></td>
	<td class="c_r"></td>
	</tr>
	<tr>
	<td class="b_l"></td>
	<td class="b_c"></td>
	<td class="b_r"></td>
	</tr>
	</table>
</div>


<script type="text/javascript">
//#########################################################################################	
	
	//to retrive the subGroup of the selected Group//
	function materialNameTrigger()
{	
	var dataName=document.getElementById("groupName").value;
	//alert(groupName);
	
	var xmlRequest = GetXmlHttpObject();
	if (xmlRequest == null)
	return;
	var url="<?php echo base_url();?>stock_update/materialNameListTrigger?dataName="+dataName;
	//alert(url);
	var browser=navigator.appName;
	if (browser=="Microsoft Internet Explorer")
		{
			xmlRequest.open("POST",url, true);
		}
	else
		{
			xmlRequest.open("GET",url, true);
		}
	xmlRequest.setRequestHeader("Content-Type", "application/x-www-formurlencoded");
	xmlRequest.onreadystatechange =function()
		{
			if(xmlRequest.readyState==4)
			{
			    // $(".back").css("display","block"); 
				HandleAjaxResponseName(xmlRequest);
			}
		};
	xmlRequest.send(null);
	return false;
}


		function HandleAjaxResponseName(xmlRequest)
	{
		var xmlT=xmlRequest.responseText;
		//alert(xmlT);
		document.getElementById('dis').innerHTML=xmlT;
		//loadmylightbox();
		test333();
		return false;
	}
//****************************************************************************************

	$('.submit').click(function(e){
		
				//e.preventDefault();
		 var fromDate=$('#datepicker').val();
		 var toDate=$('#datepicker2').val();
	     var groupName=$('#groupName').val();
		 var groupName=$('#materialName').val();
		 
		  var startTime = dateToNumber(fromDate);
		  var endTime = dateToNumber(toDate);
		  
		 //alert('Start'+startTime+'end='+endTime);
		 
		 
		 	if(startTime > endTime ){
			 alert(startTime+'>'+endTime);
			$('#datepicker').val('please put right value');
			$("#datepicker").css("border-color","red");
			$("#sms").css("display",""); 
			document.getElementById('datepicker').focus();
			e.preventDefault();
		
		} else if((groupName == "")||(groupName == "none" )){
		 e.preventDefault();
		  $('#groupName').val('none');
		  $('#groupName').css("border-color","red");
			document.getElementById(groupName).focus();
			
		} 
		
		else if((materialName == "none" )||(total_price == '' )){
		  e.preventDefault();
		  $('#materialName').css("border-color","red");
			
			
		} else {
		 e.preventDefault();
				var formData = $('form').serialize();
               // var namee = $('form name').val();
                //alert(namee);
				
				submitForm(formData);
		//return false;
		}
		 
				
				
				
});


	function dateToNumber(e){
		 
		 var x=e.split('/');
		 
		 var y= x[2]+x[0]+x[1];
		 
		 return y;
		 
		 }

function submitForm(formData)
	{
	$.ajax({
			url: "stock_update/materialNameListTrigger",
			type: 'POST',
			data:formData,
			success: function(response)
			{// $('#response').html(response).fadeIn('fast');
			//alert(response);
			
			$('#singleshow').html(response);
			}
	
	});
}	


//****************************************************************************************	
	
	

 //##############**************DATE************Picker***********##########################	
$(function() {
		$( "#datepicker" ).datepicker();
	});
	
	
	$(function() {
		$( "#datepicker2" ).datepicker();
	});

	
//#########################################################################################	
	function GetXmlHttpObject()
{		
	var xmlHttp=null;
	try
	{
		xmlHttp=new XMLHttpRequest();
	}
	catch (e)
	{
		// Internet Explorer
		try
			{
				xmlHttp=new ActiveXObject("Microsoft.XMLHTTP");
			}
		catch (e)
			{
				xmlHttp=new ActiveXObject("Msxml2.XMLHTTP");
			}
	}
	return xmlHttp;
}

</script>

