<style>

#u_table {
text-align:right;
	width:600px;
	height:250px;
	float:left;
	margin-bottom:30px;
}

.uc_header {
  float: right;
  text-align:center;
  width:600px;
  font-size:18px;
  font-weight:bold;
  
}

.left_col {
  float: right;
  padding-right: 100px;
}

.right_col {
  float: right;
  padding-right: 150px;
  margin-top: 20px;
}

#u_table select {
width:160px;

}

#u_table input ,#u_table select {
  background: none repeat scroll 0 0 #E6F4FF;
  border: 1px solid #7FB2CF;
  border-radius: 2px 2px 2px 2px;
  color: #205291;
  font-family: Verdana,Arial,Helvetica,sans-serif;
  font-size: 9px;
  font-weight: normal;
  height: 18px;
  width: 150px;
}

#u_table input:hover, #u_table input:focus #u_table select:hover, #u_table select:focus {
	border-color:#087DB5;
	background:#E6F4FF;
} 

 .bb_close , .submit {
  background-color: #7DA8D3;
  border: 1px solid #4B87C2;
  border-radius: 3px 3px 3px 3px;
  color: #FFFFFF;
  cursor: pointer;
  font-family: Arial,Helvetica,sans-serif;
  font-size: 12px;
  height: 21px;
  width: 120px;
  margin-left:30px;
}

.submit {

  background-color: #7DA8D3;
  border: 1px solid #4B87C2;
  border-radius: 3px 3px 3px 3px;
  color: #FFFFFF;
  cursor: pointer;
  font-family: Arial,Helvetica,sans-serif;
  font-size: 12px;
  height: 21px;
  width: 120px;
  margin-left:150px;
}

                      
              #groupCode {
  background: none repeat scroll 0 0 #E6F4FF;
  border: 1px solid #7FB2CF;
  border-radius: 2px 2px 2px 2px;
  color: #205291;
  font-family: Verdana,Arial,Helvetica,sans-serif;
  font-size: 9px;
  font-weight: normal;
  height: 16px;
  width: 125px;
}

#u_table textarea {
  background: none repeat scroll 0 0 #E6F4FF;
  border: 1px solid #7FB2CF;
  border-radius: 2px 2px 2px 2px;
  color: #205291;
  font-family: Verdana,Arial,Helvetica,sans-serif;
  font-size: 9px;
  font-weight: normal;
  width: 200px;
  height: 56px;
}

</style>


<?php echo form_open("supplier_manage/update_supplier"); ?>


<?php ///////////////////////////////////////////////////////////////////////////////////////////////////////////////  ?>
<div id="u_table">
<div class="uc_header"><img src="<?php echo base_url();?>assets/images/supplier.png" width="48" height="48" />&nbsp; &nbsp; Update Supplier</div>
<div class="right_col">


	  
        <table width="100%" border="0">
  <tr>
    <td width="65%"><div align="right">Supplier Name:</div></td>
    <td width="35%"><div align="left"><?php echo form_input('supplier_name',$editData['supplier_name'],'id="supplier_name"');?></div></td>
  </tr>
  <tr>
    <td><div align="right">Customer Code:</div></td>
    <td><div align="left"><?php echo form_input('customer_code',$editData['customer_code'],'id="customer_code"');?></div></td>
  </tr>
  <tr>
    <td><div align="right">Address: </div></td>
    <td><div align="left"><?php echo form_textarea('address',$editData['address'],'id="address"');?></div></td>
  </tr>
  <tr>
    <td><div align="right">Phone: </div></td>
    <td><div align="left"><?php echo form_input('phone',$editData['phone'],'id="phone"');?></div></td>
  </tr>
  <tr>
    <td><div align="right">Email: </div></td>
    <td><div align="left"><?php echo form_input('email',$editData['email'],'id="email"');?></div></td>
  </tr>
</table>
<p>
             
            
    </p>
      <p>&nbsp;</p>
	 
    <p>&nbsp;</p>
       



      
  </div>


      
 
</div>
<p><?php echo form_hidden('id',$editData['id'],'id="id"');?><?php echo form_submit('submit', 'Update Supplier','class="submit"');?><input class="bb_close" onclick="hideOverlay();" href="#" title="Close" type="button" value="Cancel"></p>
<?php echo form_close();?>
	
     