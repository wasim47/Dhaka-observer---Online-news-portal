<table width="100%" border="0" cellspacing="0" cellpadding="0">
	<tr>
	<td colspan="3"><img src="<?php echo base_url(); ?>assets/images/main_body_01.jpg" width="986" height="35" /></td>
	</tr>
	<tr>
	<td style="background:url(assets/images/bar.jpg) repeat-y;" valign="top"><img src="<?php echo base_url(); ?>assets/images/main_body_02.jpg" width="24" height="181" /></td>
	<td width="936" height="181" align="center" style="background:url(assets/images/main_body_03.jpg) repeat-x; background-color:#dee4f0" ><table width="50%" border="0" cellspacing="5" cellpadding="8" align="center" style="padding-top:20px; padding-bottom:20px;">
      <tr >
        <td width="133"  bgcolor="#dbe8f8" class="section" id="bor" onMouseOver="this.bgColor='#fafbfd'" onMouseOut="this.bgColor='#dbe8f8'"><a href="<?php echo base_url();?>material_manage" id="material_manage" >
          <div align="center"><img src="<?php echo base_url(); ?>assets/images/icon-48-pro-subcatgory.png" width="45" height="45" border="0" /></div>
          <div align="center">Material Management </div>
        </a> </td>
        <td width="84" bgcolor="#dbe8f8" class="section" id="bor" onMouseOver="this.bgColor='#fafbfd'" onMouseOut="this.bgColor='#dbe8f8'"><a href="<?php echo base_url();?>stock_manage" id="stock_manage">
          <div align="center"><img src="<?php echo base_url(); ?>assets/images/menu.png" width="45" height="45" border="0" /></div>
          <div align="center">Stock Management</div>
        </a> </td>
        <td width="183" bgcolor="#dbe8f8" id="bor" class="section" onMouseOver="this.bgColor='#fafbfd'" onMouseOut="this.bgColor='#dbe8f8'"><a href="<?php echo base_url();?>supplier_manage" id="supplier_manage">
          <div align="center"><img src="<?php echo base_url(); ?>assets/images/submenu.png" width="35" height="35" border="0" /></div>
          <div align="center">Supplier Management</div>
        </a> </td>
      </tr>
      <tr>
        <td bgcolor="#dbe8f8" id="bor" class="section" onMouseOver="this.bgColor='#fafbfd'" onMouseOut="this.bgColor='#dbe8f8'"><a href="<?php echo base_url();?>pi" id="pi">
          <div align="center"><img src="<?php echo base_url(); ?>assets/images/news.png" width="45" height="45" border="0" /></div>
          <div align="center">Purchase Invoice</div>
        </a> </td>
        <td bgcolor="#dbe8f8" id="bor" class="section" onMouseOver="this.bgColor='#fafbfd'" onMouseOut="this.bgColor='#dbe8f8'"><a href="<?php echo base_url();?>iwo" id="iwo">
          <div align="center"><img src="<?php echo base_url(); ?>assets/images/download.png" width="45" height="45" border="0" /></div>
          <div align="center">Work Order</div>
        </a> </td>
        <td width="183" bgcolor="#dbe8f8" id="bor" class="section" onMouseOver="this.bgColor='#fafbfd'" onMouseOut="this.bgColor='#dbe8f8'"><a href="<?php echo base_url();?>io_manage" id="io">
          <div align="center"><img src="<?php echo base_url(); ?>assets/images/icon-48-header.png" width="45" height="45" border="0" /></div>
          <div align="center">Issue Order</div>
        </a> </td>
      </tr>
      <tr >
        <td colspan="2"  bgcolor="#dbe8f8" class="section" id="bor" onMouseOver="this.bgColor='#fafbfd'" onMouseOut="this.bgColor='#dbe8f8'"><a href="<?php echo base_url();?>admin" id="home">
          <div align="center"><img src="<?php echo base_url(); ?>assets/images/user.png" width="48" height="48" border="0"></div>
          <div align="center">User Manager </div>
        </a> <a href="menu_manager.php"></a> </td>
        <td width="183" bgcolor="#dbe8f8" id="bor" class="section" onMouseOver="this.bgColor='#fafbfd'" onMouseOut="this.bgColor='#dbe8f8'"><a href="javascript:void(0);">
          <div align="center"><img src="<?php echo base_url(); ?>assets/images/submenu.png" width="35" height="35" border="0" /></div>
          <div align="center">Report</div>
        </a> </td>
      </tr>
    </table></td>
	<td style="background:url(assets/images/bar1.jpg) repeat-y;" valign="top"><img src="<?php echo base_url(); ?>assets/images/main_body_04.jpg" width="26" height="181" /></td>
	</tr>
	</table>
    </td>
	</tr>
	<tr>
	<td width="978" height="156" align="center" style="background:url(assets/images/bg1.jpg) repeat-x;">&nbsp;</td>
	</tr>
</table>
	


<?php #################################################################### ?>


<!--<tr>
    <td height="18">&nbsp;</td>
</tr>
<tr>
    <td height="356" align="center" valign="top"><table width="90%" border="0" align="center" cellpadding="0" cellspacing="4" class="bdr_all">
            <tr>
                <td colspan="2" class="content_heading">Doctors &amp; Staff</td>
            </tr>
            <?php ######Data####input#####start#######################################################?>
            <?php foreach ($doctors as $doctor): ?>
                <tr>
                    <td colspan="2" align="center" valign="middle" class="bdr_top"><table width="100%" border="0" align="center" cellpadding="0" cellspacing="0">
                            <tr>
                                <td align="center" valign="middle" class="con_bg">
									<table width="96%" border="0" align="center" cellpadding="0" cellspacing="0">
											<tr height="40">
												<td width="15%" align="left"><?php echo $doctor->first_name . ' ' . $doctor->last_name; ?></td>
												<td width="110px" align="left">(<?php echo $doctor->type; ?>)</td>
												<td width="47%" align="left">&nbsp;&nbsp;&nbsp;<?php echo $doctor->email;?></td>
												<td><?php echo anchor("doctors_schedule/schedule_data/".$doctor->id, '<img src="'.base_url().'assets/images/calender.png" width="35" height="35" title="Doctors Schedule" />')?></td>
												<td align="center" ><?php echo ($doctor->active) ? anchor("doctors/deactivate/".$doctor->id, 'Active') : anchor("doctors/activate/". $doctor->id, 'Inactive');?>&nbsp;&nbsp;&nbsp;<?php if(($doctor->active)==1){?><img src="<?php echo base_url();?>assets/images/tick.png" width="16" height="16" /><?php }else {?><img src="<?php echo base_url();?>assets/images/minus_circle.png" width="16" height="16" /><?php }?></td>
												<td width="3%" align="center"><?php echo anchor("doctors/edit_staff/".$doctor->id, 'Edit')?></td>
											    <td width="4%" align="center"><a href="<?php echo base_url(); ?>doctors/doctors_del/<?php echo $doctor->id ; ?> "><img src="<?php echo base_url();?>assets/images/cross.png" width="12" height="12" border="0" /></a></td>
											</tr>
								   </table>							   </td>
                            </tr>
                        </table></td>
                </tr>
            <?php endforeach; ?>
            <?php ######################################################################?>

                

                <div id="addPerson" > <tr><?php echo form_open("doctors/add_staff");?>
                        <td colspan="2" align="center" valign="middle" class="bdr_top"><table width="100%" bgcolor="#EFFAEF" border="0" align="center" cellpadding="0" cellspacing="0">
                                <tr>
                                    <td align="center" valign="middle" class="con_bg_insert"><table width="96%" border="0" align="center" cellpadding="0" cellspacing="0">
                                            <tr>
                                                <td width="21%" align="left">&nbsp;&nbsp;<strong>First Name:</strong></td>
                                                <td width="21%" align="left">&nbsp;&nbsp;<strong>Last Name:</strong></td>
												<td width="21%" align="left">&nbsp;&nbsp;<strong>Email Address:</strong></td>
                                                <td width="21%" align="left">&nbsp;&nbsp;<strong><?php echo form_label('Type', 'type') . "<br />"; ?></strong></td>

                                                <td width="7%" align="center">&nbsp;</td>
                                            </tr>
                                            <tr>
                                                <td width="21%" height="40" align="left" valign="middle"><?php echo form_input('first_name', '', 'id="first_name"'); ?></td>
                                                <td width="21%" height="40" align="left"><?php echo form_input('last_name', '', 'id="last_name"'); ?></td>
												<td width="21%" height="40" align="left"><?php echo form_input('email', '', 'id="email"'); ?></td>
                                                <td width="21%" height="40" align="left"><?php
                $options = array(
                    'none' => 'Please select',
                    'Dental Hygienist' => 'Dental Hygienist',
                    'Doctor' => 'Doctor',
                    'Midwife' => 'Midwife',
                    'Nurse' => 'Nurse',
                    'Nurse Practitioner' => 'Nurse Practitioner',                  
                    'Physician Assistant' => 'Physician Assistant',
                    'Therapist' => 'Therapist',
                );


                
                echo form_dropdown('type', $options, 'None');
            ?></td>

                                            <td width="7%" height="30" align="center"><?php echo form_submit('submit', 'Add');?><?php echo form_close();?></td>
                                        </tr>
                                    </table></td>
                            </tr>
                        </table></td>
                </tr></div>
            <tr>
                <td width="13%" height="54" class="mid_nav"><p id="addStaff" >Add person</p></td>
                <td width="87%" class="mid_nav"><div id="errors" > <?php echo $error ; ?></div></td>
            </tr>
            <tr>            </tr>
            <tr>
                <td colspan="2"></td>
            </tr>
            <tr>
                <td colspan="2" class="bdr_top"> Your Profile will not be displayed on med-ped untill the setup is complete</td>
            </tr>
            <tr>
                <td height="19" colspan="2">&nbsp;</td>
            </tr>
        </table>              
    <p>&nbsp;</p></td>
</tr>
</table></td>
</tr>
<tr>
    <td align="right"></td>
</tr>

</table>
</div>

<?php // ####################################################################?>

<script type="text/javascript">

    $(function(){

        $("#addStaff").click(function(){
                $(".con_bg_insert").slideToggle();
				
				});
				

        });
</script>-->

