</div><!-- //content -->
<!-- #left sidebar -->
<div id="sidebarLT">
<em>Left Side Bar:</em> Will contain WordPress content related links
</div><!--//sidebarLT  -->
</div><!--//container3-->
<!-- #right sidebar -->
<div id="sidebarRT">
<a href="<?php echo URL; ?>registration"><h2>New user Registration</h2></a>
		<a href="<?php echo URL; ?>accounts"><h2>Account Section</h2></a>
		<a href="<?php echo URL; ?>dailyCafe"><h2>Daily Cafe Entry</h2></a>

<em>Right Side Bar:</em> This will include additional ads,  
or non-content relevant items.
</div><!--//sidebarRT -->
<div id="pushbottom"> </div><!--//this div will span across the 3 divs 
above it making sure the footer stays at the bottom of the longest 
column-->
</div><!--//container2-->
<div id="top_navlist">

<a href="<?php echo URL . 'registration/'; ?>internetUserRegistration"><3>New Internet user Registration</h3>
<a href="<?php echo URL . 'registration/'; ?>cafeUseRegistration"><h3>New cyberCafe user Registration</h3>

<a href="<?php echo URL; ?>wakeupboard"><h3>Back</h3>

<em>Top Nav:</em> For reading through straight text, it's best to have 
links at bottom (css will place it up top, for visual ease of use)