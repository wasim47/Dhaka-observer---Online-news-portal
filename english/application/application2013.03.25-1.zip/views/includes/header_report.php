<?php //****************************************************************************************?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">

<!-- Mirrored from medpedhealthcare.com/ by HTTrack Website Copier/3.x [XR&CO'2010], Mon, 10 Sep 2012 07:43:12 GMT -->


<head>
	<title>..:: Welcome to admin Panel ::..</title>
        <meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />

	<script type="text/javascript" src="<?php echo base_url();?>assets/js/jquery-1.8.2.js"></script>
	
	
    <script type="text/javascript" src="<?php echo base_url(); ?>assets/js/jquery-templ.js"></script><!-- for ajax crud -->
	
<script type="text/javascript" src="<?php echo base_url();?>assets/js/common.js"></script><!-- for light Box -->
<script type="text/javascript" src="<?php echo base_url();?>assets/js/jquery.lightbox-0.5.js"></script><!-- for light Box -->
<script type="text/javascript" src="<?php echo base_url();?>assets/js/custom.js"></script>
<script type="text/javascript" src="<?php echo base_url();?>assets/js/jquery.autocomplete.js"></script><!-- for Auto Complete -->

	<script src="<?php echo base_url();?>assets/js/datepicker/jquery.ui.core.js"></script>
	<script src="<?php echo base_url();?>assets/js/datepicker/jquery.ui.widget.js"></script>
	<script src="<?php echo base_url();?>assets/js/datepicker/jquery.ui.datepicker.js"></script>
    
	<link rel="stylesheet" href="<?php echo base_url();?>assets/css/jquery.ui.all.css">
	<!--<link rel="stylesheet" href="../demos.css">-->

<link rel="stylesheet" type="text/css" href="<?php echo base_url();?>assets/css/jquery.autocomplete.css" /><!-- for Auto Complete CSS -->
<link rel="stylesheet" type="text/css" href="<?php echo base_url();?>assets/css/lightbox.css" /><!-- for light Box -->
<link rel="stylesheet" href="<?php echo base_url();?>assets/css/artsign-style.css" />
<link rel="stylesheet" href="<?php echo base_url();?>assets/css/dropdown.css" />


       <script type="text/javascript" language="javascript">
function selectedmenu(id)
{
	document.getElementById(id).style.backgroundColor = '#FFFFFF';
}
</script>




</head>


<?php @session_start(); ?>

<body  onload="selectedmenu('<?php echo $onload; ?>') " >
<div class="mainwrap">
  <div class="twrap">
    <table width="960" border="0" align="center" cellpadding="0" cellspacing="0">
      <tr id="header">
        <td><table width="100%" height="129" border="0" cellpadding="0" cellspacing="0">
          <tr>
            <td width="463" height="129" align="left"><img src="<?php echo base_url();?>assets/images/logo.png"  border="0" /></td>
            <td width="497" align="right" valign="top"><div class="right-top"> <?php if ($this->ion_auth->logged_in() == true):?>
		<a href="<?php echo base_url();?>logout">Logout</a>
	<?php else: ?>
		<a href="<?php echo base_url();?>admin">Login</a>
	<?php endif; ?>
        <?php if ($this->ion_auth->logged_in() == true){ echo "| Welcome, ".$this->session->userdata('username');} ?></div><!--right-top menu-->
        	<div class="right-head"> <img src="<?php echo base_url();?>assets/images/right-head.png"  border="0" /> </div>
            
            </td>
          </tr>
        </table></td>
      </tr>
      <tr>
        <td><table width="100%" border="0" align="center" cellpadding="0" cellspacing="0">
          <tr>
            <td>
<?php //****************************************************************************************?>


    <table width="100%" border="0"  cellpadding="0" cellspacing="0" class="mid_nav_bg">
              <tr>
                <td><div class="nav_area">
                  <ul class="dropdown dropdown-horizontal">
                      <?php if (($this->ion_auth->logged_in() == true)&& ($this->session->userdata('role') == 'default')):?>
                      
                     
                      
                      <li><a href="<?php echo base_url();?>#" id="file">File</a>
                      	<ul>
                        <li><a href="<?php echo base_url();?>dashboard" id="home">Home</a> </li>
                        <!--<li><a href="<?php echo base_url();?>dashboard" id="export">Export</a> </li>
                        <li><a href="<?php echo base_url();?>dashboard" id="import">Import</a> </li>-->
                        <li><a href="<?php echo base_url();?>admin" id="admin">User&nbsp;Manager</a> </li>
                        <li><a href="<?php echo base_url();?>admin/change_password" id="change_password">Change&nbsp;Password</a> </li>
      				   </ul>
                     </li>
                      <li><a href="<?php echo base_url();?>#" id="stock_manage">Stock Management</a>
                      	<ul>
                        <li><a href="<?php echo base_url();?>stock_manage" id="stock_manage">Material Group Mangment</a> </li>
                        <li><a href="<?php echo base_url();?>stock_manage/sub_group" id="sub_group">Material Sub Group Mangment</a> </li>
                        <li><a href="<?php echo base_url();?>material_manage" id="material_manage">Material Mangment</a> </li>
                        <li><a href="<?php echo base_url();?>stock_update" id="stock_update">Stock Update</a> </li>
                       <!-- <li><a href="<?php echo base_url();?>dashboard" id="admin">Stock Adjust</a> </li>-->
                        <!--<li><a href="<?php echo base_url();?>stock_update/stock_current" id="change_password">Current Stock</a> </li>-->
                        <!--<li><a href="<?php echo base_url();?>dashboard/" id="change_password">Stock Report</a> </li>-->
                        <li><a href="<?php echo base_url();?>supplier_manage/" id="supplier_manage">Supplier&nbsp;Management</a> </li>
                        <li><a href="<?php echo base_url();?>client_manage/" id="client_manage">Client&nbsp;Management</a> </li>
      				   </ul>
                      </li>
                      <li><a href="<?php echo base_url();?>pi" id="pi">Purchase Invoice</a></li>
                      <li><a href="<?php echo base_url();?>iwo" id="iwo">Work Order</a></li>
                      <li><a href="<?php echo base_url();?>io_manage" id="io">Issue Order</a></li>
                      <li><a href="<?php echo base_url();?>report_stock" id="report">Material Report</a>
                      <ul>
                        <li><a href="<?php echo base_url();?>report_stock" id="report_stock">Ledger Report</a> </li>
                        <li><a href="<?php echo base_url();?>report_stock/group" id="group">Group Report</a> </li>
                        <li><a href="<?php echo base_url();?>report_stock/issue" id="issue">Issue Report</a> </li>
                        <li><a href="<?php echo base_url();?>report_stock/receive" id="receive">Receive Report</a> </li>
                       <!-- <li><a href="<?php echo base_url();?>dashboard" id="admin">Stock Adjust</a> </li>-->
                        <!--<li><a href="<?php echo base_url();?>stock_update/stock_current" id="change_password">Current Stock</a> </li>-->
                        <li><a href="<?php echo base_url();?>report_stock/total_stock" id="change_password">Total Stock Report</a> </li>
                        <li><a href="<?php echo base_url();?>report_stock/wo" id="supplier_manage">Work Order Report</a> </li>
      				   </ul>
                      </li>
                      <li><a href="<?php echo base_url();?>requisition_manage" id="requisition_manage">Material Requisition</a></li>
            
                    <?php endif; ?>
                  </ul>
                </div></td>
              </tr>
            </table></td>
          </tr>
	


	
