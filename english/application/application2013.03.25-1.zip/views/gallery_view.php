<div id="photo_uploadd">	




<div id="gallersy">
		<?php // if (isset($images) && (count($images))):
		foreach($images as $image):?>
		<div class="thumbf">
		<a href="<?php echo $image['url']; ?>">
		<img src="<?php echo $image['thumb_url']; ?>" /></a>
		</div>
		<?php endforeach;
		// endif; ?>
		

</div>


<?php echo form_open_multipart('gallery');?>
<?php echo form_upload('userfile');?>
<?php echo form_submit('upload','Upload');?>
<?php echo form_close();?>


</div>