<style type="text/css">
<!--
.style1 {font-size: medium}
-->
</style>
          <tr >
            <td height="0">&nbsp;</td>
          </tr>
          <tr>
            <td align="center" valign="top"><table  width="100%" border="0" align="center" cellpadding="0" cellspacing="0">
              <tr>
                <td colspan="3" align="left" valign="top">
				
				<table width="100%" border="0" align="left" cellpadding="0" cellspacing="0" bgcolor="#F0F0F0" border-bottom="#0099FF">
                          <tr>
                            <td width="3%">&nbsp;</td>
                            <td width="97%"><strong> What purpose It Serve?</strong></td>
                          </tr>
                          <tr>
                            <td>&nbsp;</td>
                            <td>Settings is a place where you can create, update and Delete some feild like Locations etc.</td>
                          </tr>
                  </table>				�				</td><!--Top row-->
              </tr>
              <tr>
                <td  width="47%" align="left" valign="top"> <div >
				
				<table width="99%" border="0" align="left" cellpadding="0" cellspacing="0">
                  <tr>
                    <td width="38%" class="content_heading"><div style="height:16px; padding:5px; background-color:#CCCCCC">Add New Location</div></td>
                    <td width="62%" align="right"></td>
                  </tr>
                  <tr style="border:solid;1px">
                    <td colspan="2" align="center" valign="middle" ></td>
                  </tr>
                  <tr>
                    <td colspan="2" class="bdr_top">
					<?php echo form_open('settings/locations_update');
					foreach($locations as $loca):?><table class="con_bg_4" width="100%" border="0" align="center" cellpadding="0" cellspacing="0">
                              <tr>
                                <td width="4%">								 </td>
                                <td width="90%"><input name="locations[]" type="checkbox" value="<?php echo $loca->location; ?>"  <?php if ($loca->active==1) { ?> checked="checked" <?php } ?> />&nbsp;&nbsp;<strong><?php echo $loca->location; ?></strong><?php
								 echo form_hidden('id[]', $loca->id); ?></td>
                                <td width="6%"><a href="<?php echo base_url(); ?>settings/locations_del/<?php echo $loca->id ; ?> "><img src="<?php echo base_url();?>assets/images/cross.png" width="12" height="12" border="0" /></a></td>
                            </table>
                              
                           <?php   endforeach; 
					
					 //echo form_submit('submit', 'Update');?></td>
                  </tr>
				  

                  
                  
                  
                  
                  
                  
                  
                  
                  <tr >
                    <td    colspan="2" align="right" valign="center"  class="con_bg_2"><table width="45%" border="0" cellspacing="0" cellpadding="0">
                      <tr >
                        <td width="29%" align="center"><input type="submit" value=" " class="save"><?php echo form_close();?></td>
                        <td width="71%" align="center"><div style="" ><img id="addLocation" src="images/add_btn.gif" width="90" height="39" border="0" /></div></td>
                      </tr>
                      </table>				  <!--|||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||________________|||||||||||-->
				  <div id="addLocation"  style="width:auto;"> <tr>
                        
				  </tr>
				  
				  <!--|||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||_________________||||||||||--></td>
                  </tr>
                  <tr>
                    <td  colspan="2" align="right" valign="center"  class="con_bg_2">
					
					<table class="con_bg_insert" width="100%" border="0" align="center" cellpadding="0" cellspacing="0">
                      <tr>
                        <td width="40%" align="left"></td>
                        <td width="60%" align="left">&nbsp;</td>
                      </tr>
                      <tr colspan="2">
                        <td width="40%" align="left" valign="middle"   cellpadding="2">&nbsp;<span class="style1"><strong>Locations :</strong>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</span></td>
                        <td width="60%" align="left" valign="middle"   cellpadding="2"><p><span class="style1"><?php echo form_open("settings/add_locations");?><?php echo form_input('locations', '', 'class="style1"'); ?></span></p></td>
                        </tr>
                      <tr colspan="2">
                        <td align="left" valign="middle"   cellpadding="2">&nbsp;<span class="style1"><strong>Company :</strong>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</span></td>
                        <td align="left" valign="middle"   cellpadding="2"><p><div class="t_box_select">
                          <select   name="company_name" id="company_name" >
                            <option>Choose Company</option>
                            <?php foreach($company as $com): ?>
                            <option value="<?php echo $com->id; ?>"><?php echo $com->company_name; ?></option>
                            <?php endforeach;?>
                          </select>
                          <label for="select"></label>
                        </div></p></td>
                      </tr>
                      <tr colspan="2">
                        <td align="left" valign="middle"   cellpadding="2"><span class="style1"><strong>Address :</strong>&nbsp;&nbsp;&nbsp;&nbsp;</span></td>
                        <td align="left" valign="middle"   cellpadding="2"><span class="style1"><?php
						$data = array(
              'name'        => 'address',
              'id'          => 'address',
              'value'       => '',
              'rows'   		=> '4',
              'cols'        => '18',
            );
						 echo form_textarea($data); ?> <br /><?php echo form_submit('submit', 'Add','class="style1"');?><?php echo form_close(); ?></span></td>
                      </tr>
                    </table>
					
					</td>
                  </tr>
                  <tr>
                    					
                  </tr>
                  <tr>&nbsp;              </tr>
                  </table>				
                </div>�</td>
                <td width="2%">&nbsp;</td>
                <td width="51%" height="176" align="right" valign="top">
				
				<table width="97%" border="0" align="left" cellpadding="0" cellspacing="0">
                  <tr>
                    <td width="51%" class="content_heading"><div style="height:16px; padding:5px; background-color:#CCCCCC">Add New Campany Name</div></td>
                    <td width="49%" align="right"></td>
                  </tr>
                  <tr style="border:solid;1px">
                    <td colspan="2" align="center" valign="middle" ></td>
                  </tr>
                  <tr>
                    <td colspan="2" class="bdr_top">
					<?php echo form_open('settings/company_update');
					foreach($company as $com):?><table class="con_bg_4" width="100%" border="0" align="center" cellpadding="0" cellspacing="0">
                              <tr>
                                <td width="4%">								 </td>
                                <td width="90%"><input name="company[]" type="checkbox" value="<?php echo $com->company_name; ?>"  <?php if ($loca->active==1) { ?> checked="checked" <?php } ?> />&nbsp;&nbsp;<strong><?php echo $com->company_name; ?></strong><?php
								 echo form_hidden('id[]', $com->id); ?></td>
                                <td width="6%"><a href="<?php echo base_url(); ?>settings/company_del/<?php echo $com->id ; ?> "><img src="<?php echo base_url();?>assets/images/cross.png" width="12" height="12" border="0" /></a></td>
                            </table>
                              
                           <?php   endforeach; 
					
					 //echo form_submit('submit', 'Update');?></td>
                  </tr>
				  

                  
                  
                  
                  
                  
                  
                  
                  
                  <tr>
                    <td  colspan="2" align="right" valign="center" height="29" class="con_bg_2"><table width="45%" border="0" cellspacing="0" cellpadding="0">
                      <tr >
                        <td align="center"><input type="submit" value=" " class="save"><?php echo form_close();?></td>
                        <td align="center"><img id="addCompany" src="images/add_btn.gif" width="90" height="39" border="0" /></td>
                      </tr>
                      </table>				  <!--|||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||________________|||||||||||-->
				  <div id="addPerson" > <tr></tr>
				  </div>
				  
				  <!--|||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||_________________||||||||||--></td>
                  </tr>
                  <tr>
                    <td  colspan="2" align="right" valign="center"  class="con_bg_2"><table  class="con_bg_insert1" width="100%" border="0" align="center" cellpadding="0" cellspacing="0">
                      <tr>
                        <td width="100%" align="left"><?php echo form_open("settings/add_company");?></td>
                      </tr>
                      <tr>
                        <td width="83%"  align="left" valign="middle">&nbsp;&nbsp;<span class="style1"><strong>Add Company :</strong>&nbsp;&nbsp;&nbsp;&nbsp;<?php echo form_input('company', '', 'class="style1"'); ?>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<?php echo form_submit('submit', 'Add','class="style1"');?></span></td>
                        <?php echo form_close(); ?></tr>
                    </table></td>
                  </tr>
                  <tr>&nbsp;              </tr>
                  </table>
				
				
				�</td><!--right column-->
              </tr>
              <tr>
                <td width="47%" align="left" valign="top">&nbsp;</td>
                <td width="2%">&nbsp;</td>
                <td align="right" valign="top">&nbsp;</td>
              </tr>
            </table></td>
          </tr>
        </table></td>
      </tr>
      <tr>
        <td align="right"></td>
      </tr>
      
    </table>
    <script type="text/javascript">

    $(function(){
	


        $("#addLocation").click(function(){
                $(".con_bg_insert").slideToggle('slow');
				
				});
				
		 $("#addCompany").click(function(){
                $(".con_bg_insert1").slideToggle();
				
				});		
				

        });
		
</script>


<style type="text/css">




</style>