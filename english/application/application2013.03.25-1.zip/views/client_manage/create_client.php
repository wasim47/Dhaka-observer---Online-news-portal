<style>

#u_table {
text-align:right;
	width:500px;
	float:left;
	margin-bottom:30px;
}

.uc_header {
  float: right;
  text-align:center;
  width:600px;
  font-size:18px;
  font-weight:bold;
  
}

.left_col {
  float: right;
  padding-right: 100px;
}

.right_col {
  float: right;
  padding-right: 150px;
  margin-top: 20px;
}

#u_table select {
width:160px;

}

#u_table input ,#u_table select {
  background: none repeat scroll 0 0 #E6F4FF;
  border: 1px solid #7FB2CF;
  border-radius: 2px 2px 2px 2px;
  color: #205291;
  font-family: Verdana,Arial,Helvetica,sans-serif;
  font-size: 9px;
  font-weight: normal;
  height: 18px;
  width: 150px;
}

#u_table input:hover, #u_table input:focus #u_table select:hover, #u_table select:focus {
	border-color:#087DB5;
	background:#E6F4FF;
} 

 .bb_close , .submit {
  background-color: #7DA8D3;
  border: 1px solid #4B87C2;
  border-radius: 3px 3px 3px 3px;
  color: #FFFFFF;
  cursor: pointer;
  font-family: Arial,Helvetica,sans-serif;
  font-size: 12px;
  height: 21px;
  width: 120px;
  margin-left:30px;
}

.submit {

  background-color: #7DA8D3;
  border: 1px solid #4B87C2;
  border-radius: 3px 3px 3px 3px;
  color: #FFFFFF;
  cursor: pointer;
  font-family: Arial,Helvetica,sans-serif;
  font-size: 12px;
  height: 21px;
  width: 120px;
  margin-left:150px;
}

                      
              #groupCode {
  background: none repeat scroll 0 0 #E6F4FF;
  border: 1px solid #7FB2CF;
  border-radius: 2px 2px 2px 2px;
  color: #205291;
  font-family: Verdana,Arial,Helvetica,sans-serif;
  font-size: 9px;
  font-weight: normal;
  height: 16px;
  width: 125px;
}

#u_table textarea {
  background: none repeat scroll 0 0 #E6F4FF;
  border: 1px solid #7FB2CF;
  border-radius: 2px 2px 2px 2px;
  color: #205291;
  font-family: Verdana,Arial,Helvetica,sans-serif;
  font-size: 9px;
  font-weight: normal;
  width: 200px;
  height: 56px;
}





</style>


<?php echo form_open("client_manage/insert_client"); ?>


<?php ///////////////////////////////////////////////////////////////////////////////////////////////////////////////  ?>
<div id="u_table">
<div class="uc_header"><img src="<?php echo base_url();?>assets/images/supplier.png" width="48" height="48" /> Create Client</div>
  
<div class="right_col">

	  
        <table width="100%" border="0">
  <tr>
    <td width="65%"><div align="right">Client Name:</div></td>
    <td width="35%"><div align="left"><?php echo form_input('client_name','','id="client_name" class="vertical"  tabindex="1"');?></div></td>
  </tr>
  <tr>
    <td><div align="right">Address: </div></td>
    <td><div align="left"><?php echo form_textarea('address','','id="address" class="vertical"  tabindex="3"');?></div></td>
  </tr>
  <tr>
    <td><div align="right">Phone: </div></td>
    <td><div align="left"><?php echo form_input('client_phone','','id="phone" class="vertical"  tabindex="4"');?></div></td>
  </tr>
  <tr>
    <td><div align="right">Email: </div></td>
    <td><div align="left"><?php echo form_input('client_email','','id="email" class="vertical"  tabindex="5"');?></div></td>
  </tr>
</table>




       



      
  </div>  
  <table width="70%"> 
    <tr>
    <td width="149"><div align="right">Contact Person Name: </div></td>
    
 
    <td width="143"><div align="right">Contact Person Email: </div></td>
    <td width="112"><div align="right">Contact Person Phone: </div></td>
    
  </tr>
  <tr>
    
    <td><div align="left"><?php echo form_input('contact_person_name','','id="contact_person_name" class="vertical"  tabindex="6" ');?></div></td>
    <td><div align="left"><?php echo form_input('contact_person_email','','id="contact_person_email" class="vertical"  tabindex="7" ');?></div></td>
    <td><div align="left"><?php echo form_input('contact_person_phone','','id="contact_person_phone" class="vertical"  tabindex="8"');?></div></td>
  </tr>
  <tr><input id="prof_count" type="hidden" value="1" name="prof_count"></tr>
           
			<tr id="prof_1"></tr>
            <tr >&nbsp;</tr>
  </table>  
</div>
<p><?php echo form_submit('submit', 'Create Client','class="submit" onclick="validationCheck()"');?><input class="bb_close" onclick="hideOverlay();" href="#" title="Close" type="button" value="Cancel"></p>
<?php echo form_close();?>
	
<script type="text/javascript">

		

 
$(".vertical").keypress(function(event) {
        if(event.keyCode == 13) { 
        textboxes = $("input.vertical");

        currentBoxNumber = textboxes.index(this);
        if (textboxes[currentBoxNumber + 1] != null) {
            nextBox = textboxes[currentBoxNumber + 1]
           // nextBox.focus();
			if(nextBox.value !='')
			{
				nextBox = textboxes[currentBoxNumber + 2]
				
           // nextBox.focus();
			}
			
			nextBox.focus();
			
           event.preventDefault();
            return false 
            }
        }
    });
	
			$(document).keydown(function(e){
			if(e.keyCode==17)
			{
             	var contact_person_name=$('#contact_person_name').val();
				var contact_person_email=$('#contact_person_email').val();
				var contact_person_phone=$('#contact_person_phone').val(); 
				
				if ((contact_person_name==''))
				{	
					$("#contact_person_name").css("border-color","red");					
					$("#contact_person_name").css("background-color","#FF9595");
					document.getElementById('contact_person_name').focus();				
				} else if (contact_person_email=='')
				{
					$("#contact_person_email").css("border-color","red");					
					$("#contact_person_email").css("background-color","#FF9595");
					document.getElementById('contact_person_email').focus();
				
				}else if (contact_person_phone=='')
				{
					$("#contact_person_phone").css("border-color","red");					
					$("#contact_person_phone").css("background-color","#FF9595");
					document.getElementById('contact_person_phone').focus();
				} 
				else 				
				{
					$("#contact_person_name").css("background-color","#E6F4FF");
					$("#contact_person_name").css("border-style","solid");
					$("#contact_person_name").css("border-color","#7FB2CF");
					
					$("#contact_person_email").css("background-color","#E6F4FF");
					$("#contact_person_email").css("border-style","solid");
					$("#contact_person_email").css("border-color","#7FB2CF");
					
					$("#contact_person_phone").css("background-color","#E6F4FF");
					$("#contact_person_phone").css("border-style","solid");
					$("#contact_person_phone").css("border-color","#7FB2CF");	
					
					
				add25();
				document.getElementById('contact_person_name').focus();
				}
			}
		});
		
		//
				
		
				
		function add25()
		{
			//alert("new row working");
				$(document).ready(function(){
				 //alert("Add25");
			
				var ac=addStaff();
			
				function addStaff(){
				//alert("In");
				var contact_person_name=$('#contact_person_name').val();
				var contact_person_email=$('#contact_person_email').val();
				var contact_person_phone=$('#contact_person_phone').val();
		
				
				 //alert(p_c1);
				//document.getElementById("total_price").value=total_price_final;
				
				strCountField = '#prof_count';      
				intFields = $(strCountField).val();
				intFields = Number(intFields);    
				newField = intFields + 1;
				
				strNewField = '<tr class="prof blueBox" id="prof_' + newField + '">\
							<input type="hidden" id="id' + newField + '" name="id' + newField + '" value="-1" />\
<td><input type="text" id="contact_person_name' + newField + '" name="contact_person_name1[]" maxlength="10" value="'+contact_person_name+'" readonly="" /></td>\
            <td><input type="text" id="contact_person_email' + newField + '" name="contact_person_email1[]" maxlength="10" value="'+contact_person_email+'" readonly="" /></td>\
<td><input type="text" id="contact_person_phone' + newField + '" name="contact_person_phone1[]" maxlength="10" value="'+contact_person_phone+'" readonly="" /></td>\
<td><div align="left"><span class="style5"><img src="<?php echo base_url();?>assets/images/delete.png" width="20" height="20" border="0" id="prof_' + newField + '"  value="prof_' + newField + '" onClick="del(this)" ></span></div></td>\
<td><div align="left"><span class="style5">&nbsp;</span></div></td>\
          </tr>\
		  <div class="nopass"><!-- clears floats --></div>\
		  '
		  ;

				$("#prof_" + intFields).after(strNewField);    
				$("#prof_" + newField).slideDown("medium");
				$(strCountField).val(newField);				
				$('#contact_person_name').val('');
				$('#contact_person_email').val('');
				$('#contact_person_phone').val('');
				//alert(strNewField);
				}
				
			
		});
		}
		
		
		function del(id)
		{
		
			var agree=confirm ('Are you want to delete This?')
			{
				if(agree)
				{
				
				var y= ($(id).attr("id"));
				
				var z=y.split('_');
				
				
				
				var contact_person_name="contact_person_name"+z[1];
				var contact_person_email="contact_person_email"+z[1];
				var contact_person_phone="contact_person_phone"+z[1];
				
				
			
				
					document.getElementById(contact_person_name).value='';
					document.getElementById(contact_person_email).value='';
					document.getElementById(contact_person_phone).value='';
					
				 document.getElementById(y).style.display='none';
				 return true
				}
				else
				{
				return false;
				}
		}
		
		//confirm
		 //alert(y);
		
		
		}//del function END
		
		
	
	

	
	
	
			$('.submit').click(function(e){
		
		
		
		 var iwo_number=$('#iwo_number').val();
		 var contact_person_name=$('#inStock').val();
		//alert('supp='+total_price);
		//alert(contact_person_name);
		
		
		if(iwo_number == "" ){
		
			$('#iwo_number').val('');
			$("#iwo_number").css("border-color","red");
			$("#sms").css("display",""); 
			document.getElementById('iwo_number').focus();
			e.preventDefault();
		
		} else if(contact_person_name == "" ){
		 e.preventDefault();
		 $('#contact_person_name').val('');
		  $('#contact_person_name').css("border-color","red");
			document.getElementById(contact_person_name).focus();
			
		} 
		
		
		//return false;
		
	});
 

</script>