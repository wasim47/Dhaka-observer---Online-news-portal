<style>

#u_table {
text-align:right;
	width:600px;
	height:250px;
	float:left;
	margin-bottom:30px;
}

.uc_header {
  float: right;
  text-align:center;
  width:600px;
  font-size:18px;
  font-weight:bold;
  
}

.left_col {
  float: right;
  padding-right: 40px;
}

.right_col {
  float: right;
  padding-right: 40px;
}

#u_table select {
width:160px;

}

#u_table input ,#u_table select  {
  background: none repeat scroll 0 0 #E6F4FF;
  border: 1px solid #7FB2CF;
  border-radius: 2px 2px 2px 2px;
  color: #205291;
  font-family: Verdana,Arial,Helvetica,sans-serif;
  font-size: 9px;
  font-weight: normal;
  height: 18px;
  width: 125px;
}

#u_table input:hover, #u_table input:focus #u_table select:hover, #u_table select:focus {
	border-color:#087DB5;
	background:#E6F4FF;
} 

 .bb_close , .submit {
  background-color: #7DA8D3;
  border: 1px solid #4B87C2;
  border-radius: 3px 3px 3px 3px;
  color: #FFFFFF;
  cursor: pointer;
  font-family: Arial,Helvetica,sans-serif;
  font-size: 12px;
  height: 21px;
  width: 120px;
  margin-left:30px;
}

.submit {

  background-color: #7DA8D3;
  border: 1px solid #4B87C2;
  border-radius: 3px 3px 3px 3px;
  color: #FFFFFF;
  cursor: pointer;
  font-family: Arial,Helvetica,sans-serif;
  font-size: 12px;
  height: 21px;
  width: 120px;
  margin-left:150px;
}



</style>




<?php
		$options = array(
						  '0'  => 'No',
						  '1'    => 'Yes'
						);
						
 		echo form_open("admin/update_user");

?>


<?php ///////////////////////////////////////////////////////////////////////////////////////////////////////////////  ?>
<div id="u_table">
<div class="uc_header">User Create</div>
<?php //print_r($editUser['email']); ?>
	<div class="left_col">
      <p>
            Email: 
            <?php echo $editUser['email'];?>
      </p>
      
     
      <p>
       		Stock Managment:
      		 <?php  if($editUser['sm']==0){?> 
            <?php echo form_dropdown('sm',$options,'0'); } else { ?>
            <?php echo form_dropdown('sm',$options,'1');}  ?>
     </p>
	 
      <p>
            Work Order: 
             <?php  if($editUser['wo']==0){?> 
            <?php echo form_dropdown('wo',$options,'0'); } else { ?>
            <?php echo form_dropdown('wo',$options,'1');}  ?>
      </p>
      <p>
            Report: 
             <?php  if($editUser['report']==0){?> 
            <?php echo form_dropdown('report',$options,'0'); } else { ?>
            <?php echo form_dropdown('report',$options,'1');}  ?>
      </p>
     

</div>
<div class="right_col">

	  <p>
            First Name: 
            <?php echo form_input('first_name',$editUser['first_name'],'id="first_name"');?>
      </p>

      <p>
            Last Name: 
            <?php echo form_input('last_name',$editUser['last_name'],'id="last_name"');?>
      </p>
       <p>
            Super Admin:
            <?php  if($editUser['sa']==0){?> 
            <?php echo form_dropdown('sa',$options,'0'); } else { ?>
            <?php echo form_dropdown('sa',$options,'1');}  ?>
      </p>
       <p>
            Purchase Invoice: 
             <?php  if($editUser['pi']==0){?> 
            <?php echo form_dropdown('pi',$options,'0'); } else { ?>
            <?php echo form_dropdown('pi',$options,'1');}  ?>
      </p>
      <p>
            Issue Order: 
             <?php  if($editUser['io']==0){?> 
            <?php echo form_dropdown('io',$options,'0'); } else { ?>
            <?php echo form_dropdown('io',$options,'1');}  ?>
      </p> 




      
  </div>    
</div>
<p><?php echo form_hidden('id',$editUser['id'],'id="id"');?><?php echo form_submit('submit', 'Update User','class="submit"');?><input class="bb_close" onclick="hideOverlay();" href="#" title="Close" type="button" value="Cancel"></p>
<?php echo form_close();?>