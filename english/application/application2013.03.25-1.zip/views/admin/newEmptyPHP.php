<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>Med-Ped Health Care, LLC</title>
<link href="style.css" rel="stylesheet" type="text/css" />
<link href="dropdown.css" rel="stylesheet" type="text/css" />
<link href="default.ultimate.css" rel="stylesheet" type="text/css" />
</head>

<body>
<div class="mainwrap">
  <div class="twrap">
    <table width="960" border="0" align="center" cellpadding="0" cellspacing="0">
      <tr>
        <td><table width="960" height="129" border="0" cellpadding="0" cellspacing="0">
          <tr>
            <td width="463" height="129" align="left"><img src="images/logo.png" width="520" height="113" border="0" usemap="#Map" /></td>
            <td width="497"><table width="100%" border="0" cellspacing="0" cellpadding="5">
              <tr>
                <td width="94%"><div style="position:fixed; top:0; right:0;">
<div id="google_translate_element"></div><script>
function googleTranslateElementInit() {
  new google.translate.TranslateElement({
    pageLanguage: 'en'
  }, 'google_translate_element');
}
</script><script src="//translate.google.com/translate_a/element.js?cb=googleTranslateElementInit"></script>
</div></td>
                <td width="6%">&nbsp;</td>
              </tr>
              <tr>
                <td align="right"><div class="social" style="padding-right:8px">
        <ul>
          <li><a href="http://www.twitter.com/MedPedHC" target="_blank"><img src="images/twitter.png" alt="Tweet us @MedPedHC"  title="Tweet us @MedPedHC" /></a></li>
          <li><a href="http://www.linkedin.com/company/med-ped-health-care-llc" target="_blank"><img src="images/linkedin.png" alt="Follow us in LinkedIn" title="Follow us in LinkedIn" /></a></li>

		  <li><a href="http://pinterest.com/medpedhc/" target="_blank"><img src="images/pinterest-logo.png" alt="Follow us in LinkedIn" width="28" height="28" border="0" title="Follow us in LinkedIn" /></a></li>

          <li><a href="http://youtube.com/medpedhealthcare" target="_blank"><img src="images/youtube.png" alt="Youtube" title="Youtube" /></a></li>
          <li><a href="http://www.facebook.com/pages/Med-Ped-Health-Care-LLC/129409117123663" target="_blank"><img src="images/facebook.png"  alt="Share with Facebook" title="Share with Facebook"/></a></li>
        </ul>
      </div></td>
                <td>&nbsp;</td>
              </tr>
              <tr>
                <td><div style="text-align:right;"> <a href="http://www.zocdoc.com/practice/med-ped-health-care-4951" id="zocdoc_schedule" target='_top'>Find a College Park Doctor at Practice Med-Ped Health Care on ZocDoc</a>
        <script type="text/javascript" src="http://offsiteSchedule.zocdoc.com/remote/Schedule2.js.aspx?providerid=4951&prefix=zocdoc_&bookBtn=http://offsiteSchedule.zocdoc.com/images/remote/bookAnAppointment1542.jpg" ></script>
      </div></td>
                <td>&nbsp;</td>
              </tr>
            </table></td>
          </tr>
        </table></td>
      </tr>
      <tr>
        <td><ul  class="dropdown dropdown-horizontal">
    <li><a href="index.html">Home</a></li>
    <li><a href="#">About Us</a>
      <ul>
        <li><a href="about.html">Company Overview</a> </li>
		<li><a href="om.html">Occupational Medicine</a> </li>
        <li><a href="doctors.html">OUR DOCTORS</a></li>
		<li><a href="team.html">OUR TEAM</a></li>
      </ul>
    </li>
    <li><a href="testimonials.html" >Testimonials</a> </li>
    <li><a href="#">Patients/Visitors</a>
      <ul>
        <li><a href="services.html">Services</a></li>
        <li><a href="info.html">Practical Information</a></li>
        <li><a href="appointment.php">Request Appointment</a></li>
        <li><a href="careers.html">Careers</a></li>
        <li><a href="#">Notes</a></li>
		<li><a href="patientexperience.php">Patient Experience</a></li>
      </ul>
    </li>
    <li><a href="locations.html">Locations</a>
    <li><a href="contact.html">Hours &amp; Contact Info</a></li>
    </li>
  </ul></td>
      </tr>
      <tr>
        <td><object classid="clsid:D27CDB6E-AE6D-11cf-96B8-444553540000" codebase="http://download.macromedia.com/pub/shockwave/cabs/flash/swflash.cab#version=7,0,19,0" width="960" height="393">
          <param name="movie" value="swf/banner.swf" />
          <param name="quality" value="high" />
		  <param name="wmode" value="transparent" />
          <embed src="swf/banner.swf" quality="high" wmode="transparent" pluginspage="http://www.macromedia.com/go/getflashplayer" type="application/x-shockwave-flash" width="960" height="393"></embed>
        </object></td>
      </tr>
      <tr>
        <td height="10"></td>
      </tr>
      <tr>
        <td><table width="100%" border="0" cellspacing="0" cellpadding="0">
          <tr>
            <td width="30%"><div style="width:290px; float:left">
<script src="http://widgets.twimg.com/j/2/widget.js"></script>
<script>
new TWTR.Widget({
  version: 2,
  type: 'search',
  search: 'medpedhc ',
  interval: 8000,
  title: 'Follow us on Twitter ',
  subject: '@medpedhc  ',
  width: 280,
  height: 130,
  theme: {
    shell: {
      background: '#3c6c38',
      color: '#ffffff'
    },
    tweets: {
      background: '#ffffff',
      color: '#444444',
      links: '#1985b5'
    }
  },
  features: {
    scrollbar: true,
    loop: true,
    live: true,
    hashtags: true,
    timestamp: false,
    avatars: false,
    toptweets: false,
    behavior: 'default'
  }
}).render().start();
</script>
        </div></td>
            <td width="40%"><div style="width:290px; float:left">
          <iframe src="http://www.facebook.com/plugins/likebox.php?href=http%3A%2F%2Fwww.facebook.com%2Fpages%2FMed-Ped-Health-Care-LLC%2F129409117123663&amp;width=380&amp;colorscheme=light&amp;show_faces=true&amp;stream=true&amp;header=true&amp;height=220" scrolling="no" frameborder="0" style="border:none; overflow:hidden; width:380px; height:220px;" allowTransparency="true"></iframe>
        </div></td>
            <td width="30%"><div style="width:290px; float:right"><a href="http://expresshealthcaremd.com" target="_blank"><img src="images/express.jpg" width="280" height="220" border="0" align="right" /></a></div></td>
          </tr>
        </table></td>
      </tr>

    </table>
  </div>

<div class="fwrap"> </div>
<div class="clr"></div>
<div class="footer">
  <div class="footernav"><a href="index.html">Home</a> | <a href="about.html">About Us</a> | <a href="testimonials.html">Testiminals</a> | <a href="locations.html">Locations</a> | <a href="contact.html">Contact Us</a> | <a href="#">Site map</a></div>
  <div class="copyright">Copyright &copy; 2012 <a href="#"><strong>Med-Ped Health Care, LLC</strong></a>. All Rights Reserved. </div>
</div>
</div>

<map name="Map" id="Map"><area shape="rect" coords="140,78,491,105" href="patientexperience.html" />
</map><script type="text/javascript">

  var _gaq = _gaq || [];
  _gaq.push(['_setAccount', 'UA-25716443-1']);
  _gaq.push(['_trackPageview']);

  (function() {
    var ga = document.createElement('script'); ga.type = 'text/javascript'; ga.async = true;
    ga.src = ('https:' == document.location.protocol ? 'https://ssl' : 'http://www') + '.google-analytics.com/ga.js';
    var s = document.getElementsByTagName('script')[0]; s.parentNode.insertBefore(ga, s);
  })();

</script></body>
</html>
