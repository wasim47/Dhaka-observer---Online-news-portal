<style>

#u_table {
text-align:right;
	width:600px;
	height:250px;
	float:left;
	margin-bottom:30px;
}

.uc_header {
  float: right;
  text-align:center;
  width:600px;
  font-size:18px;
  font-weight:bold;
  
}

.left_col {
  float: right;
  padding-right: 40px;
}

.right_col {
  float: right;
  padding-right: 40px;
}

#u_table select {
width:160px;

}

#u_table input ,#u_table select  {
  background: none repeat scroll 0 0 #E6F4FF;
  border: 1px solid #7FB2CF;
  border-radius: 2px 2px 2px 2px;
  color: #205291;
  font-family: Verdana,Arial,Helvetica,sans-serif;
  font-size: 9px;
  font-weight: normal;
  height: 18px;
  width: 125px;
}

#u_table input:hover, #u_table input:focus #u_table select:hover, #u_table select:focus {
	border-color:#087DB5;
	background:#E6F4FF;
} 

 .bb_close , .submit {
  background-color: #7DA8D3;
  border: 1px solid #4B87C2;
  border-radius: 3px 3px 3px 3px;
  color: #FFFFFF;
  cursor: pointer;
  font-family: Arial,Helvetica,sans-serif;
  font-size: 12px;
  height: 21px;
  width: 120px;
  margin-left:30px;
}

.submit {

  background-color: #7DA8D3;
  border: 1px solid #4B87C2;
  border-radius: 3px 3px 3px 3px;
  color: #FFFFFF;
  cursor: pointer;
  font-family: Arial,Helvetica,sans-serif;
  font-size: 12px;
  height: 21px;
  width: 120px;
  margin-left:150px;
}



</style>


<div id="errors"><?php echo $message;?></div>

<?php
		$options = array(
						  '0'  => 'No',
						  '1'    => 'Yes'
						);
						
 		echo form_open("admin/create_user");

?>


<?php ///////////////////////////////////////////////////////////////////////////////////////////////////////////////  ?>
<div id="u_table">
<div class="uc_header">User Create</div>
	<div class="left_col">
      <p>
            Email: 
            <?php echo form_input('email','','id="email"');?>
      </p>

      
      <p>
            Password: 
            <?php echo form_password('password','','id="password"');?>
      </p>

      <p>
            Confirm Password: 
            <?php echo form_password('password_confirm','','id="password_confirm"');?>
      </p>
      <p>
       		Stock Managment:
      		<?php echo form_dropdown('sm',$options,'No'); ?>
     </p>
	 
      <p>
            Work Order: 
            <?php echo form_dropdown('wo',$options,'No'); ?>
      </p>
      <p>
            Report: 
            <?php echo form_dropdown('report',$options,'No'); ?>
      </p>
     

</div>
<div class="right_col">

	  <p>
            First Name: 
            <?php echo form_input('first_name','','id="first_name"');?>
      </p>

      <p>
            Last Name: 
            <?php echo form_input('last_name','','id="last_name"');?>
      </p>
       <p>
            Super Admin: 
            <?php echo form_dropdown('sa',$options,'No'); ?>
      </p>
       <p>
            Purchase Invoice: 
            <?php echo form_dropdown('pi',$options,'No'); ?>
      </p>
      <p>
            Issue Order: 
            <?php echo form_dropdown('io',$options,'No'); ?>
      </p> 




      
  </div>    
</div>
<p><?php echo form_submit('submit', 'Create User','class="submit"');?><input class="bb_close" onclick="hideOverlay();" href="#" title="Close" type="button" value="Cancel"></p>
<?php echo form_close();?>