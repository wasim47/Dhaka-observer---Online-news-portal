
<?php //+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++?>
<table width="100%" border="0" cellspacing="0" cellpadding="0">
	<tr>
	<td colspan="3"><img src="<?php echo base_url();?>assets/images/main_body_01.jpg" width="986" height="35" /></td>
	</tr>
	<tr>
	<td><img src="<?php echo base_url();?>assets/images/main_body_02.jpg" width="24" height="60" /></td>
	<td background="images/main_body_03.jpg" width="936" height="50">
	<table width="930"  border="0">
	<tr>
	<td width="49"><img src="<?php echo base_url();?>assets/images/icon-48-article.png" width="48" height="48" /></td>
	<td width="595"><h1><span class="user">User Management </span></h1></td>
	<!--<td width="28" class="border"><div align="center" class="section"><a href="javascript:void(0);" onClick="article_delete('delete','0');" ><img src="images/delete2.png" width="32" height="32" border="0" />Delete</a></div></td>-->
	<!--<td width="33" class="border"><div align="center" class="section"><a href="#" class="newFrm">
	<img src="images/edit1.png" width="32" height="32" border="0" />Edit</a></div></td>-->
	<td width="33" class="border">
	<div align="center" class="section">
	<a class="uCreate" href="<?php echo base_url();?>admin/create_user/"><img src="<?php echo base_url();?>assets/images/new1.png" width="30" height="30" border="0" />New</a>
	</div>
	</td>
	
	</tr>
	</table>
	</td>
	<td><img src="<?php echo base_url();?>assets/images/main_body_04.jpg" width="26" height="60" /></td>
	</tr>
	<tr>
	<td colspan="3"><img src="<?php echo base_url();?>assets/images/main_body_05.jpg" width="986" height="32" /></td>
	</tr>
</table>
    
    <table width="100%" border="0" cellspacing="0" cellpadding="0">
	<tr>
	<td colspan="3"><img src="<?php echo base_url();?>assets/images/main_body_01.jpg" width="986" height="35" /></td>
	</tr>
	<tr>
	<td style="background:url(assets/images/bar.jpg) repeat-y;" valign="top"><img src="<?php echo base_url();?>assets/images/main_body_02.jpg" width="24" height="181" /></td>
	<td width="936" height="181" align="center" style="background:url(assets/images/main_body_03.jpg) repeat-x; background-color:#dee4f0" >
	
	
	<div class="table_user_round1">
	  <table width="910" cellpadding="2" cellspacing="1">
        <tr >
          <td height="35" colspan="5" align="left" valign="top"><form action="" method="post">
              <table width="406" border="0" cellspacing="2" cellpadding="1">
                <tr>
                  <td width="2%">&nbsp;</td>
                  <td width="17%" align="center" valign="middle"><span class="filter2">Filter :</span> </td>
                  <td width="26%" align="left" valign="middle"><label>
                    <input type="text" name="target" id="target" class="filter">
                  </label></td>
                  <td width="15%" align="left" valign="middle"><label>
                    <input type="submit" name="submit" value="Go" class="button">
                  </label></td>
                  <td width="40%" align="left" valign="middle"><input type="reset" name="reset" value="Reset" class="button"></td>
                </tr>
              </table>
          </form></td>
          <td width="59" align="left" valign="middle">&nbsp;</td>
          <td width="162" align="left" valign="middle">
          
		  <form name="state_form" action="<?php echo $_SERVER['PHP_SELF']; ?>" method="post">
		    <select name="state" id="state" style="height:20px;" onchange="this.form.submit()">
              <option value="">Select Publish</option>
              <option value="1">Publish</option>
              <option value="0">All</option>
            </select>
		  </form>		  </td>
        </tr>
		</table>
		<table  cellpadding="4" cellspacing="1">
          <tr>
            <td width="19" height="26" align="center" bgcolor="#C9DEF1" class="table_header"><span class="style2">#</span></td>
            <td width="85" align="center" bgcolor="#C9DEF1" class="table_header"><span class="style2">First Name </span></td>
            <td width="90" align="center" bgcolor="#C9DEF1" class="table_header"><span class="style2">Last Name </span></td>
            <td width="158" align="center" bgcolor="#C9DEF1" class="table_header"><span class="style2">User Name </span></td>
            
            <td width="45" align="center" bgcolor="#C9DEF1" class="table_header"><span class="style2">Status</span></td>
            <td width="78" align="center" bgcolor="#C9DEF1" class="table_header"><span class="style2">Last Update</span></td>
            <td width="57" align="center" bgcolor="#C9DEF1" class="table_header"><span class="style2">P.Invoice</span></td>
            <td width="74" align="center" bgcolor="#C9DEF1" class="table_header"><span class="style2">Work Order</span></td>
            <td width="76" align="center" bgcolor="#C9DEF1" class="table_header"><span class="style2">Issue Order</span></td>
            <td width="51" align="center" bgcolor="#C9DEF1" class="table_header"><span class="style2">Report</span></td>
            
            <td width="101" align="center" bgcolor="#C9DEF1" class="table_header"><span class="style2">Action </span></td>
          </tr>
        </table>
		<div style="overflow:scroll; overflow-x:hidden; width:910px; max-height:313px;">
		  <table  cellpadding="4" cellspacing="1">
            
            <?php $i=1; foreach ($users as $user):?>
            <?php if($i%2!=0)
			 { $c="#E3EDF9";
			 } else {
				$c="#FFFFFF"; } ?>
            <tr class="table_hover" bgcolor="<?php echo $c; ?>">
              <td width="19" height="27" align="center"><span class="style9"><?php echo $i;?></span></td>
              <td width="79" align="left" class="section" style="padding-left:10px;"><a href="#" title="<?php echo $user->email;?>" class="style2" > <?php echo $user->first_name;?></a></td>
              <td width="87" align="center" class="style2"><?php echo $user->last_name;?></td>
              <td width="153" align="center" class="style2"><?php echo $user->email;?>              </td>
              <td width="45" align="center"><span class="style2"><!--<?php echo ($user->active) ? anchor("admin/deactivate/".$user->id, 'A',' class="newFrm" ') : anchor("admin/activate/". $user->id, 'I',' class="newFrm" ');?>-->
			  
			  <?php if(($user->active)==0){?>
               <a href="<?php echo base_url();?>admin/activate/<?php echo $user->id; ?>" title="Deactive"><img src="<?php echo base_url();?>assets/images/stop.png" border=0></a>
			  <?php } else { ?>
              <a href="<?php echo base_url();?>admin/deactivate/<?php echo $user->id; ?>" title="Deactive"><img src="<?php echo base_url();?>assets/images/active.png" border=0></a><?php } ?>
              
              </span></td>
              <td width="80" align="center" class="style9"><?php echo $user->created_on;?></td>
              <td width="57" align="center" class="style9"><?php if(($user->pi)==0){?> <img src="<?php echo base_url();?>assets/images/stop.png" border=0><?php }
			  else{ ?><img src="<?php echo base_url();?>assets/images/active.png" border=0><?php } ?></span></td>
              <td width="75" align="center"><?php if(($user->wo)==0){?> <img src="<?php echo base_url();?>assets/images/stop.png" border=0><?php }
			  else{ ?><img src="<?php echo base_url();?>assets/images/active.png" border=0><?php } ?></span></td>
              <td width="79" align="center" class="style9"><?php if(($user->io)==0){?> <img src="<?php echo base_url();?>assets/images/stop.png" border=0><?php }
			  else{ ?><img src="<?php echo base_url();?>assets/images/active.png" border=0><?php } ?></span></td>
              <td width="52" align="center" class="style9"><?php if(($user->report)==0){?> <img src="<?php echo base_url();?>assets/images/stop.png" border=0><?php }
			  else{ ?><img src="<?php echo base_url();?>assets/images/active.png" border=0><?php } ?></span></td>
          
              
              <td width="82" align="center" class="section"><a href="<?php echo base_url();?>admin/edit_user/<?php echo $user->id; ?>" class="uCreate" title="Edit"><img src="<?php echo base_url();?>assets/images/pensil.png" border="0"> </a>&nbsp;&nbsp;&nbsp; <a href="<?php echo base_url();?>dashboard/user_del/<?php echo $user->id; ?>" title="Delete"><img src="<?php echo base_url();?>assets/images/delete.png" border="0"></a> </td>
            </tr>
            <?php $i++; endforeach;?>           
            
          </table>
		</div>
	</div></td>
	<td style="background:url(assets/images/bar1.jpg) repeat-y;" valign="top"><img src="<?php echo base_url();?>assets/images/main_body_04.jpg" width="26" height="181" /></td>
	</tr>
	<tr>
	<td colspan="3"><img src="<?php echo base_url();?>assets/images/main_body_05.jpg" width="986" height="32" /></td>
	</tr>
	</table>
<div id="errors"><?php echo $message;?></div>
<?php //+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++?>


<div id="lightBox" align="center">
	<table cellspacing="0" cellpadding="0">
	<tr>
	<td colspan="3" align="right">
	<!--<a title="Close" class="bb_close" href="javascript:void(0);" onClick="hideOverlay();"></a>--></td>
	</tr>
	<tr>
	<td class="t_l"></td>
	<td class="t_c"></td>
	<td class="t_r"></td>
	</tr>
	<tr>
	<td class="c_l"></td>
	<td class="c_c">
	<div id="lightText"></div></td>
	<td class="c_r"></td>
	</tr>
	<tr>
	<td class="b_l"></td>
	<td class="b_c"></td>
	<td class="b_r"></td>
	</tr>
	</table>
</div>

<div id="lightBox3" align="center">
	<table cellspacing="0" cellpadding="0">
	<tr>
	<td colspan="3" align="right">
	<!--<a title="Close" class="bb_close" href="javascript:void(0);" onClick="hideOverlay();"></a>--></td>
	</tr>
	<tr>
	<td class="t_l"></td>
	<td class="t_c"></td>
	<td class="t_r"></td>
	</tr>
	<tr>
	<td class="c_l"></td>
	<td class="c_c">
	<div id="lightText3"></div></td>
	<td class="c_r"></td>
	</tr>
	<tr>
	<td class="b_l"></td>
	<td class="b_c"></td>
	<td class="b_r"></td>
	</tr>
	</table>
</div>