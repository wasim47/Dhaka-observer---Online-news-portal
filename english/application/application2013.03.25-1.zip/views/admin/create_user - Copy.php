


<!--<div id="errors"><?php echo $message;?></div>-->

<?php echo form_open("admin/create_user");?>



<table width="600" border="0" cellspacing="2" cellpadding="3">
		<tr>
		<td width="124">&nbsp;</td>
		<td>&nbsp;</td>
		<td>&nbsp;</td>
		<td width="156">&nbsp;</td>
		</tr>
		<tr>
		<td colspan="4" align="center" valign="middle" class="style1 style4">User Create </td>
		</tr>
		<tr>
		<td width="124">&nbsp;</td>
		<td>&nbsp;</td>
		<td>&nbsp;</td>
		<td width="156">&nbsp;</td>
		</tr>
		<tr height="22">
		<td align="right" valign="middle"><span class="category_content">User Name</span></td>
		<td align="left" valign="middle" style="padding-left:3px;">
		<input name="user_name" type="text" class="input" id="user_name" />
		<div style="float:left; display:none; color:#FF6600; width:200px;" id="title1">Required User Name *</div>		</td>
		<td align="right" valign="middle"><span class="category_content">First Name</span></td>
		<td style="padding-left:3px;">
		<input name="first_name" type="text" class="input" id="first_name" />
		<div style="float:left; display:none; color:#FF6600; width:200px;" id="title2">Required First Name *</div>		</td>
		</tr>
		<tr height="22">
		<td align="right" valign="middle"><span class="category_content">Password</span></td>
		<td align="left" valign="middle" style="padding-left:3px;">
		<input name="password" type="password" class="input" id="password" />
		<div style="float:left; display:none; color:#FF6600; width:200px;" id="title3">Required Password *</div>		</td>
		<td align="right"><span class="category_content">Last Name</span></td>
		<td style="padding-left:3px;">
		<input name="last_name" type="text" class="input" id="last_name" />
		<div style="float:left; display:none; color:#FF6600; width:200px;" id="title4">Required Last Name *</div>		</td>
		</tr>
		<tr height="22">
          <td align="right" valign="middle"><span class="category_content">Depot Code</span></td>
		  <td align="left" valign="middle" style="padding-left:3px;">
		  <input name="depot_code" type="text" class="input" id="depot_code" />
		  <div style="float:left; display:none; color:#FF6600; width:200px;" id="title5">Required Depot Code *</div>		  </td>
		  <td align="right" valign="middle"><span class="category_content">Collection</span></td>
		  <td style="padding-left:3px;"><select name="collection" class="input" id="collection">
            <option value="1">Yes</option>
            <option value="0">No</option>
          </select></td>
	  </tr>
		<tr height="22">
		  <td align="right" valign="middle"><span class="category_content">Transaction</span></td>
		  <td align="left" valign="middle" style="padding-left:3px;"><select name="transaction" class="input" id="transaction">
              <option value="1">Yes</option>
              <option value="0">No</option>
          </select></td>
		  <td align="right"><span class="category_content">Status</span></td>
		  <td style="padding-left:3px;"><select name="status" class="input" id="status">
            <option value="1">Yes</option>
            <option value="0">No</option>
          </select></td>
	  </tr>
		<tr height="22">
		  <td align="right"><span class="category_content">Requisition</span></td>
		  <td align="left" style="padding-left:3px;"><select name="requisition" class="input" id="requisition">
            <option value="1">Yes</option>
            <option value="0">No</option>
          </select></td>
		  <td align="right" valign="middle"><span class="category_content">Depot Management</span></td>
		  <td style="padding-left:3px;"><select name="depot_management" class="input" id="depot_management">
            <option value="1">Yes</option>
            <option value="0">No</option>
          </select></td>
	  </tr>
		<tr height="22">
          <td align="right" valign="middle"><span class="category_content">Stock Management</span></td>
		  <td align="left" valign="middle" style="padding-left:3px;"><select name="stock_management" class="input" id="stock_management">
            <option value="1">Yes</option>
            <option value="0">No</option>
          </select></td>
		  <td align="right"><span class="category_content">Report</span></td>
		  <td><span style="padding-left:3px;">
		    <select name="report" class="input" id="report">
              <option value="1">Yes</option>
              <option value="0">No</option>
            </select>
		  </span></td>
	  </tr>
		<tr height="22">
		<td colspan="4" align="center"><table width="100%" border="0" cellspacing="1" cellpadding="1">
		<tr>
		<td width="124">&nbsp;</td>
		<td colspan="2">&nbsp;</td>
		<td colspan="2">&nbsp;</td>
		<td width="156">&nbsp;</td>
		</tr>
		<tr>
		  <td width="50%" align="right" valign="middle"><input type="submit"  name="create2" value="Create " id="submit"/></td>
		  <td width="4%">&nbsp;</td>
		<td width="46%" align="left" valign="middle"><input type="button"  name="create22" value="Cancel" id="submit" onClick="hideOverlay();"/></td>
		</tr>
		</table></td>
		</tr>
		<tr>
		<td width="124">&nbsp;</td>
		<td>&nbsp;</td>
		<td>&nbsp;</td>
		<td width="156">&nbsp;</td>
		</tr>
	</table>
<?php ///////////////////////////////////////////////////////////////////////////////////////////////////////////////  ?>

      <p>
            First Name: <br />
            <?php echo form_input('first_name','','id="first_name"');?>
      </p>

      <p>
            Last Name: <br />
            <?php echo form_input('last_name','','id="last_name"');?>
      </p>

      <p>
            Company Name: <br />
            <?php echo form_input('company','','id="company"');?>
      </p>

      <p>
            Email: <br />
            <?php echo form_input('email','','id="email"');?>
      </p>


      <p>
            Password: <br />
            <?php echo form_password('password','','id="password"');?>
      </p>

      <p>
            Confirm Password: <br />
            <?php echo form_password('password_confirm','','id="password_confirm"');?>
      </p>

      <p><?php
    $options = array(
                  'small'  => 'Default',
                  'admin'    => 'Admin',
                  'owner'   => 'Owner',
                  'family' => 'Family',
                );

      
       echo form_label('Role','role')."<br />";
       echo form_dropdown('role',$options,'deafult');
       ?></p>


      <p><?php echo form_submit('submit', 'Create User');?></p>

<?php echo form_close();?>