<?php
	//session_start();
	require_once("classes/config.php");
	$depot_admin_id=$_SESSION['depot_admin_id'];
	
	$zone_id = $_REQUEST['zone_id'];
	
	$query = mysql_query("select * from district where zone_id = '$zone_id' order by dist_name");
	
	
?>
<select name="dist_id" id="dist_id" class="light_drop">
	<option value="">Select District</option>
	<?php 
	while (	$r = mysql_fetch_array($query))
	{
	?>		
	<option value="<?php echo $r['dist_id'] ;?>"><?php echo $r['dist_name'] ;?></option>
	<?php
	} 
	?>
</select>