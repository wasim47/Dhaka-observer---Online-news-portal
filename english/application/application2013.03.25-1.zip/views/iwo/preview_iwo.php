
<style>

#u_table {
text-align:right;
	width:725px;
	min-height:400px;
	float:left;
	margin-bottom:30px;
}

.uc_header {
  float: right;
  text-align:center;
  width:800px;
  font-size:18px;
  font-weight:bold;
  
}

.left_col {
  margin-top: 10px;
  float: right;
  /*padding-right: 150px;*/
}

.right_col {
  float: left;
  margin-top: 10px;
  padding-right: 20px;
}

.row1 {

	height:165px;
}

#u_table select {
width:160px;

}

#u_table input ,#u_table select {
  background: none repeat scroll 0 0 #E6F4FF;
  border: 1px solid #7FB2CF;
  border-radius: 2px 2px 2px 2px;
  color: #205291;
  font-family: Verdana,Arial,Helvetica,sans-serif;
  font-size: 9px;
  font-weight: normal;
  height: 18px;
 /* width: 150px;*/
}

#u_table .row2 input ,#u_table .row2 select {
  background: none repeat scroll 0 0 #E6F4FF;
  border: 1px solid #7FB2CF;
  border-radius: 2px 2px 2px 2px;
  color: #205291;
  font-family: Verdana,Arial,Helvetica,sans-serif;
  font-size: 9px;
  font-weight: normal;
  height: 18px;
  width: 95%;
}

#u_table input:hover, #u_table input:focus #u_table select:hover, #u_table select:focus {
	border-color:#087DB5;
	background:#E6F4FF;
} 

 .bb_close , .submit {
  background-color: #7DA8D3;
  border: 1px solid #4B87C2;
  border-radius: 3px 3px 3px 3px;
  color: #FFFFFF;
  cursor: pointer;
  font-family: Arial,Helvetica,sans-serif;
  font-size: 12px;
  height: 21px;
  width: 120px;
  margin-left: 300px;
}


  
  #u_table button  {
  background-color: #7DA8D3;
  border: 1px solid #4B87C2;
  border-radius: 3px 3px 3px 3px;
  color: #FFFFFF;
  cursor: pointer;
  font-family: Arial,Helvetica,sans-serif;
  font-size: 12px;
  height: 21px;
  
  width: 120px;
}
                      
              #groupCode1 {
  background: none repeat scroll 0 0 #E6F4FF;
  border: 1px solid #7FB2CF;
  border-radius: 2px 2px 2px 2px;
  color: #205291;
  font-family: Verdana,Arial,Helvetica,sans-serif;
  font-size: 9px;
  font-weight: normal;
  height: 16px;
  width: 70px;
}

#u_table textarea {
  background: none repeat scroll 0 0 #E6F4FF;
  border: 1px solid #7FB2CF;
  border-radius: 2px 2px 2px 2px;
  color: #205291;
  font-family: Verdana,Arial,Helvetica,sans-serif;
  font-size: 9px;
  font-weight: normal;
  width: 250px;
  height: 56px;
}
.style4 {font-size: 12px}
#u_table .row1 .right_col table {
}
#u_table .row1 .right_col table {
}
</style>




<?php ///////////////////////////////////////////////////////////////////////////////////////////////////////////////  ?>
<div id="u_table">
<div class="uc_header"> Preview Internal Work Order</div>
<div class="row1">  
              
                          <div class="right_col">
                    <table width="100%" border="0" cellspacing="4" >
              <tr>
                <td width="170"><div align="right">Internal Work Order #</div></td>
                <td width="18" id="groupCode1" ><div align="left"><?php echo form_input('iwo_number',$clientInfo[0]->iwo_number,'id="iwo_number" style="width:100px;" class="vertical" tabindex="1" onblur="iwoCheck()"');?></div></td><td colspan="3" id="sms" style="display:none;color:red; font-size:09px; text-align:left;">in use or empty</td>                
              </tr><tr >
                <td>Client Name:</td>
                <td id="groupCode1" ><div align="left"><?php echo $clientInfo[0]->client_name;?></div></td><td width="41">PO #:</td>
                <td  id="groupCode1" ><div align="left"><?php echo $clientInfo[0]->po_number;?></div></td>
                

              </tr>
              <tr>
                <td colspan="4"><div align="center"><strong>Client contact person info</strong></div></td>
                </tr>
              <tr>
                <td>Contact Person Name:</td>
                <td  id="groupCode1"  ><div align="left"><?php echo $clientInfo[0]->contact_person_name;?></div></td>
                <td>&nbsp;</td><td>&nbsp;</td>
              </tr>
                    </table>
            
            
                    
    </div> 
    <div class="left_col">
            <div style="margin-bottom:15px;" > <table width="300">         
              <tr>
    <td  >Order Date</td><td  id="groupCode1" ><?php echo $clientInfo[0]->iwoDate;?></td>
    <td>Delivery Date</td><td id="groupCode1" ><?php echo $clientInfo[0]->deliveryDate;?></td>
  </tr> </table></div>
                  
                    <table width="179%" border="0" style="float:right;">
              <tr>
                <td ><div align="right">Issue Factory Name</div></td>
                <td  id="groupCode1" ><div align="left"><?php echo $clientInfo[0]->factory_name;?> </div></td>
              </tr>
              <tr>
                <td ><div align="right">Printing PO #</div></td>
                <td  id="groupCode1" ><div align="left"><?php echo $clientInfo[0]->printing_po_number;?></div></td>
              </tr>
              <tr>
                <td ><div align="right">Work Order Issued By</div></td>
                <td   id="groupCode1" ><div align="left"><?php echo $clientInfo[0]->issued_by;?></div></td>
              </tr>
              <tr>
                <td ><div align="right">Work Order Issued To</div></td>
                <td    id="groupCode1" ><div align="left"><?php echo $clientInfo[0]->issued_to;?></div></td>
              </tr>
            </table>
     
       
 

          
    </div>
    
      
    </div>    
 <div class="row2">
   <table width="100%" border="0" style="">
     <thead>
       <tr>
         <th width="50%"><div align="center"><span class="style4">Product Description</span></div></th>
         <th width="25%"><div align="center"><span class="style4">Measurement Size</span></div></th>
         <th width="25%"><div align="center"><span class="style4">Product Quantity</span></div></th>
         <th width="25%"><div align="center"><span class="style4">Total Quantity</span></div></th>
       </tr>
     </thead>
     <tbody id="addContent"><?php foreach($previewData as $data):?>
       <tr>
         <td   id="groupCode1" ><div align="center"><?php echo $data->product_description;?></div></td>
         <td id="groupCode1" ><div align="center"><?php echo $data->measurement_size;?></div></td>
         <td width="18%"  id="groupCode1" ><div align="center"><?php echo $data->product_quantity;?></div></td>
         <td width="18%"  id="groupCode1" ><div align="center"><?php echo $data->total_quantity;?></div></td>
       </tr><?php endforeach; ?>
       <tr>
         <input id="prof_count" type="hidden" value="1" name="prof_count" />
       </tr>
       <tr id="prof_1"></tr>
       <tr >&nbsp;</tr>
       <tr style="border: 1px solid #7FB2CF; ">
         <td colspan="2">&nbsp;</td>
         <td>&nbsp;</td>
         <td>&nbsp;</td>
       </tr>
        
     </tbody>
   </table>
   <table width="100%" border="0">
  <tr style="border: 1px solid #7FB2CF; ">
         <td width="36%" valign="top"><div align="right" class="style4"><strong>Instruction</strong></div></td>
         <td width="29%"><?php echo form_textarea('comment',$clientInfo[0]->comment,'id="comment"');?></td>
         <td>&nbsp;</td>
         <td width="18%" >&nbsp;</td>
       </tr>
</table>

 </div>
</div>    

<div class="row3">
<p><input class="bb_close" onclick="hideOverlay();" href="#" title="Close" type="button" value="Cancel"></p>

    </div><!--end row3-->
</div><!--end u_table-->




    



         
		