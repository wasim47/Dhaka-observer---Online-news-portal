<script type="text/javascript" src="<?php echo base_url();?>assets/js/common.js"></script><!-- for light Box -->
<script type="text/javascript" src="<?php echo base_url();?>assets/js/jquery.autocomplete.js"></script><!-- for Auto Complete -->
<link rel="stylesheet" type="text/css" href="<?php echo base_url();?>assets/css/lightbox.css" /><!-- for light Box -->
<link rel="stylesheet" type="text/css" href="<?php echo base_url();?>assets/css/jquery.autocomplete.css" /><!-- for Auto Complete CSS -->


<script src="<?php echo base_url();?>assets/js/datepicker/jquery.ui.core.js"></script>
	<script src="<?php echo base_url();?>assets/js/datepicker/jquery.ui.widget.js"></script>
	<script src="<?php echo base_url();?>assets/js/datepicker/jquery.ui.datepicker.js"></script>
    
	<link rel="stylesheet" href="<?php echo base_url();?>assets/css/jquery.ui.all.css">
<style>

#u_table {
text-align:right;
	width:900px;
	min-height:400px;
	float:left;
	margin-bottom:30px;
}

.uc_header {
  float: right;
  text-align:center;
  width:800px;
  font-size:18px;
  font-weight:bold;
  
}

.left_col {
  margin-top: 10px;
  float: right;
  /*padding-right: 150px;*/
}

.right_col {
  float: left;
  margin-top: 10px;
  padding-right: 20px;
}

.row1 {

	height:200px;
}



#u_table input ,#u_table select {
  background: none repeat scroll 0 0 #E6F4FF;
  border: 1px solid #7FB2CF;
  border-radius: 2px 2px 2px 2px;
  color: #205291;
  font-family: Verdana,Arial,Helvetica,sans-serif;
  font-size: 9px;
  font-weight: normal;
  height: 18px;
 /* width: 150px;*/
}

#u_table .row2 input ,#u_table .row2 select {
  background: none repeat scroll 0 0 #E6F4FF;
  border: 1px solid #7FB2CF;
  border-radius: 2px 2px 2px 2px;
  color: #205291;
  font-family: Verdana,Arial,Helvetica,sans-serif;
  font-size: 9px;
  font-weight: normal;
  height: 18px;
  width: 95%;
}

#u_table input:hover, #u_table input:focus #u_table select:hover, #u_table select:focus {
	border-color:#087DB5;
	background:#E6F4FF;
} 

 .bb_close , .submit {
  background-color: #7DA8D3;
  border: 1px solid #4B87C2;
  border-radius: 3px 3px 3px 3px;
  color: #FFFFFF;
  cursor: pointer;
  font-family: Arial,Helvetica,sans-serif;
  font-size: 12px;
  height: 21px;
  width: 120px;
  margin-left:30px;
}

.submit {
  background-color: #7DA8D3;
  border: 1px solid #4B87C2;
  border-radius: 3px 3px 3px 3px;
  color: #FFFFFF;
  cursor: pointer;
  font-family: Arial,Helvetica,sans-serif;
  font-size: 12px;
  height: 21px;
  margin-left: 300px;
  width: 120px;
}
  
  #u_table button  {
  background-color: #7DA8D3;
  border: 1px solid #4B87C2;
  border-radius: 3px 3px 3px 3px;
  color: #FFFFFF;
  cursor: pointer;
  font-family: Arial,Helvetica,sans-serif;
  font-size: 12px;
  height: 21px;
  
  width: 120px;
}
                      
              #groupCode1 {
  background: none repeat scroll 0 0 #E6F4FF;
  border: 1px solid #7FB2CF;
  border-radius: 2px 2px 2px 2px;
  color: #205291;
  font-family: Verdana,Arial,Helvetica,sans-serif;
  font-size: 9px;
  font-weight: normal;
  height: 16px;
  width: 70px;
}

#u_table textarea {
  background: none repeat scroll 0 0 #E6F4FF;
  border: 1px solid #7FB2CF;
  border-radius: 2px 2px 2px 2px;
  color: #205291;
  font-family: Verdana,Arial,Helvetica,sans-serif;
  font-size: 9px;
  font-weight: normal;
  width: 400px;
  height: 56px;
}
#u_table .pd  {
  background: none repeat scroll 0 0 #E6F4FF;
  border: 1px solid #7FB2CF;
  border-radius: 2px 2px 2px 2px;
  color: #205291;
  font-family: Verdana,Arial,Helvetica,sans-serif;
  font-size: 9px;
  font-weight: normal;
  width: 600px;
  height: 56px;
}
.style4 { font-size: 12px }
#u_table .row1 .right_col table {
}
#u_table .row1 .right_col table {
}
</style>


<?php echo form_open("iwo/insert_iwo"); ?>


<?php ///////////////////////////////////////////////////////////////////////////////////////////////////////////////  ?>
<div id="u_table">
<div class="uc_header"> Create Internal Work Order</div>
<div class="row1">  
              
                          <div class="right_col">
                    <table width="100%" border="0" cellspacing="4" >
            <!--  <tr>
                <td width="170"><div align="right">Internal Work Order #</div></td>
                <td width="18"><?php echo form_input('iwo_number','','id="iwo_number" style="width:100px;" class="vertical" tabindex="1" onblur="iwoCheck()"');?></td><td colspan="3" id="sms" style="display:none;color:red; font-size:09px; text-align:left;">in use or empty</td>                
              </tr>--><tr >
                <td>Client Name:</td>
                <td ><?php echo form_input('client_name','','id="clientName" autocomplete="off"   class="vertical" style="width:100px;" onKeyUp="clientInfo()"  tabindex="2" onblur="clientInfo()"');?></td><td>PO #:</td>
                <td><?php echo form_input('po_number','','id="po_number" style="width:100px;" class="vertical" tabindex="3"');?></td>
                <td><a class="pi" href="<?php echo base_url();?>client_manage/create_client"><img src="<?php echo base_url();?>assets/images/newSupplier.png" width="36" height="26" border="0" /></a></td>

              </tr>
              <tr>
                <td>Client Email</td>
                <td  ><?php echo form_input('client_email','','id="client_email" style="width:100px;"');?></td><td width="41" >Phone:</td>
                <td><?php echo form_input('client_phone','','id="client_phone" style="width:105px;"');?></td>
                <td>&nbsp;</td>
                
              </tr>
                   <table border="1" id="contact_person">
 
</table>
      
                    </table>
            
            
                    
    </div> 
    <div class="left_col">
            <div style="margin-bottom:15px;" > <table width="300">         
              <tr>
    <td  >Order Date</td><td id="groupCode1" class"iwoDate">
      <span class="todate"><?php echo date('Y-m-d');?></span><?php echo form_hidden('iwoDate',date('Y-m-d'),'id="iwoDate"');?></strong></td><td>Delivery Date<?php echo form_input('deliveryDate','','id="deliveryDate" style="width:70px;" class="vertical" tabindex="4"');?></td>
  </tr> </table></div> 
   <?php 
  $options = array(
                  'none'  => 'None',
                  'Dhaka'  => 'Dhaka',
                  'Sylhet'    => 'Sylhet',
                  'Chittagong'   => 'Chittagong',
                  'Comillah' => 'Comillah',
                ); ?>
                  
<table width="179%" border="0" style="float:right;">
              <tr>
                <td ><div align="right">Issue Factory Name</div></td>
                <td  ><?php echo form_dropdown('factory_name', $options, 'none','id="factory_name" style="width:100px;" class="vertical" tabindex="5"');?></td>
              </tr>
              <tr>
                <td ><div align="right">Printing PO #</div></td>
                <td ><?php echo form_input('printing_po_number','','id="printing_po_number" style="width:100px;" class="vertical" tabindex="6"');?></td>
              </tr>
              <tr>
                <td ><div align="right">Work Order Issued By</div></td>
                <td  id="groupCode1" ><div align="center"><strong><?php echo $this->session->userdata('username');?></strong></div></td>
              </tr>
              <tr>
                <td ><div align="right">Work Order Issued To</div></td>
                <td   ><?php echo form_input('issued_to','','id="issued_to" style="width:100px;" class="vertical" tabindex="7"');?></td>
              </tr>
   
            </table>
     
       
 

          
    </div>
    
      
    </div>    
 <div class="row2">
   <table width="100%" border="0">
     <thead>
       <tr>
         <th colspan="2"><div align="center"><span class="style4">Product Description</span></div></th>
         <th width="17%"><div align="center"><span class="style4">Measurement Size</span></div></th>
         <th width="18%"><div align="center"><span class="style4">Product Quantity</span></div></th>
         <th width="18%"><div align="center"><span class="style4">Total Quantity</span></div></th>
       </tr>
     </thead>
     <tbody id="addContent">
       <tr>
         <td colspan="2" ><?php echo form_textarea('product_description1','','id="product_description" class="pd" autocomplete="off"  style=" background-color:#FFFFFF;" ');?></td>
      <td><?php echo form_input('measurement_size1','','id="measurement_size" class="vertical" tabindex="9" ');?></td>
      <td width="18%" ><?php echo form_input('product_quantity1','','id="product_quantity" class="vertical" tabindex="10"');?></td>
      <td width="18%" ><?php echo form_input('total_quantity1','','id="total_quantity" class="vertical" tabindex="11"');?></td>
       </tr>
       <tr>
         <input id="prof_count" type="hidden" value="1" name="prof_count" />
       </tr>
       <tr id="prof_1"></tr>
       <tr >&nbsp;</tr>
       <tr style="border: 1px solid #7FB2CF; ">
         <td colspan="2">&nbsp;</td>
         <td>&nbsp;</td>
         <td width="18%" ><?php echo form_input('gtotal_quantity','','id="gtotal_quantity"');?></td>
       </tr>
         <tr style="border: 1px solid #7FB2CF; ">
         <td width="36%" valign="top"><div align="right" class="style4"><strong>Instruction</strong></div></td>
         <td width="29%"><?php echo form_textarea('comment','','id="comment"');?></td>
         <td>&nbsp;</td>
         <td width="18%" >&nbsp;</td>
       </tr>
     </tbody>
   </table>
 </div>
</div>    

<div class="row3">
<p><?php echo form_submit('submit', 'Submit','class="submit" ');?><input class="bb_close" onclick="hideOverlay();" href="#" title="Close" type="button" value="Cancel"></p>

    </div><!--end row3-->
</div><!--end u_table-->

<?php echo form_close();?>	

<script type="text/javascript">
 
 
 
		 $().ready(function() {
		 
		 
			$("#clientName").autocomplete("iwo/clientACName", {
				width: 150,
				matchContains: true,
				selectFirst: false
			});
			
			$("#clientName").result(function(event, data, formatted) {	
				clientInfo();
				contactInfo();
			});
		});

 
$(".vertical").keypress(function(event) {
        if(event.keyCode == 13) { 
        textboxes = $("input.vertical");

        currentBoxNumber = textboxes.index(this);
        if (textboxes[currentBoxNumber + 1] != null) {
            nextBox = textboxes[currentBoxNumber + 1]
           // nextBox.focus();
			if(nextBox.value !='')
			{
				nextBox = textboxes[currentBoxNumber + 2]
				
           // nextBox.focus();
			}
			
			nextBox.focus();
			
           event.preventDefault();
            return false 
            }
        }
    });
	
			$(document).keydown(function(e){
			if(e.keyCode==17)
			{
             //alert('CTRL Worlking');
			 	var product_description=$('#product_description').val();
				var measurement_size=$('#measurement_size').val();
				var product_quantity=$('#product_quantity').val(); 
				var product_quantity=$('#total_quantity').val();
				
				//alert(measurement_size);
				if ((product_description==''))
				{	
					$("#product_description").css("border-color","red");					
					$("#product_description").css("background-color","#FF9595");
					document.getElementById('product_description').focus();				
				} else if (measurement_size=='')
				{
					$("#measurement_size").css("border-color","red");					
					$("#measurement_size").css("background-color","#FF9595");
					document.getElementById('measurement_size').focus();
				
				}else if (product_quantity=='')
				{
					$("#product_quantity").css("border-color","red");					
					$("#product_quantity").css("background-color","#FF9595");
					document.getElementById('product_quantity').focus();
				} else if (total_quantity=='')
				{
					$("#total_quantity").css("border-color","red");					
					$("#total_quantity").css("background-color","#FF9595");
					document.getElementById('total_quantity').focus();
				} 
				else 				
				{
					$("#product_description").css("background-color","#E6F4FF");
					$("#product_description").css("border-style","solid");
					$("#product_description").css("border-color","#7FB2CF");
					
					$("#measurement_size").css("background-color","#E6F4FF");
					$("#measurement_size").css("border-style","solid");
					$("#measurement_size").css("border-color","#7FB2CF");
					
					$("#product_quantity").css("background-color","#E6F4FF");
					$("#product_quantity").css("border-style","solid");
					$("#product_quantity").css("border-color","#7FB2CF");	
									
					add25();
					document.getElementById('product_description').focus();
				}
				
			}
		});
		
		//
		function netPrice()
		{
			var unitPrice=document.getElementById("unit_price").value;
			var materialQty=document.getElementById("material_qty").value;
			var netPrice=(unitPrice*materialQty);
			document.getElementById("net_price").value= netPrice;

		}
		
		
				
		function add25()
		{
			//alert("new row working");
				$(document).ready(function(){
				 //alert("Add25");
			
				var ac=addStaff();
			
				function addStaff(){
				//alert("In");
				var product_description=encodeURIComponent($('#product_description').val());
				var measurement_size=encodeURIComponent($('#measurement_size').val());
				var product_quantity=encodeURIComponent($('#product_quantity').val()); 
				var total_quantity=encodeURIComponent($('#total_quantity').val());  
				var gtotal_quantity=encodeURIComponent($('#gtotal_quantity').val()); 
				
				//alert(measurement_size);
				
				var total_quantity_final=(Number(product_quantity)+Number(gtotal_quantity));
				 //alert(product_quantity+'+'+total_quantity+'='+total_quantity_final);
				 if(product_quantity!='')
				 {
				 
				document.getElementById("gtotal_quantity").value=total_quantity_final;
				} else 
				{
				document.getElementById("gtotal_quantity").value=0;
				}
				strCountField = '#prof_count';      
				intFields = $(strCountField).val();
				intFields = Number(intFields);    
				newField = intFields + 1;
				
				strNewField = "<tr class='prof blueBox' id='prof_" + newField + "'>\
							<input type='hidden' id='id" + newField + "' name='id" + newField + "' value='-1' />\
<td colspan='2'><input type='text' id='product_description" + newField + "' name='product_description[]' maxlength='10' value='"+product_description+"'  /></td>\
<td><input type='text' id='measurement_size" + newField + "' name='measurement_size[]' maxlength='10' value='"+measurement_size+"'  /></td>\
<td ><input type='text' id='product_quantity" + newField + "' name='product_quantity[]' maxlength='10' value='"+product_quantity+"'  /></td>\
<td ><input type='text' id='total_quantity" + newField + "' name='total_quantity[]' maxlength='10' value='"+total_quantity+"'  /></td>\
<td ><img src='<?php echo base_url();?>assets/images/delete.png' width='20' height='20' border='0' id='prof_" + newField + "'  value='prof_" + newField + "' onClick='del(this)' ></td>\
          </tr>\
		  <div class='nopass'><!-- clears floats --></div>\
		  "
		  ;

				$("#prof_" + intFields).after(decodeURIComponent(strNewField));    
				$("#prof_" + newField).slideDown("medium");
				$(strCountField).val(newField);				
				$('#product_description').val('');
				$('#measurement_size').val('');
				$('#product_quantity').val('');
				$('#total_quantity').val('');
				}
				
			
		});
		}
		
		
		function del(id)
		{
		
			var agree=confirm ('Are you want to delete This?')
			{
				if(agree)
				{
				
				var y= ($(id).attr("id"));
				
				var x=y.split('_');
				
				
				
				var product_description="product_description"+x[1];
				var measurement_size="measurement_size"+x[1];
				var product_quantity="product_quantity"+x[1];
			
				
				var dataName=document.getElementById(product_quantity).value;
				
				var total_quantity=$('#total_quantity').val();
				
				var total_quantity_final=(Number(total_quantity)-Number(dataName));
				 //alert(total_quantity_final);
				document.getElementById("total_quantity").value=total_quantity_final;
				
				//alert(total_quantity_final);
				
					document.getElementById(product_description).value='';
					document.getElementById(measurement_size).value='';
					document.getElementById(product_quantity).value='';
					
					
					
				 document.getElementById(y).style.display='none';
				 return true
				}
				else
				{
				return false;
				}
		}
		
		
		
		}//del function END
		
		$('#deliveryDate').change(function(e){
		
		 var fromDate=$('.todate').html();
		 var toDate=$('#deliveryDate').val();
		 
		  var startTime = dateToNumber(fromDate);
		  var endTime = dateToNumber(toDate);
		  
		 //alert('Start'+fromDate+'end='+toDate);
		 
		 
		 	if((startTime > endTime)||(startTime == endTime ) ){
			 alert(startTime+'>'+endTime);
			$('.iwoDate').css("border-color","red");					
			$("#iwoDate").css("background-color","#FF9595");
			$("#deliveryDate").css("border-color","red");
			$("#deliveryDate").css("background-color","#FF9595");
			document.getElementById('deliveryDate').focus();
			e.preventDefault();
		
		} else {
			
					$(".iwoDate").css("background-color","#E6F4FF");
					$(".iwoDate").css("border-color","#7FB2CF");	
					
					$("#deliveryDate").css("background-color","#E6F4FF");
					$("#deliveryDate").css("border-color","#7FB2CF");	
		}
		
		});
		
		function dateToNumber(eee){
		 
		 var x=eee.split('-');
		 
		 var y= x[0]+x[1]+x[2];
		 
		 return y;
		 
		 }
		 
		 
			$('.submit').click(function(e){
		
		
		
		 //var iwo_number				=$('#iwo_number').val();
		 var clientName				=$('#clientName').val();
	     var po_number				=$('#po_number').val();
		 var deliveryDate			=$('#deliveryDate').val();
	     var printing_po_number		=$('#printing_po_number').val();
		 var issued_to				=$('#issued_to').val();
	     var gtotal_quantity			=$('#gtotal_quantity').val();
		
		//alert('supp='+total_quantity);
		
		
		
/*		if(iwo_number == "" ){
		
		
			$("#iwo_number").css("border-color","red");					
			$("#iwo_number").css("background-color","#FF9595");
			$("#sms").css("display",""); 
			document.getElementById('iwo_number').focus();
			e.preventDefault();
		
		} else*/ 
		if(clientName == "" ){
		 e.preventDefault();
		 $('#clientName').val('');
		  $('#clientName').css("border-color","red");
			document.getElementById(clientName).focus();
			
		} else if(po_number == "" ){
		 e.preventDefault();
		 $('#po_number').val('');
		  $('#po_number').css("border-color","red");
			document.getElementById(po_number).focus();
			
		} else if(deliveryDate == "" ){
		 e.preventDefault();
		 $('#deliveryDate').val('');
		  $('#deliveryDate').css("border-color","red");
			document.getElementById(deliveryDate).focus();
			
		} else if(printing_po_number == "" ){
		 e.preventDefault();
		 $('#printing_po_number').val('');
		  $('#printing_po_number').css("border-color","red");
			document.getElementById(printing_po_number).focus();
			
		} else if(issued_to == "" ){
		 e.preventDefault();
		 $('#issued_to').val('');
		  $('#issued_to').css("border-color","red");
			document.getElementById(issued_to).focus();
			
		} 
		
		else if((gtotal_quantity == "" )||(gtotal_quantity == 0 )){
		  e.preventDefault();
		  $('#product_description').css("border-color","red");
			
			
		} 

		//return false;
		
	});
	
	 //##############**************DATE************Picker***********##########################	
$(function() {
		$( "#deliveryDate" ).datepicker({ dateFormat: 'yy-mm-dd' });
	});
	
 

</script>
