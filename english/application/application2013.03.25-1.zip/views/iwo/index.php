
<?php //+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++?>
<table width="100%" border="0" cellspacing="0" cellpadding="0">
	<tr>
	<td colspan="3"><img src="<?php echo base_url();?>assets/images/main_body_01.jpg" width="986" height="35" /></td>
	</tr>
	<tr>
	<td><img src="<?php echo base_url();?>assets/images/main_body_02.jpg" width="24" height="60" /></td>
	<td background="images/main_body_03.jpg" width="936" height="50">
	<table width="930"  border="0">
	<tr>
	<td width="49"><img src="<?php echo base_url();?>assets/images/iwo.png" width="48" height="48" /></td>
	<td width="595"><h1><span class="material">&nbsp;Internal Work Order</span></h1></td>
	<td width="33" class="border">
	<div align="center" class="section">
	<a class="pi" href="<?php echo base_url();?>iwo/create_iwo"><img src="<?php echo base_url();?>assets/images/new1.png" width="30" height="30" border="0" />New</a>
	</div>
	</td>
	
	</tr>
	</table>
	</td>
	<td><img src="<?php echo base_url();?>assets/images/main_body_04.jpg" width="26" height="60" /></td>
	</tr>
	<tr>
	<td colspan="3"><img src="<?php echo base_url();?>assets/images/main_body_05.jpg" width="986" height="32" /></td>
	</tr>
</table>
    
    <table width="100%" border="0" cellspacing="0" cellpadding="0">
	<tr>
	<td colspan="3"><img src="<?php echo base_url();?>assets/images/main_body_01.jpg" width="986" height="35" /></td>
	</tr>
	<tr>
	<td style="background:url(assets/images/bar.jpg) repeat-y;" valign="top"><img src="<?php echo base_url();?>assets/images/main_body_02.jpg" width="24" height="181" /></td>
	<td width="936" height="181" align="center" style="background:url(assets/images/main_body_03.jpg) repeat-x; background-color:#dee4f0" >
	
	
	<div class="table_user_round1">
	  
		<table width="100%"  cellpadding="4" cellspacing="1">
        <tr >
          <td height="35" colspan="5" align="left" valign="top"><form action="" method="post">
              <table width="406" border="0" cellspacing="2" cellpadding="1">
                <!--<tr>
                  <td width="2%">&nbsp;</td>
                  <td width="17%" align="center" valign="middle"><span class="filter2">Filter :</span> </td>
                  <td width="26%" align="left" valign="middle"><label>
                    <input type="text" name="target" id="target" class="filter">
                  </label></td>
                  <td width="15%" align="left" valign="middle"><label>
                    <input type="submit" name="submit" value="Go" class="button">
                  </label></td>
                  <td width="40%" align="left" valign="middle"><input type="reset" name="reset" value="Reset" class="button"></td>
                </tr>-->
              </table>
          </form></td>
          </tr>
          <tr>
            <td width="36" height="26" align="center" bgcolor="#C9DEF1" class="table_header"><span class="style2">#</span></td>
            
            <td width="121" align="center" bgcolor="#C9DEF1" class="table_header">work Order Number</td>
        <td width="108" align="center" bgcolor="#C9DEF1" class="table_header"><span class="style2">Client Name</span></td>
        <td width="105" align="center" bgcolor="#C9DEF1" class="table_header"><span class="style2">Order Date</span></td>
        <td width="119" align="center" bgcolor="#C9DEF1" class="table_header"><span class="style2">Delivery Date</span></td>
        <td width="138" align="center" bgcolor="#C9DEF1" class="table_header"><span class="style2">Issued By</span></td>
        <td width="118" align="center" bgcolor="#C9DEF1" class="table_header"><span class="style2">Issued To</span></td>
       
        
            
                        
            <td width="116" align="center" bgcolor="#C9DEF1" class="table_header"><span class="style2">Action </span></td>
          </tr>
		
		  <tbody >
         
            <?php $i=1; foreach ($iwos as $iwo):?>
             <?php if($i%2!=0)
			 { $c="#E3EDF9";
			 } else {
				$c="#FFFFFF"; } ?>
            <tr class="table_hover" bgcolor="<?php echo $c; ?>">
              <td width="36" height="27" align="center"><span class="style9"><?php echo $i;?></span></td>
              <td width="121" align="left" class="section" style="padding-left:10px;"><a href="#" title="<?php echo $iwo->iwo_number;?>" class="style2" > <?php echo $iwo->iwo_number;?></a></td>
              <td width="108" align="center" class="style2"><?php echo $iwo->client_name;?></td>
              <td width="105" align="center" class="style2"><?php echo $iwo->iwoDate;?></td>
              <td width="119" align="center" class="style2"><?php echo $iwo->deliveryDate;?></td>
              <td width="138" align="center" class="style2"><?php echo $iwo->issued_by;?></td>
              <td width="118" align="center" class="style2"><?php echo $iwo->issued_to;?></td>
                        
              
              <td width="116" align="center" class="section"><a href="<?php echo base_url();?>iwo/preview_iwo/<?php echo $iwo->iwo_number; ?>" class="pi" title="Preview"><img src="<?php echo base_url();?>assets/images/view.png" border="0"> </a>&nbsp;&nbsp;&nbsp; <a href="<?php echo base_url();?>iwo/iwo_del/<?php echo $iwo->iwo_number; ?>" title="Delete"><img src="<?php echo base_url();?>assets/images/delete.png" border="0"></a> </td>
            </tr>
            <?php $i++; endforeach;?>           
          </tbody></table>
	  </div>
	</td>
	<td style="background:url(assets/images/bar1.jpg) repeat-y;" valign="top"><img src="<?php echo base_url();?>assets/images/main_body_04.jpg" width="26" height="181" /></td>
	</tr>
	<tr>
	<td colspan="3"><img src="<?php echo base_url();?>assets/images/main_body_05.jpg" width="986" height="32" /></td>
	</tr>
	</table>
<div id="errors"><?php echo $message;?></div>
<?php //+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++?>


<div id="lightBox" align="center">
	<table cellspacing="0" cellpadding="0">
	<tr>
	<td colspan="3" align="right">
	<!--<a title="Close" class="bb_close" href="javascript:void(0);" onClick="hideOverlay();"></a>--></td>
	</tr>
	<tr>
	<td class="t_l"></td>
	<td class="t_c"></td>
	<td class="t_r"></td>
	</tr>
	<tr>
	<td class="c_l"></td>
	<td class="c_c">
	<div id="lightText"></div></td>
	<td class="c_r"></td>
	</tr>
	<tr>
	<td class="b_l"></td>
	<td class="b_c"></td>
	<td class="b_r"></td>
	</tr>
	</table>
</div>

<div id="lightBox4" align="center">
	<table cellspacing="0" cellpadding="0">
	<tr>
	<td colspan="3" align="right">
	<!--<a title="Close" class="bb_close" href="javascript:void(0);" onClick="hideOverlay();"></a>--></td>
	</tr>
	<tr>
	<td class="t_l"></td>
	<td class="t_c"></td>
	<td class="t_r"></td>
	</tr>
	<tr>
	<td class="c_l"></td>
	<td class="c_c">
	<div id="lightText4"></div></td>
	<td class="c_r"></td>
	</tr>
	<tr>
	<td class="b_l"></td>
	<td class="b_c"></td>
	<td class="b_r"></td>
	</tr>
	</table>
</div>


<script type="text/javascript">
//#########################################################################################


	//to retrive the subGroup of the selected Group//
	function clientInfo()
{
	
	var dataName=document.getElementById("clientName").value;
	//alert(groupName);
	
	var xmlRequest = GetXmlHttpObject();
	if (xmlRequest == null)
	return;
	var url="<?php echo base_url();?>iwo/clientInfoTrigger?dataName="+dataName;
	//alert(url);
	var browser=navigator.appName;
	if (browser=="Microsoft Internet Explorer")
		{
			xmlRequest.open("POST",url, true);
		}
	else
		{
			xmlRequest.open("GET",url, true);
		}
	xmlRequest.setRequestHeader("Content-Type", "application/x-www-formurlencoded");
	xmlRequest.onreadystatechange =function()
		{
			if(xmlRequest.readyState==4)
			{
				HandleAjaxResponseClientInfo(xmlRequest);
			}
		};
	xmlRequest.send(null);
	return false;
}



	function HandleAjaxResponseClientInfo(xmlRequest)
	{
		var xmlT=xmlRequest.responseText;
		
		
	var x=xmlT.split('~');
	
			if (x=='fail')
			{

			$("#clientName").css("border-color","red"); 

			} else 
			{
			//$("#sms").css("display","none"); 
			$("#clientName").css("background-color","#E6F4FF");
			$("#clientName").css("border-style","solid");
			$("#clientName").css("border-color","#7FB2CF");
			//alert('its  ok');
			
			//alert(xmlT);
			//document.getElementById("idSelect").value=x[0];
			document.getElementById("client_email").value=x[1];
			document.getElementById("client_phone").value=x[2];
			
			return false;
			
			}
	}
	
		
//##########################materialName###Dataretrive############################################################		

	//to retrive the subGroup of the selected Group//
	function contactInfo()
{
	
	var dataName=document.getElementById("clientName").value;
	//alert(groupName);
	
	var xmlRequest = GetXmlHttpObject();
	if (xmlRequest == null)
	return;
	var url="<?php echo base_url();?>iwo/contactInfoTrigger?dataName="+dataName;
	//alert(url);
	var browser=navigator.appName;
	if (browser=="Microsoft Internet Explorer")
		{
			xmlRequest.open("POST",url, true);
		}
	else
		{
			xmlRequest.open("GET",url, true);
		}
	xmlRequest.setRequestHeader("Content-Type", "application/x-www-formurlencoded");
	xmlRequest.onreadystatechange =function()
		{
			if(xmlRequest.readyState==4)
			{
				HandleAjaxResponsecontactInfo(xmlRequest);
			}
		};
	xmlRequest.send(null);
	return false;
}



	function HandleAjaxResponsecontactInfo(xmlRequest)
	{
		var xmlT=xmlRequest.responseText;
		
		document.getElementById('contact_person').innerHTML=xmlT;
		

	return false;
	}		
//#########################################################################################	
	function iwoCheck()
{
	
	var dataName=document.getElementById("iwo_number").value;
	//alert(groupName);
	
		var xmlRequest = GetXmlHttpObject();
		if (xmlRequest == null)
		return;
		var url="<?php echo base_url();?>iwo/iwoNumberCheck?dataName="+dataName;
		//alert(url);
		var browser=navigator.appName;
		if (browser=="Microsoft Internet Explorer")
			{
				xmlRequest.open("POST",url, true);
			}
		else
			{
				xmlRequest.open("GET",url, true);
			}
		xmlRequest.setRequestHeader("Content-Type", "application/x-www-formurlencoded");
		xmlRequest.onreadystatechange =function()
			{
				if(xmlRequest.readyState==4)
				{
					HandleAjaxResponse3(xmlRequest,dataName);
				}
			};
		xmlRequest.send(null);
		return false;
	
}



	function HandleAjaxResponse3(xmlRequest,dataName)
	{
		var xmlT=xmlRequest.responseText;
	var x=xmlT;
	
	if ((x==0)||(dataName==''))
	{
	//alert('its not OK');
	$('#iwo_number').val('');
	$("#iwo_number").css("border-color","red"); 
	$("#iwo_number").css("border-style","dotted"); 
	$("#sms").css("display",""); 
	document.getElementById('iwo_number').focus();
	
	} else 
	{
	$("#sms").css("display","none"); 
	$("#iwo_number").css("background-color","#E6F4FF");
	$("#iwo_number").css("border-style","solid");
	$("#iwo_number").css("border-color","#7FB2CF");
	//alert('its  ok');
	}
	
	
	
	return false;
	}	
 
	
	
//#########################################################################################	
	function GetXmlHttpObject()
{		
	var xmlHttp=null;
	try
	{
		xmlHttp=new XMLHttpRequest();
	}
	catch (e)
	{
		// Internet Explorer
		try
			{
				xmlHttp=new ActiveXObject("Microsoft.XMLHTTP");
			}
		catch (e)
			{
				xmlHttp=new ActiveXObject("Msxml2.XMLHTTP");
			}
	}
	return xmlHttp;
}


</script>

