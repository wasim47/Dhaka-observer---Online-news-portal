            <?php if (isset($contact_person_list)){ ?>
            
             <tr>
                <td colspan="4"><div align="center"><strong>Client contact person info</strong></div></td>
                </tr>
				<tr>
                <td>Contact Person Name:</td>
                <td >
						
				  <select   name="contact_person_name"  id="contact_person_name" >
                    <option  value="none" selected="selected" >Select name</option>
                    
					<?php foreach($contact_person_list as $data): ?>
					<option value="<?php echo $data->contact_person_name;?>" ><?php echo $data->contact_person_name;?></option>
				
				<?php endforeach;}?>
				  </select></td>
                <td>&nbsp;</td><td>&nbsp;</td>
              </tr>