
<?php //+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++?>
<table width="100%" border="0" cellspacing="0" cellpadding="0">
	<tr>
	<td colspan="3"><img src="<?php echo base_url();?>assets/images/main_body_01.jpg" width="986" height="35" /></td>
	</tr>
	<tr>
	<td><img src="<?php echo base_url();?>assets/images/main_body_02.jpg" width="24" height="60" /></td>
	<td background="images/main_body_03.jpg" width="936" height="50">
	<table width="930"  border="0">
	<tr>
	<td width="49"><img src="<?php echo base_url();?>assets/images/Product.png" width="48" height="48" /></td>
	<td width="595"><h1><span class="material">Material Receive</span> Report</h1></td>
	<!--<td width="28" class="border"><div align="center" class="section"><a href="javascript:void(0);" onClick="article_delete('delete','0');" ><img src="images/delete2.png" width="32" height="32" border="0" />Delete</a></div></td>-->
	<!--<td width="33" class="border"><div align="center" class="section"><a href="#" class="newFrm">
	<img src="images/edit1.png" width="32" height="32" border="0" />Edit</a></div></td>-->
<!--	<td width="33" class="border">
	<div align="center" class="section">
	<a class="uCreate" href="<?php echo base_url();?>stock_update/waste_return"><img src="<?php echo base_url();?>assets/images/return.png" width="30" height="30" border="0" />Return</a>
	</div>
	</td>-->
    
	
	</tr>
	</table>
	</td>
	<td><img src="<?php echo base_url();?>assets/images/main_body_04.jpg" width="26" height="60" /></td>
	</tr>
	<tr>
	<td colspan="3"><img src="<?php echo base_url();?>assets/images/main_body_05.jpg" width="986" height="32" /></td>
	</tr>
</table>
    
    <table width="100%" border="0" cellspacing="0" cellpadding="0">
	<tr>
	<td colspan="3"><img src="<?php echo base_url();?>assets/images/main_body_01.jpg" width="986" height="35" /></td>
	</tr>
	<tr>
	<td style="background:url(assets/images/bar.jpg) repeat-y;" valign="top"><img src="<?php echo base_url();?>assets/images/main_body_02.jpg" width="24" height="181" /></td>
	<td width="936" height="181" align="center" style=" background:url(assets/images/main_body_03.jpg) repeat-x; background-color:#dee4f0" >
	
	
	<div class="table_user_round1">
	  <p style="float:right; margin-right:20px; color:#999999">To get a date wise invoice Report please type &nbsp;&nbsp;&nbsp;
      
     <input style=" color:#999999 ; text-align:center; " id="invoiceDate" type="text" name='invoiceDate' value='Date'  autocomplete="off"   class="vertical"   tabindex="3" onblur="if(this.value=='') this.value='Date'" onFocus="if(this.value =='Date' ) this.value=''" /><a style="" class="back" href="<?php echo base_url();?>report_stock/reveive" title="Back">Back</a></p>
		<table width="100%"  cellpadding="4" cellspacing="1">
        
        <thead>
          <tr>
            <td width="38" height="26" align="center" bgcolor="#C9DEF1" class="table_header"><span class="style2">Sl No</span></td>
            
             <td width="97" align="center" bgcolor="#C9DEF1" class="table_header"><span class="style2">Material Code</span></td>
        <td width="97" align="center" bgcolor="#C9DEF1" class="table_header"><span class="style2">Material Name</span></td>
        <td width="105" align="center" bgcolor="#C9DEF1" class="table_header"><span class="style2">Supplier Name</span></td>
        <td width="100" align="center" bgcolor="#C9DEF1" class="table_header"><span class="style2">Invoice No.</span></td>
        <!--<td width="150" align="center" bgcolor="#C9DEF1" class="table_header"><span class="style2">WO#</span></td>-->
        <td width="67" align="center" bgcolor="#C9DEF1" class="table_header">UOM</td>
        <td width="75" align="center" bgcolor="#C9DEF1" class="table_header"><span class="style2">QTY</span></td>
        <td width="82" align="center" bgcolor="#C9DEF1" class="table_header"><span class="style2">Unit Price</span></td>
         <td width="82" align="center" bgcolor="#C9DEF1" class="table_header"><span class="style2">Net Price</span></td>
         <td width="100" align="center" bgcolor="#C9DEF1" class="table_header"><span class="style2">Remarks</span></td>
          </tr></thead>
        
		
		  <tbody id="singleshow">
            </tbody>          
          </table>
		
	</div></td>
	<td style="background:url(assets/images/bar1.jpg) repeat-y;" valign="top"><img src="<?php echo base_url();?>assets/images/main_body_04.jpg" width="26" height="181" /></td>
	</tr>
	<tr>
	<td colspan="3"><img src="<?php echo base_url();?>assets/images/main_body_05.jpg" width="986" height="32" /></td>
	</tr>
	</table>

<?php //+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++?>


<div id="lightBox" align="center">
	<table cellspacing="0" cellpadding="0">
	<tr>
	<td colspan="3" align="right">
	<!--<a title="Close" class="bb_close" href="javascript:void(0);" onClick="hideOverlay();"></a>--></td>
	</tr>
	<tr>
	<td class="t_l"></td>
	<td class="t_c"></td>
	<td class="t_r"></td>
	</tr>
	<tr>
	<td class="c_l"></td>
	<td class="c_c">
	<div id="lightText"></div></td>
	<td class="c_r"></td>
	</tr>
	<tr>
	<td class="b_l"></td>
	<td class="b_c"></td>
	<td class="b_r"></td>
	</tr>
	</table>
</div>

<div id="lightBox3" align="center">
	<table cellspacing="0" cellpadding="0">
	<tr>
	<td colspan="3" align="right">
	<!--<a title="Close" class="bb_close" href="javascript:void(0);" onClick="hideOverlay();"></a>--></td>
	</tr>
	<tr>
	<td class="t_l"></td>
	<td class="t_c"></td>
	<td class="t_r"></td>
	</tr>
	<tr>
	<td class="c_l"></td>
	<td class="c_c">
	<div id="lightText3"></div></td>
	<td class="c_r"></td>
	</tr>
	<tr>
	<td class="b_l"></td>
	<td class="b_c"></td>
	<td class="b_r"></td>
	</tr>
	</table>
</div>


<script type="text/javascript">
//#########################################################################################	
	
		
			
		
	//to retrive the subGroup of the selected Group//
	function reveiveNameByDate()
{	
	var dataName=document.getElementById("invoiceDate").value;
	//alert(groupName);
	
	var xmlRequest = GetXmlHttpObject();
	if (xmlRequest == null)
	return;
	var url="<?php echo base_url();?>report_stock/reveiveNameByDate?dataName="+dataName;
	//alert(url);
	var browser=navigator.appName;
	if (browser=="Microsoft Internet Explorer")
		{
			xmlRequest.open("POST",url, true);
		}
	else
		{
			xmlRequest.open("GET",url, true);
		}
	xmlRequest.setRequestHeader("Content-Type", "application/x-www-formurlencoded");
	xmlRequest.onreadystatechange =function()
		{
			if(xmlRequest.readyState==4)
			{
			     $(".back").css("display","block"); 
				HandleAjaxResponse_issueNameList(xmlRequest);
			}
		};
	xmlRequest.send(null);
	return false;
}


		function HandleAjaxResponse_issueNameList(xmlRequest)
	{
		var xmlT=xmlRequest.responseText;
		//alert(xmlT);
		document.getElementById('singleshow').innerHTML=xmlT;
		//loadmylightbox();
		test333();
		return false;
	}
	
//#########################################################################################



$(function() {
		$( "#invoiceDate" ).datepicker({ dateFormat: 'yy-mm-dd' });
	});
		$('#invoiceDate').change(function(e){
		
		//alert('Date Check Alpha')
		
		reveiveNameByDate();
		
		});	
	
//#########################################################################################	
	function GetXmlHttpObject()
{		
	var xmlHttp=null;
	try
	{
		xmlHttp=new XMLHttpRequest();
	}
	catch (e)
	{
		// Internet Explorer
		try
			{
				xmlHttp=new ActiveXObject("Microsoft.XMLHTTP");
			}
		catch (e)
			{
				xmlHttp=new ActiveXObject("Msxml2.XMLHTTP");
			}
	}
	return xmlHttp;
}


</script>

