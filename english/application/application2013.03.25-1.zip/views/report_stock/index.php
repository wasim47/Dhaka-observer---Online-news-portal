<style>
.table_report {
  color:#000000;
  border: 1px solid #FFFFFF;
  border-radius: 5px 5px 5px 5px;
  margin-bottom: 20px;
  margin-top: 20px;
  padding-bottom: 3px;
  width: 910px;
}

 .op {
  
  font-family: Arial,Helvetica,sans-serif;
  font-size: 12px;
  text-align: center;
}

</style>
<?php //+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++?>

    
    <table width="100%" border="0" cellspacing="0" cellpadding="0">
	<tr>
	
	<td width="936" height="181" align="center"  >
	
	
	<div class="table_report">
	  <p style="float:right; margin-right:20px; color:#999999">To get a single information of stock update please type &nbsp;&nbsp;&nbsp;
      
      <input style=" color:#999999 ; text-align:center; " id="suMaterialName" type="text" name='material_name' value='Material Name'  autocomplete="off"   class="vertical"   tabindex="3" onblur="if(this.value=='') this.value='Material Name'" onFocus="if(this.value =='Material Name' ) this.value=''" /><a style="" class="back" href="<?php echo base_url();?>report_stock" title="History">Back</a></p>
		<table width="100%"  cellpadding="4" cellspacing="1">
        
        <thead>
          <tr>
            <td width="29" height="26" rowspan="2" align="center" bgcolor="#C9DEF1" class="table_header"><span class="style2">Date</span></td>
            
             <td height="28" colspan="4" align="center" bgcolor="#CCCCCC" class="table_header">Receive</td>
        <!--<td width="150" align="center" bgcolor="#C9DEF1" class="table_header"><span class="style2">WO#</span></td>-->
        <td colspan="5" align="center" bgcolor="#CCCCCC" class="table_header">Issue</td>
        <td colspan="4" align="center" bgcolor="#CCCCCC" class="table_header">Balance</td>
        </tr>
          <tr>
            <td width="85" align="center" bgcolor="#C9DEF1" class="table_header"><span class="style2">Invoice No. </span></td>
            <td width="60" align="center" bgcolor="#C9DEF1" class="table_header"><span class="style2">Quantity</span></td>
            <td width="69" align="center" bgcolor="#C9DEF1" class="table_header"><span class="style2">Unit Price</span></td>
            <td width="60" align="center" bgcolor="#C9DEF1" class="table_header"><span class="style2">Net Price</span></td>
            <td width="89" align="center" bgcolor="#C9DEF1" class="table_header"><span class="style2">Work Order#</span></td>
            <td width="89" align="center" bgcolor="#C9DEF1" class="table_header"><span class="style2">Issue Order#</span></td>
            <td width="60" align="center" bgcolor="#C9DEF1" class="table_header"><span class="style2">Quantity</span></td>
            <td width="66" align="center" bgcolor="#C9DEF1" class="table_header"><span class="style2">Unit Price</span></td>
            <td width="61" align="center" bgcolor="#C9DEF1" class="table_header"><span class="style2">Net Price</span></td>
            <td width="61" align="center" bgcolor="#C9DEF1" class="table_header"><span class="style2">Quantity</span></td>
            <td width="53" align="center" bgcolor="#C9DEF1" class="table_header"><span class="style2">Unit Price</span></td>
            <td width="56" align="center" bgcolor="#C9DEF1" class="table_header"><span class="style2">Net Price</span></td>
            <td width="67" align="center" bgcolor="#C9DEF1" class="table_header"><span class="style2">Comment</span></td>
          </tr>
        </thead>
        
		
		  <tbody id="singleshow">
          </tbody>          
        </table>
	</div></td>
	
	</tr>
	</table>
<div id="errors"><?php echo $message;?></div>
<?php //+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++?>


<div id="lightBox" align="center">
	<table cellspacing="0" cellpadding="0">
	<tr>
	<td colspan="3" align="right">
	<!--<a title="Close" class="bb_close" href="javascript:void(0);" onClick="hideOverlay();"></a>--></td>
	</tr>
	<tr>
	<td class="t_l"></td>
	<td class="t_c"></td>
	<td class="t_r"></td>
	</tr>
	<tr>
	<td class="c_l"></td>
	<td class="c_c">
	<div id="lightText"></div></td>
	<td class="c_r"></td>
	</tr>
	<tr>
	<td class="b_l"></td>
	<td class="b_c"></td>
	<td class="b_r"></td>
	</tr>
	</table>
</div>

<div id="lightBox3" align="center">
	<table cellspacing="0" cellpadding="0">
	<tr>
	<td colspan="3" align="right">
	<!--<a title="Close" class="bb_close" href="javascript:void(0);" onClick="hideOverlay();"></a>--></td>
	</tr>
	<tr>
	<td class="t_l"></td>
	<td class="t_c"></td>
	<td class="t_r"></td>
	</tr>
	<tr>
	<td class="c_l"></td>
	<td class="c_c">
	<div id="lightText3"></div></td>
	<td class="c_r"></td>
	</tr>
	<tr>
	<td class="b_l"></td>
	<td class="b_c"></td>
	<td class="b_r"></td>
	</tr>
	</table>
</div>


<script type="text/javascript">
//#########################################################################################	

	 $().ready(function() {
			$("#suMaterialName").autocomplete("stock_update/wMaterialAc", {
				width: 150,
				matchContains: true,
				selectFirst: false
			});
			
			$("#suMaterialName").result(function(event, data, formatted) {	
				suMaterialName();
			});
		});
		
		
	//to retrive the subGroup of the selected Group//
	function suMaterialName()
{	
	var dataName=document.getElementById("suMaterialName").value;
	//alert(groupName);
	
	var xmlRequest = GetXmlHttpObject();
	if (xmlRequest == null)
	return;
	var url="<?php echo base_url();?>report_stock/materialNameTrigger?dataName="+dataName;
	//alert(url);
	var browser=navigator.appName;
	if (browser=="Microsoft Internet Explorer")
		{
			xmlRequest.open("POST",url, true);
		}
	else
		{
			xmlRequest.open("GET",url, true);
		}
	xmlRequest.setRequestHeader("Content-Type", "application/x-www-formurlencoded");
	xmlRequest.onreadystatechange =function()
		{
			if(xmlRequest.readyState==4)
			{
			     $(".back").css("display","block"); 
				HandleAjaxResponseName(xmlRequest);
			}
		};
	xmlRequest.send(null);
	return false;
}


		function HandleAjaxResponseName(xmlRequest)
	{
		var xmlT=xmlRequest.responseText;
		//alert(xmlT);
		document.getElementById('singleshow').innerHTML=xmlT;
		//loadmylightbox();
		test333();
		return false;
	}


	
 //#########################################################################################	
	

	
//#########################################################################################	
	function GetXmlHttpObject()
{		
	var xmlHttp=null;
	try
	{
		xmlHttp=new XMLHttpRequest();
	}
	catch (e)
	{
		// Internet Explorer
		try
			{
				xmlHttp=new ActiveXObject("Microsoft.XMLHTTP");
			}
		catch (e)
			{
				xmlHttp=new ActiveXObject("Msxml2.XMLHTTP");
			}
	}
	return xmlHttp;
}


</script>

