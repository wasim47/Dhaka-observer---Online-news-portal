		<?php $totalNP=0;
		$datas[][]=  0;?>	
        
   <table >
  <tr>
    <td colspan="3" width="33%">&nbsp;</td>
    <td colspan="3" width="33%"><div align="center">ARTSIGN (PVT.) LTD.<br />
    Issue Report (Work Order)</div></td>
    <td colspan="3" width="33%">&nbsp;</td>
  </tr>  
  <tr><td colspan="3">Work Order No.:&nbsp;&nbsp;<?php echo $m_list[0]->iwo_number;?></td><td colspan="3" >&nbsp;</td><td colspan="3" ><!--Work Order No.:&nbsp;&nbsp;<?php echo $m_list[0]->iwo_number;?>--></td></tr>
  <!--<tr><td>Factory Name:&nbsp;&nbsp;<?php echo $m_list[0]->factory_name;?></td><td>&nbsp;</td><td>&nbsp;</td></tr>-->
</table>
     
        
  <thead class="op">
            <tr>
              <td  height="26" align="center" bgcolor="#CCCCCC" class="op"><span class="style2">Sl#</span></td>
              <td  align="center" bgcolor="#CCCCCC" class="op"><span class="style2">Material Name</span></td>
              <td  align="center" bgcolor="#CCCCCC" class="op"><span class="style2">Material Code</span></td>
              <td  align="center" bgcolor="#CCCCCC" class="op"><span class="style2">Group Name</span></td>
              <td  align="center" bgcolor="#CCCCCC" class="op">UOM</td>
              <td  align="center" bgcolor="#CCCCCC" class="op"><span class="style2">QTY in Stock</span></td>
              <td  align="center" bgcolor="#CCCCCC" class="op"><span class="style2">Unit Price</span></td>
              <td  align="center" bgcolor="#CCCCCC" class="op"><span class="style2">Net Price</span></td>
              <td  align="center" bgcolor="#CCCCCC" class="op"><span class="style2">Comment</span></td>
            </tr>
          </thead>	       
    
        
         <?php $j=1; foreach($m_list as $i=>$data): ?>
          
	                 
        <tr>
        <td><?php echo $j; ?></td>
            <td> <?php echo $data->material_name; ?></td> 
            <td> <?php echo $data->material_code; ?></td> 
            <td> <?php echo $data->material_group; ?></td>  
            <td> <?php echo $data->measurement_unit; ?></td> 
            <td><?php echo $plusQ = $data->material_qty; ?></td>
            <td><?php  echo $data->unit_price; ?></td>
            <td> <?php echo $data->net_price; ?></td> 
            <td> <?php if ($data->return==0){$totalNP = $totalNP+$data->net_price;} else {$totalNP = $totalNP-$data->net_price;} echo $data->comment; ?></td> 
            
          
            </tr>


         <?php $j++; endforeach; ?>
         
         <tr style="border-top:solid 1px #666666">
		
          
           <td style="border-top:solid 1px #666666" >&nbsp;&nbsp;</td>
          <td style="border-top:solid 1px #666666" >&nbsp;&nbsp;</td>
          <td style="border-top:solid 1px #666666" >&nbsp;&nbsp;</td>
          <td style="border-top:solid 1px #666666" >&nbsp;&nbsp;</td>
          <td style="border-top:solid 1px #666666" >&nbsp;&nbsp;</td>
            <td style="border-top:solid 1px #666666" >&nbsp;&nbsp;</td>
            <td style="border-top:solid 1px #666666" > &nbsp;&nbsp;Total Price</td>
            <td style="border-top:solid 1px #666666" > <?php echo $totalNP ; ?></td> 
            
          
            </tr>
         
         
        
 