		<?php $totalNP=0;
		$datas[][]=  0;?>	
        
        
         <?php $j=1; foreach($m_list as $i=>$data): ?>
          
		            
        <tr>
        <td><?php echo $j; ?></td>
            <td> <?php echo $data->material_name; ?></td> 
            <td> <?php echo $data->material_code; ?></td> 
            <td> <?php echo $data->material_group; ?></td>  
            <td> <?php echo $data->measurement_unit; ?></td> 
            <td><?php echo $plusQ = $data->material_qty; ?></td>
            <td><?php $totalNP = $totalNP+$data->unit_price; echo $data->unit_price; ?></td>
            <td> <?php echo $data->net_price; ?></td> 
            <td> <?php echo $data->comment; ?></td> 
            
          
            </tr>


         <?php $j++; endforeach; ?>
         
         
        
 <!--       	<?php $m_code=array_unique($code); //print_r($m_code)?>	
            
          <?php $j=1; foreach($m_code as $i=>$uniq_m_code):   
		  
          //$data[$uniq_m_code]['tq'] = array();
		 
          		
            foreach($m_list as $i=>$data): 
			  //$test=0;
			  if($uniq_m_code==$data->material_code)
			  {
				  
				  echo 'test=kj<br/>';
				  if($data->pi_number!=0)
				  
				  { 
				  
				  	if($data->return==0){ $datas[$uniq_m_code]['tq']=$datas[$uniq_m_code]['tq']+$data->material_qty; } else { $datas[$uniq_m_code]['tq']=$datas[$uniq_m_code]['tq']-$data->material_qty; }
				  $datas[$uniq_m_code]['mn']=$data->material_name;
				  } 
				  
					  if($data->io_number!=0)
					  
					  { 
					  
					  	if($data->return==0){ $datas[$uniq_m_code]['tq']=$datas[$uniq_m_code]['tq']-$data->material_qty; } else { $datas[$uniq_m_code]['tq']=$datas[$uniq_m_code]['tq']+$data->material_qty; }
					    $datas[$uniq_m_code]['mn']=$data->material_name;
					  }
				  
						  if($data->return==2)
						  
						  { 
						  
						   	$datas[$uniq_m_code]['tq']=$datas[$uniq_m_code]['tq']-$data->material_qty; 
						  $datas[$uniq_m_code]['mn']=$data->material_name;
						  }
				 
			  }
			  ?>
          <?php  endforeach; ?>
          
          
          <?php //if($i>0){ $mata[$i]=$data->unit_price; $j=1-$i; $up_avg=(($mata[$i]+$mata[$j])/2);} else { $up_avg=$data->unit_price; } ?>
		  <!-- <tr>

            <td><?php echo $plusQ = $data->material_qty; ?></td>
            <td><?php $totalNP = $totalNP+$data->unit_price; echo $data->unit_price; ?></td>
            <td> <?php echo $data->net_price; ?></td> 
            
          
            </tr>-->
  				
                
                
         <?php  $j++; endforeach; //print_r($datas); ?>
         
         
         <?php foreach($datas as $i=>$fata): ?>
         
         <tr>
         <td><?php  echo $fata['mn'];?></td>
		 <td><?php  echo $fata['tq'];?></td>
		 </tr>
		 <?php endforeach; ?>
         
         
		  <tr style="border-top:solid 1px #666666">
		
          
           <td style="border-top:solid 1px #666666" >&nbsp;&nbsp;</td>
          <td style="border-top:solid 1px #666666" >&nbsp;&nbsp;</td>
          <td style="border-top:solid 1px #666666" >&nbsp;&nbsp;</td>
          <td style="border-top:solid 1px #666666" >&nbsp;&nbsp;</td>
          <td style="border-top:solid 1px #666666" >&nbsp;&nbsp;</td>
            <td style="border-top:solid 1px #666666" >&nbsp;&nbsp;</td>
            <td style="border-top:solid 1px #666666" > &nbsp;&nbsp;Total Price</td>
            <td style="border-top:solid 1px #666666" > <?php echo $totalNP ; ?></td> 
            
          
            </tr>-->