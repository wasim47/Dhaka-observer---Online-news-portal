
<style>
.table_report {
  color:#000000;
  border: 1px solid #FFFFFF;
  border-radius: 5px 5px 5px 5px;
  margin-bottom: 20px;
  margin-top: 20px;
  padding-bottom: 3px;
  width: 910px;
}

 .op {
  
  font-family: Arial,Helvetica,sans-serif;
  font-size: 12px;
  text-align: center;
}
</style>
<?php //+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++?>

    
    <table width="100%" border="0" cellspacing="0" cellpadding="0">
	
	<tr>
	
	<td width="936" height="181" align="center"  >
	
	
	<div class="table_report">
	  <p style="float:right; margin-right:20px; color:#999999">To get a date wise total Stock Report please type &nbsp;&nbsp;&nbsp;
      
     <input style=" color:#999999 ; text-align:center; " id="totalStockDate" type="text" name='totalStockDate' value='Date'  autocomplete="off"   class="vertical"   tabindex="3" onblur="if(this.value=='') this.value='Date'" onFocus="if(this.value =='Date' ) this.value=''" /><a style="" class="back" href="<?php echo base_url();?>report_stock/total_stock" title="Back">Back</a></p>
     <br />
		<table width="100%"  cellpadding="4" cellspacing="1">
          <thead class="op">
            <tr>
              <td  height="26" align="center" bgcolor="#CCCCCC" class="op"><span class="style2">Sl#</span></td>
              <td  align="center" bgcolor="#CCCCCC" class="op"><span class="style2">Material Name</span></td>
              <td  align="center" bgcolor="#CCCCCC" class="op"><span class="style2">Material Code</span></td>
              <td  align="center" bgcolor="#CCCCCC" class="op"><span class="style2">Group Name</span></td>
              <td  align="center" bgcolor="#CCCCCC" class="op">UOM</td>
              <td  align="center" bgcolor="#CCCCCC" class="op"><span class="style2">QTY in Stock</span></td>
              <td  align="center" bgcolor="#CCCCCC" class="op"><span class="style2">Unit Price</span></td>
              <td  align="center" bgcolor="#CCCCCC" class="op"><span class="style2">Net Price</span></td>
            </tr>
          </thead>
          <tbody id="singleshow">
          </tbody>
        </table>
	</div></td>
	</tr>
	<tr>
	<td colspan="3">&nbsp;</td>
	</tr>
	</table>

<?php //+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++?>


<div id="lightBox" align="center">
	<table cellspacing="0" cellpadding="0">
	<tr>
	<td colspan="3" align="right">
	<!--<a title="Close" class="bb_close" href="javascript:void(0);" onClick="hideOverlay();"></a>--></td>
	</tr>
	<tr>
	<td class="t_l"></td>
	<td class="t_c"></td>
	<td class="t_r"></td>
	</tr>
	<tr>
	<td class="c_l"></td>
	<td class="c_c">
	<div id="lightText"></div></td>
	<td class="c_r"></td>
	</tr>
	<tr>
	<td class="b_l"></td>
	<td class="b_c"></td>
	<td class="b_r"></td>
	</tr>
	</table>
</div>

<div id="lightBox3" align="center">
	<table cellspacing="0" cellpadding="0">
	<tr>
	<td colspan="3" align="right">
	<!--<a title="Close" class="bb_close" href="javascript:void(0);" onClick="hideOverlay();"></a>--></td>
	</tr>
	<tr>
	<td class="t_l"></td>
	<td class="t_c"></td>
	<td class="t_r"></td>
	</tr>
	<tr>
	<td class="c_l"></td>
	<td class="c_c">
	<div id="lightText3"></div></td>
	<td class="c_r"></td>
	</tr>
	<tr>
	<td class="b_l"></td>
	<td class="b_c"></td>
	<td class="b_r"></td>
	</tr>
	</table>
</div>


<script type="text/javascript">
//#########################################################################################	
	
		
			
		
	//to retrive the subGroup of the selected Group//
	function totalStockNameByDate()
{	
	var dataName=document.getElementById("totalStockDate").value;
	//alert(groupName);
	
	var xmlRequest = GetXmlHttpObject();
	if (xmlRequest == null)
	return;
	var url="<?php echo base_url();?>report_stock/totalStockNameByDate?dataName="+dataName;
	//alert(url);
	var browser=navigator.appName;
	if (browser=="Microsoft Internet Explorer")
		{
			xmlRequest.open("POST",url, true);
		}
	else
		{
			xmlRequest.open("GET",url, true);
		}
	xmlRequest.setRequestHeader("Content-Type", "application/x-www-formurlencoded");
	xmlRequest.onreadystatechange =function()
		{
			if(xmlRequest.readyState==4)
			{
			     $(".back").css("display","block"); 
				HandleAjaxResponse_totalStockNameList(xmlRequest);
			}
		};
	xmlRequest.send(null);
	return false;
}


		function HandleAjaxResponse_totalStockNameList(xmlRequest)
	{
		var xmlT=xmlRequest.responseText;
		//alert(xmlT);
		document.getElementById('singleshow').innerHTML=xmlT;
		//loadmylightbox();
		test333();
		return false;
	}
	
//#########################################################################################



$(function() {
		$( "#totalStockDate" ).datepicker({ dateFormat: 'yy-mm-dd' });
	});
		$('#totalStockDate').change(function(e){
		
		//alert('Date Check Alpha')
		
		totalStockNameByDate();
		
		});	
	
//#########################################################################################	
	function GetXmlHttpObject()
{		
	var xmlHttp=null;
	try
	{
		xmlHttp=new XMLHttpRequest();
	}
	catch (e)
	{
		// Internet Explorer
		try
			{
				xmlHttp=new ActiveXObject("Microsoft.XMLHTTP");
			}
		catch (e)
			{
				xmlHttp=new ActiveXObject("Msxml2.XMLHTTP");
			}
	}
	return xmlHttp;
}


</script>

