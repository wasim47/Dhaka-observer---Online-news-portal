

 <select   name="material_name"  id="materialName" >
  <option  value="none" selected="selected" >Select Material</option>
  <?php  foreach($m_n_list as $data):?>
					<option value="<?php echo $data->material_name;?>" ><?php echo $data->material_name;?></option>				
				<?php endforeach;?>
</select>
<?php echo form_submit('submit', 'GO','class="submit" onclick="validationCheck()"');?>

             