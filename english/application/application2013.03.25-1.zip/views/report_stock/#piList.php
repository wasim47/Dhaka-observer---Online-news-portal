<?php foreach($pi_m_list as $data):?>
          <tr>
            <td><?php echo form_input('material_name[]',$data->material_name,'id="material_name" autocomplete="off" "  class="vertical" readonly="" ');?></td>
            <td><?php echo form_input('material_code[]',$data->material_code,'id="material_code" readonly=""');?></td>
            <td><?php echo form_input('measurement_unit[]',$data->measurement_unit,'id="measurement_unit" readonly=""');?></td>
            <td><?php echo form_input('material_qty[]',$data->material_qty,'id="material_qty"  class="vertical" ');?></td>
            <td><?php echo form_input('unit_price[]',$data->unit_price,'id="unit_price"  class="vertical" ');?></td>
            <td ><?php echo form_input('net_price[]',$data->net_price,'id="net_price"');?>
            	 <?php echo form_hidden('supplier_name',$data->supplier_name,'id="supplier_name"');?>
                 <?php echo form_hidden('supplier_code',$data->supplier_code,'id="supplier_code"');?>
            	 <?php echo form_hidden('material_group[]',$data->material_group,'id="material_group"');?>
                 <?php echo form_hidden('sub_group[]',$data->sub_group,'id="sub_group"');?></td>
          </tr>
         <?php endforeach; ?>
         
		
        