			<?php $totalNP=0;?>		
          <?php $i=1; foreach($m_list as $data): ?>
          
          <?php //if($i>0){ $mata[$i]=$data->unit_price; $j=1-$i; $up_avg=(($mata[$i]+$mata[$j])/2);} else { $up_avg=$data->unit_price; } ?>
		   <tr>
		
          
           <td><?php echo $i;?></td>
          <td><?php echo $data->material_code; ?></td>
          <td><?php echo $data->material_name; ?></td>
          <td><?php echo $data->supplier_name; ?></td>
          <td><?php echo $data->pi_number; ?></td>
          <td><?php echo $data->measurement_unit; ?></td>
            <td><?php  echo $data->material_qty; ?></td>
            <td><?php echo $data->unit_price; ?></td>
            <td> <?php $totalNP = $totalNP+$data->net_price; echo $data->net_price; ?></td> 
            <td> <?php echo $data->comment; ?></td>  
            
          
            </tr>
           
          <?php $i++; endforeach; ?>
		 <tr>
		
          
           <td>&nbsp;&nbsp;</td>
          <td>&nbsp;&nbsp;</td>
          <td>&nbsp;&nbsp;</td>
          <td>&nbsp;&nbsp;</td>
          <td>&nbsp;&nbsp;</td>
          <td>&nbsp;&nbsp;</td>
            <td>&nbsp;&nbsp;</td>
            <td> &nbsp;&nbsp;Total Price</td>
            <td> <?php echo $totalNP ; ?></td> 
            <td> &nbsp;&nbsp;</td>  
            
          
            </tr>