		
        
        
         <?php  if(isset($m_list)){
		 
		 $j=1;
		 
		 foreach($m_list as $i=>$data): 
		 
		   $data->material_name;   
		   
		   $code[$i]=$data->material_code; 
		   
		    $j++;
			
			endforeach; 
			
			if(isset($code)){ $m_code=array_unique($code); 
			 
			  $j=1; foreach($m_code as $i=>$uniq_m_code):   
			  
			   $totalNP=$tq=$mn=$np=0;
			   
			     foreach($m_list as $i=>$data){
			  //$test=0;
			  if($uniq_m_code==$data->material_code)
			  {
			  		$mn=$data->material_name;
					$gn=$data->material_group;
					$mu=$data->measurement_unit;

				  if($data->pi_number!=0)
				  
				  { 
				  
				  	if($data->return==0){ $tq=$tq+$data->material_qty; $np=$np+$data->net_price;} else { $tq=$tq-$data->material_qty; $np=$np-$data->net_price; }
				  
				  } 
				  
					  if($data->io_number!=0)
					  
					  { 
					  
					  	if($data->return==0){ $tq=$tq-$data->material_qty; $np=$np-$data->net_price; } else { $tq=$tq+$data->material_qty; $np=$np+$data->net_price; }
					    //$mn=$data->material_name;
					  }
				  
						  if($data->return==2)				  
						  { 
						   	$tq=$tq-$data->material_qty; $np=$np-$data->net_price;
						  //$mn=$data->material_name;
						  }
				 
			  }
			  			  
			  } //End of all stock foreach
		?>	  
			  <tr>
			<td><?php echo $j; ?></td>
            <td><?php echo $mn; ?></td>
            <td><?php echo $uniq_m_code; ?></td>
            <td> <?php echo $gn; ?></td> 
            <td><?php  echo $mu; ?></td>
            <td> <?php $up=$np/$tq; echo $tq; ?></td> 
            <td><?php  echo $up; ?></td>
            <td> <?php echo $np; ?></td> 
            
          
            </tr>
<?php  endforeach; 
}
}?>