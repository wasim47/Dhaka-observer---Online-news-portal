<!--Ledger Report List-->


         <?php $totalQ=$plusQ=$minusQ=$totalBalance=0; //$up_avg=$unit_price_avg[0]->unit_price?>
          
          					
          <?php foreach($m_list as $i=>$data): ?>
          
          <?php //if($i>0){ $mata[$i]=$data->unit_price; $j=1-$i; $up_avg=(($mata[$i]+$mata[$j])/2);} else { $up_avg=$data->unit_price; } ?>
		   <tr>
		 <?php if($data->pi_number!=0){?>
          
           <td><?php echo $data->date;?></td>
          <td><?php echo $data->pi_number; ?></td>
            <td><?php echo $plusQ = $data->material_qty; ?><?php if($data->return==0){$totalQ=$totalQ+$plusQ; } else{ $totalQ=$totalQ-$plusQ;} ?></td>
            <td><?php echo $data->unit_price; ?></td>
            <td> <?php echo $data->net_price; ?></td>  
            
           <td>&nbsp;&nbsp;0</td>
          <td>&nbsp;&nbsp;0</td>
            <td>&nbsp;&nbsp;0</td>
            <td> &nbsp;&nbsp;0</td>
            <td> &nbsp;&nbsp;0</td>
            <td><?php if(($data->return==1)){$totalBalance=($totalBalance-$data->net_price); } else { $totalBalance=($totalBalance+$data->net_price);} echo $totalQ; ?></td>
            <td><?php  echo $up=$totalBalance/$totalQ; ?></td>
            <td> <?php  echo $totalBalance; ?> </td>
            <td> <?php echo $data->comment; ?></td></tr><?php } ?>
            
            
            		 <?php if($data->return==2){?>
          
           <td><?php echo $data->date;?></td>
          <td><?php echo $data->pi_number; ?></td>
            <td><?php echo $plusQ = $data->material_qty; ?><?php  $totalQ=($totalQ-$plusQ); ?></td>
            <td><?php echo $data->unit_price; ?></td>
            <td> <?php echo $data->net_price; ?></td>  
            
           <td>&nbsp;&nbsp;0</td>
          <td>&nbsp;&nbsp;0</td>
            <td>&nbsp;&nbsp;0</td>
            <td> &nbsp;&nbsp;0</td>
            <td> &nbsp;&nbsp;0</td>
            <td><?php echo $totalQ; ?></td>
            <td><?php  echo $data->unit_price; ?></td>
            <td> <?php $totalBalance=($totalQ*$data->unit_price); echo $totalBalance; ?> </td>
            <td> <?php echo $data->comment; ?></td></tr><?php } ?>
            
            
          <?php  if($data->io_number!=0){?>
           
          <td><?php echo $data->date;?></td>
           <td>&nbsp;&nbsp;0</td>
         	 <td>&nbsp;&nbsp;0</td>
            <td>&nbsp;&nbsp;0</td>
            <td>&nbsp;&nbsp;0</td>
           	<td><?php echo $data->iwo_number; ?></td>
           	<td><?php echo $data->io_number; ?></td>
            <td><?php echo $minusQ =$data->material_qty; ?><?php if($data->return==0){$totalQ=$totalQ-$minusQ; } else{ $totalQ=$totalQ+$minusQ;} ?> </td>
            <td><?php echo $data->unit_price; ?></td>
            <td> <?php echo $data->net_price;  ?></td>  
            <td><?php  echo $totalQ; ?></td> 
     		<td><?php echo $data->unit_price; ?></td>
            <td> <?php $totalBalance=($totalQ*$data->unit_price); echo $totalBalance; ?></td>
            <td> <?php echo $data->comment; ?></td></tr><?php } ?>
            
            
 							
         
         <?php  endforeach; ?>
		 