		<?php $totalNP=0;?>					
          <?php foreach($m_list as $i=>$data): ?>
          
          <?php //if($i>0){ $mata[$i]=$data->unit_price; $j=1-$i; $up_avg=(($mata[$i]+$mata[$j])/2);} else { $up_avg=$data->unit_price; } ?>
		   <tr>
		
          
           <td><?php echo $data->io_date;?></td>
          <td><?php echo $data->io_number; ?></td>
          <td><?php echo $data->iwo_number; ?></td>
          <td><?php echo $data->material_code; ?></td>
          <td><?php echo $data->material_name; ?></td>
          <td><?php echo $data->measurement_unit; ?></td>
            <td><?php echo $plusQ = $data->material_qty; ?></td>
            <td><?php  echo $data->unit_price_avg; ?></td>
            <td> <?php if ($data->return==0){$totalNP = $totalNP+$data->total_price; } else {$totalNP = $totalNP-$data->total_price;} echo $data->total_price; ?></td> 
            <td> <?php echo $data->comment; ?></td>  
            
          
            </tr>

         <?php  endforeach; ?>
		  <tr style="border-top:solid 1px #666666">
		
          
           <td style="border-top:solid 1px #666666" >&nbsp;&nbsp;</td>
          <td style="border-top:solid 1px #666666" >&nbsp;&nbsp;</td>
          <td style="border-top:solid 1px #666666" >&nbsp;&nbsp;</td>
          <td style="border-top:solid 1px #666666" >&nbsp;&nbsp;</td>
          <td style="border-top:solid 1px #666666" >&nbsp;&nbsp;</td>
          <td style="border-top:solid 1px #666666" >&nbsp;&nbsp;</td>
            <td style="border-top:solid 1px #666666" >&nbsp;&nbsp;</td>
            <td style="border-top:solid 1px #666666" > &nbsp;&nbsp;Total Price</td>
            <td style="border-top:solid 1px #666666" > <?php echo $totalNP ; ?></td> 
            <td style="border-top:solid 1px #666666" > &nbsp;&nbsp;</td>  
            
          
            </tr>