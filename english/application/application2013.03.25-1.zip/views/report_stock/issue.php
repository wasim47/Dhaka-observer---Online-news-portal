<style>

.table_report {
  color:#000000;
  border: 1px solid #FFFFFF;
  border-radius: 5px 5px 5px 5px;
  margin-bottom: 20px;
  margin-top: 20px;
  padding-bottom: 3px;
  width: 910px;
}

 .op {
  
  font-family: Arial,Helvetica,sans-serif;
  font-size: 12px;
  text-align: center;
}
</style>


<?php //+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++?>
<table width="100%" border="0" cellspacing="0" cellpadding="0">
	<tr>
	<td width="936">&nbsp;</td>
	</tr>
</table>
    
<table width="100%" border="0" cellspacing="0" cellpadding="0">
	<tr>
	
	<td width="936" height="181" align="center"  >
	
	
	<div class="table_report">
	  <p style="float:right; margin-right:20px; color:#999999">To get a date wise Issue Report please type &nbsp;&nbsp;&nbsp;
      
     <input style=" color:#999999 ; text-align:center; " id="issueDate" type="text" name='issueDate' value='Date'  autocomplete="off"   class="vertical"   tabindex="3" onblur="if(this.value=='') this.value='Date'" onFocus="if(this.value =='Date' ) this.value=''" /><a style="" class="back" href="<?php echo base_url();?>report_stock/issue" title="Back">Back</a></p>
		<table width="100%"  cellpadding="4" cellspacing="1">
        
        <thead>
          <tr>
            <td width="38" height="26" align="center" bgcolor="#C9DEF1" class="table_header"><span class="style2">Date</span></td>
            
             <td width="97" align="center" bgcolor="#C9DEF1" class="table_header"><span class="style2">Issue Order#</span></td>
        <td width="97" align="center" bgcolor="#C9DEF1" class="table_header"><span class="style2">Work Order#</span></td>
        <td width="105" align="center" bgcolor="#C9DEF1" class="table_header"><span class="style2">Material Code</span></td>
        <td width="100" align="center" bgcolor="#C9DEF1" class="table_header"><span class="style2">Material Name</span></td>
        <!--<td width="150" align="center" bgcolor="#C9DEF1" class="table_header"><span class="style2">WO#</span></td>-->
        <td width="67" align="center" bgcolor="#C9DEF1" class="table_header">UOM</td>
        <td width="75" align="center" bgcolor="#C9DEF1" class="table_header"><span class="style2">QTY</span></td>
        <td width="82" align="center" bgcolor="#C9DEF1" class="table_header"><span class="style2">Unit Price</span></td>
         <td width="82" align="center" bgcolor="#C9DEF1" class="table_header"><span class="style2">Net Price</span></td>
         <td width="100" align="center" bgcolor="#C9DEF1" class="table_header"><span class="style2">Remarks</span></td>
          </tr></thead>
        
		
		  <tbody id="singleshow">
            </tbody>          
          </table>
	</div></td>
	
	</tr>
	
	</table>

<?php //+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++?>


<div id="lightBox" align="center">
	<table cellspacing="0" cellpadding="0">
	<tr>
	<td colspan="3" align="right">
	<!--<a title="Close" class="bb_close" href="javascript:void(0);" onClick="hideOverlay();"></a>--></td>
	</tr>
	<tr>
	<td class="t_l"></td>
	<td class="t_c"></td>
	<td class="t_r"></td>
	</tr>
	<tr>
	<td class="c_l"></td>
	<td class="c_c">
	<div id="lightText"></div></td>
	<td class="c_r"></td>
	</tr>
	<tr>
	<td class="b_l"></td>
	<td class="b_c"></td>
	<td class="b_r"></td>
	</tr>
	</table>
</div>

<div id="lightBox3" align="center">
	<table cellspacing="0" cellpadding="0">
	<tr>
	<td colspan="3" align="right">
	<!--<a title="Close" class="bb_close" href="javascript:void(0);" onClick="hideOverlay();"></a>--></td>
	</tr>
	<tr>
	<td class="t_l"></td>
	<td class="t_c"></td>
	<td class="t_r"></td>
	</tr>
	<tr>
	<td class="c_l"></td>
	<td class="c_c">
	<div id="lightText3"></div></td>
	<td class="c_r"></td>
	</tr>
	<tr>
	<td class="b_l"></td>
	<td class="b_c"></td>
	<td class="b_r"></td>
	</tr>
	</table>
</div>


<script type="text/javascript">
//#########################################################################################	
	
		
			
		
	//to retrive the subGroup of the selected Group//
	function issueNameByDate()
{	
	var dataName=document.getElementById("issueDate").value;
	//alert(groupName);
	
	var xmlRequest = GetXmlHttpObject();
	if (xmlRequest == null)
	return;
	var url="<?php echo base_url();?>report_stock/issueNameByDate?dataName="+dataName;
	//alert(url);
	var browser=navigator.appName;
	if (browser=="Microsoft Internet Explorer")
		{
			xmlRequest.open("POST",url, true);
		}
	else
		{
			xmlRequest.open("GET",url, true);
		}
	xmlRequest.setRequestHeader("Content-Type", "application/x-www-formurlencoded");
	xmlRequest.onreadystatechange =function()
		{
			if(xmlRequest.readyState==4)
			{
			     $(".back").css("display","block"); 
				HandleAjaxResponse_issueNameList(xmlRequest);
			}
		};
	xmlRequest.send(null);
	return false;
}


		function HandleAjaxResponse_issueNameList(xmlRequest)
	{
		var xmlT=xmlRequest.responseText;
		//alert(xmlT);
		document.getElementById('singleshow').innerHTML=xmlT;
		//loadmylightbox();
		test333();
		return false;
	}
	
//#########################################################################################



$(function() {
		$( "#issueDate" ).datepicker({ dateFormat: 'yy-mm-dd' });
	});
		$('#issueDate').change(function(e){
		
		//alert('Date Check Alpha')
		
		issueNameByDate();
		
		});	
	
//#########################################################################################	
	function GetXmlHttpObject()
{		
	var xmlHttp=null;
	try
	{
		xmlHttp=new XMLHttpRequest();
	}
	catch (e)
	{
		// Internet Explorer
		try
			{
				xmlHttp=new ActiveXObject("Microsoft.XMLHTTP");
			}
		catch (e)
			{
				xmlHttp=new ActiveXObject("Msxml2.XMLHTTP");
			}
	}
	return xmlHttp;
}


</script>

